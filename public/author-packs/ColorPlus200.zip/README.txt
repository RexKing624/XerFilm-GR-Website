XerFilm GR · ColorPlus200

==================== 简体中文 ====================

一款 ColorPlus 200 彩色效果。
只有一款效果：ADJ 直接选用 ColorPlus200，不弹出子菜单。
适用机型与固件：GR III／GR IV（含 HDF）的 XerFilm GR V3.11。
GR IIIx（含 HDF）暂不支持。
本包是胶片效果数据，不是 .bin 固件。

解压后的结构
README.txt
XERFILM/
    （内含 .XFC 安装文件）
DELETE/
    （内含 .XFC 删除补丁，平时不要放进 XERFILM）

安装／更新
1. 将 XERFILM 文件夹复制到内存卡根目录，不要再套一层文件夹。
2. 在相机打开「XerFilm GR → 胶片列表 → 从卡安装／更新」。
3. 若提示该胶片已安装、需要替换，再按一次 OK 确认；MENU 取消。
4. 安装后立即生效，关机、换卡或移走卡内安装文件后仍保留。
5. 在胶片列表启用／停用胶片后，请按 MENU「保存」。

删除：务必按以下顺序操作
1. DELETE 只是存放删除补丁的文件夹，相机不会读取它。
2. 先移走卡根目录 XERFILM 中的安装文件、其他效果包和删除补丁。
3. 将 DELETE 文件夹里的 .XFC 删除补丁移动到卡根目录的 XERFILM 中。
   执行删除时，XERFILM 内只保留这一份删除补丁，不要混放任何其他文件。
   删除补丁应直接放在：内存卡根目录/XERFILM/
   不要把整个 DELETE 文件夹放进 XERFILM，也不要直接在 DELETE 文件夹中运行。
4. 在相机「胶片列表」功能区选择「执行作者删除补丁」。提示后再按一次 OK 确认；MENU 取消。
5. 完成后，将删除补丁移回 DELETE，或从卡上移走，避免以后误操作。

此补丁仅删除本包对应的 ColorPlus200，不影响其他作者胶片、内置胶片或用户四槽。
删除立即生效，无需重启。删除后可用本包原安装文件重新安装。
安装与删除对象由文件内部校验确定，修改文件名不能改变目标。

==================== English ====================

One ColorPlus 200 color look.
The single look is selected directly as ColorPlus200 in ADJ, without a submenu.
Compatible cameras and firmware: GR III / GR IV (including HDF), running XerFilm GR V3.11.
GR IIIx (including HDF) is not supported yet.
These are film-look data files, not .bin firmware.

Archive contents
README.txt
XERFILM/    Contains the .XFC installation file
DELETE/     Contains the .XFC deletion patch; keep outside XERFILM during normal use

Install / update
1. Copy XERFILM to the root of the SD card, without an extra enclosing folder.
2. On the camera, open XerFilm GR → Film list → Install / update from SD.
3. If replacement of the installed look is requested, press OK again to confirm, or MENU to cancel.
4. The look applies immediately and remains installed after power-off, changing cards or removing the SD installation file.
5. After enabling or disabling looks in the film list, press MENU (Save).

Delete: follow this order
1. DELETE is only a storage folder for the patch. The camera does not scan it.
2. Remove the installer, other effect packs and any other deletion patches from the card's XERFILM folder first.
3. Move the .XFC deletion patch FILE from DELETE into XERFILM at the card root.
   When deleting, this one deletion patch must be the ONLY file inside XERFILM.
   Place the deletion patch directly inside: SD card root/XERFILM/
   Do not place the whole DELETE folder inside XERFILM. A patch left inside DELETE is not executed.
4. In the camera's film-list action area, select Execute author deletion patch. Press OK again to confirm, or MENU to cancel.
5. Once finished, move the patch back to DELETE or remove it from the card to prevent accidental reuse.

This patch removes only the ColorPlus200 look from this pack. Other author looks, built-in looks and the four user slots are preserved.
Deletion applies immediately, without restarting. The original installation file can be used to reinstall afterward.
Internal validation determines what is installed or deleted. Renaming a file cannot change the target.

==================== 日本語 ====================

ColorPlus 200 のカラールック1種類。
ADJ では ColorPlus200 を直接選択できます。サブメニューは表示されません。
対応機種・ファームウェア：GR III／GR IV（HDF を含む）の XerFilm GR V3.11。
GR IIIx（HDF を含む）は現在未対応です。
本パックはフィルム効果のデータであり、.bin ファームウェアではありません。

解凍後の構成
README.txt
XERFILM/    .XFC インストール用ファイルを格納
DELETE/     .XFC 削除パッチを格納。通常は XERFILM に入れないでください

インストール／更新
1. XERFILM フォルダーを SD カードのルートにコピーします。外側に別のフォルダーを作らないでください。
2. カメラで「XerFilm GR → フィルムリスト → SDからインストール／更新」を開きます。
3. インストール済みルックの置き換え確認が表示された場合は、もう一度 OK を押して確定します。MENU でキャンセルできます。
4. すぐに適用されます。電源を切る、カードを交換する、カード内のインストールファイルを移動する、といった操作をしてもカメラ内に保持されます。
5. フィルムリストで有効／無効を変更した後は、MENU（保存）を押してください。

削除：必ず次の順番で操作してください
1. DELETE は削除パッチを保管するだけのフォルダーです。カメラはこのフォルダーを読み取りません。
2. 先にカードの XERFILM 内から、インストールファイル、他の効果パック、他の削除パッチを移動してください。
3. DELETE 内の .XFC 削除パッチファイルを、カードのルートにある XERFILM へ移動します。
   削除実行時は、XERFILM 内をこの削除パッチ1個だけにしてください。他のファイルを混在させないでください。
   削除パッチの配置先：SD カードのルート/XERFILM/ の直下
   DELETE フォルダー全体を XERFILM に入れないでください。DELETE に置いたままでは実行されません。
4. カメラのフィルムリストの機能エリアで「作者削除パッチを実行」を選びます。確認後、もう一度 OK を押して確定します。MENU でキャンセルできます。
5. 完了後は誤操作を防ぐため、パッチを DELETE に戻すか、カードから移動してください。

このパッチが削除するのは、本パックの ColorPlus200 のみです。他の作者ルック、内蔵ルック、4つのユーザースロットには影響しません。
削除はすぐに反映され、再起動は不要です。削除後も、元のインストールファイルで再インストールできます。
インストールや削除の対象はファイル内部の検証で決まります。ファイル名を変更しても対象は変わりません。
