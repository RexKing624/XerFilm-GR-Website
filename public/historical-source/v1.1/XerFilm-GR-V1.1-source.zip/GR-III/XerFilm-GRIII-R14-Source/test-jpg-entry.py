# SPDX-License-Identifier: GPL-2.0-only
# Execute real per-exposure hook, both native job builders, JPEG entry and
# native cache dispatcher. CPU cache and JPEG DMA memory are separate fixtures.
# OS locks, allocator, date service and physical cache op endpoints are doubles.
from pathlib import Path
import importlib.util,struct,json,hashlib,sys
from unicorn import UC_HOOK_CODE
from unicorn.arm_const import *
R=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('port',R/'test-port.py');m0=importlib.util.module_from_spec(spec);spec.loader.exec_module(m0)
e=m0.Emu('GRIII');u=e.u;m=e.m;checks=[]
def ck(x,msg):
 assert x,msg
 checks.append(msg)
u.hook_del(e.hookHandle)
# Do not stub cache API: test the real function and its operation selection.
for a in [0x536bbc30,0x536bbcc0,0x536bbcac]:e.stubs.pop(a,None)
e.stubs.update({0x536b09f0:lambda:1,0x5304dfcc:lambda:0,0x5304dfe8:lambda:0,0x5383c6c0:lambda:0})
W,H,S=320,214,352;SZ=S*H;Y,C,PY,PC,RAW=0x70800000,0x70900000,0x70b00000,0x70c00000,0x70a00000
JOB,SHOT,PKT,PROC=0x70400000,0x70500000,0x70600000,0x70601000
planes=[Y,C,PY,PC,RAW];dma={};events=[]
def operation(kind):
 # Range APIs receive r0=aligned address, r1=byte count. Native global APIs
 # use no range; our fixture still owns only these small isolated buffers.
 a,n=e.reg(0),e.reg(1)
 for p in planes:
  if kind.startswith('global') or (p<a+n and p+SZ>a):
   if kind.endswith('clean') or kind.endswith('flush'):dma[p]=bytes(u.mem_read(p,SZ))
   if kind.endswith('invalidate') or kind.endswith('flush'):u.mem_write(p,dma[p])
 events.append((kind,a,n));return 0
for a,k in [(0x53853028,'range-invalidate'),(0x53853034,'range-clean'),(0x53853040,'range-flush'),(0x53000bb4,'global-invalidate'),(0x53000c38,'global-clean'),(0x53000cbc,'global-flush')]:
 e.stubs[a]=lambda k=k:operation(k)
for a in e.stubs:u.hook_add(UC_HOOK_CODE,e.hook,begin=a,end=a)
e.call(m['preferences']['init']);e.w32(0x70003004,0x7000b000)
def desc(a,y,c):u.mem_write(a,struct.pack('<B3xIII HHHH HH 4x',1,y,c,0,W,H,S,H,0,0))
def prepare(mode=5,strength=3,look=10,on=1):
 events.clear();u.mem_write(JOB,bytes(0x5000));u.mem_write(SHOT,bytes(0x74000))
 for p,v in [(Y,100),(C,128),(PY,110),(PC,128),(RAW,57)]:
  dma[p]=bytes([v])*SZ;u.mem_write(p,dma[p])
 desc(JOB+0x70,Y,C);desc(JOB+0x90,PY,PC);desc(JOB+0xb0,Y,C);desc(JOB+0xd0,PY,PC)
 e.w32(JOB+0x44c8,SHOT);u.mem_write(SHOT+0xb60,struct.pack('<f',8.33))
 e.w16(SHOT+0x944,2026);u.mem_write(SHOT+0x946,bytes([10,20,0,11,43,22]))
 # Use actual menu setters rather than manually manufacturing packed bits.
 ctrl=0x70602000;e.w32(ctrl+0x1d8,4);e.call(m['menu']['setter'],ctrl,strength)
 e.w32(ctrl+0x1d8,5);e.call(m['menu']['setter'],ctrl,[0,1,2,4,5,3][mode])
 e.w8(m0.SELECT,look);e.w8(m0.FLAG,on)
 # Real hook is at the date/identity capture entry, with ShotInfo in r1.
 e.call(0x5346afec,0x70603000,SHOT,0,until=0x5346aff0)
 v=e.call(m['capture']['lookup'],SHOT)
 ck(bool(v>>31)==bool(on) and ((v>>24)&31)==look,'native exposure hook freezes current look')
 ck(((v>>17)&3)==strength and ((v>>19)&7)==mode,'menu strengths/formats reach exposure snapshot')
 # Change live UI after capture: encoder must use frozen shot settings.
 e.w8(m0.SELECT,0);e.w8(m0.FLAG,1-on);e.call(m['enabled']['setGrain'],0);e.call(m['enabled']['setStamp'],0)
def encode(stage,base):
 e.call(0x5350e624,JOB,stage)
 cfg=JOB+base
 ck(e.word(cfg+0x34)==SHOT,'native builder binds captured ShotInfo')
 ck(e.word(cfg+0x3c)==JOB+(0x70 if stage==21 else 0xb0),'native builder binds main picture')
 e.w32(PKT+8,cfg)
 e.call(0x535047d4,PROC,PKT,0x12345678,0x76543210,until=0x535047d8,limit=16000000)
 ck([e.reg(i)for i in range(4)]==[PROC,PKT,0x12345678,0x76543210],'JPEG entry preserves original arguments')
for stage,base in [(21,0x904),(6,0x9b8)]:
 for mode,strength in [(0,3),(5,0),(5,3)]:
  prepare(mode,strength);before={p:dma[p] for p in planes};encode(stage,base)
  ck(dma[Y]!=before[Y],'JPEG DMA sees grain/stamp pixels after native cache writeback')
  if mode:ck(dma[C]!=before[C] or dma[Y][-S*25:]!=before[Y][-S*25:],'timestamp reaches encoded main buffer')
  ck(all(dma[p]==before[p] for p in [RAW,PY,PC]),'RAW and shared preview DMA memory unchanged')
  ck(any('clean' in x[0]for x in events),'native cache dispatcher executes CLEAN after pixel edits')
 prepare(on=0);before={p:dma[p]for p in planes};encode(stage,base)
 ck(all(dma[p]==before[p]for p in planes),'film OFF bypasses all pixel processing at native JPEG entry')
# Exercise native large-range dispatch too. Its threshold delegates to the
# stock whole-cache clean endpoint, not invalidation.
e.stubs[0x5383c6c0]=lambda:1
prepare(mode=5,strength=3);before=dma[Y];encode(6,0x9b8)
ck(dma[Y]!=before and any(k=='global-clean'for k,a,n in events),'large-image native branch writes back dirty pixels')
# Verify actual cache endpoint instructions (no guessed symbolic names).
ck(e.word(0x530008ec)==0xee074f36,'old callback routes to DCIMVAC discard')
ck(e.word(0x53000918)==0xee074f3a,'new callback routes to DCCMVAC writeback')
report=dict(status='passed',checks=len(checks),rtosSha256=hashlib.sha256(e.image).hexdigest(),hardwareTested=False,nativeExposureHook=True,nativeConfigBuilders=[21,6],nativeJpegEntry=True,nativeCacheDispatcher=True,physicalCacheAndDmaModelled=True,limitations='Physical cache/OS/clock are fixtures; not hardware verification')
(R/'jpg-entry-checks.json').write_text(json.dumps(report,indent=2));print(report)
