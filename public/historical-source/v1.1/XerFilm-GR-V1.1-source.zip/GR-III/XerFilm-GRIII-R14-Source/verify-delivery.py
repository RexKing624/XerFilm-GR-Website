# SPDX-License-Identifier: GPL-2.0-only
# Independent Python decoder of the exact final BINs, separate from TS packing.
from pathlib import Path
import json,sys,hashlib,struct
R=Path(__file__).resolve().parent;W=R.parents[1];O=W/'outputs/XerFilm-GRIII-R14-MenuFix-2026-10-21'
sys.path.insert(0,str(W/'work/gr-custom-tool'))
from gr4_editor.codec.container import inspect_container,sum32
from gr4_editor.codec.frames import decode_payload,section_rows
checks=[]
def ck(v,m):
 assert v,m
 checks.append(m)
def decode(p):
 b=p.read_bytes();m=inspect_container(b);d,_=decode_payload(b[128:128+m['encoded_size']],m['decoded_size'])
 ck(m['additive_sum32']==0,'independent complete BIN checksum');ck(sum32(d)==0,'independent decoded checksum')
 return b,m,d
candidate=(R/'resource-build/GRIII/image.rtos').read_bytes()
for folder in sorted(O.glob('GRIII-R14-*')):
 report=json.loads((folder/'validation.json').read_text());b,m,d=decode(folder/'fwdc239b.bin');ob,om,od=decode(W/report['basePath'])
 ck(hashlib.sha256(b).hexdigest()==report['sha256'],'final SHA256');ck(hashlib.sha256(ob).hexdigest()==report['baseSha256'],'pinned base SHA256')
 ck(b[:128]==ob[:128]and m['project']==om['project']==588,'model and all installation version/header bytes unchanged')
 ck(section_rows(d)==section_rows(od),'all section geometry unchanged')
 rt=next(s for s in section_rows(d)if s['name']=='RTOS');start=rt['start']+16
 expected=[start+v for v in [0xb5d36b,0xb5d36c,0xb5d36d]]
 diff=[i for i,(a,v)in enumerate(zip(d,od))if a!=v]
 ck(len(d)==len(od)and [i for i in diff if i<len(d)-4]==expected,'only three setting capacity bytes plus checksum changed')
 for i in expected:ck((od[i],d[i])==(12,14),'exact count12 to14')
 for s in section_rows(d):
  if s['name']not in ['RTOS','RES']:ck(d[s['start']:s['end']]==od[s['start']:s['end']],'unchanged whole section '+s['name'])
 image=bytearray(d[start:start+len(candidate)])
 if report['build']=='R14-H':
  base=(W/'work/gr3-native-cinema-r13/resource-build/GRIII/image.rtos').read_bytes()
  for offset in [0x2038,0x81fe6c,0x81fe7c,0x6285dc]:image[offset:offset+4]=base[offset:offset+4]
 ck(bytes(image)==candidate,'final decoded feature image equals ARM-regression-validated source')
 result={'status':'passed','hardwareTested':False,'filename':'fwdc239b.bin','sha256':report['sha256'],'checks':len(checks),'scope':'Independent Python file/payload decoding; three capacity bytes only; exact native feature image validated by ARM suites.'}
 (folder/'independent-checks.json').write_text(json.dumps(result,indent=2));print(report['build'],result,flush=True)
(O/'independent-checks.json').write_text(json.dumps({'status':'passed','hardwareTested':False,'checks':checks},indent=2))
