# SPDX-License-Identifier: GPL-2.0-only
# Execute native GR III configuration queries, shooting icon paths, and native
# change-event writer. Widget setters and external services remain test doubles.
from pathlib import Path
import importlib.util,struct,json,hashlib
from unicorn.arm_const import *
R=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('port',R/'test-port.py');port=importlib.util.module_from_spec(s);s.loader.exec_module(port)
e=port.Emu('GRIII');u=e.u;m=e.m;iso=m['runtime']['isolation'];BASE=port.BASE
original=(R/'decoded/GRIII/RTOS.bin').read_bytes();checks=[]
def ck(value,message):
 assert value,message
 checks.append(message)
user=0x70005000;wrapper=0x70004000;model=e.alloc(0x100);packet=e.alloc(0x180)
e.call(m['preferences']['init'])
# The bug was a shared SpecModel hook. Both shared resolvers, including custom
# icons 0x15b/0x15c, must now match the official ROM byte for byte.
for a,n in [(0x532a9b2c,0x78),(0x532a9ba8,0x78),(0x5324429c,24)]:
 ck(e.image[a-BASE:a-BASE+n]==original[a-BASE:a-BASE+n],f'native shared resolver/custom getters unchanged {a:x}')
for on in [0,1]:
 e.w8(port.FLAG,on)
 for style in range(25):
  e.w8(port.SELECT,style%27);actual=e.call(0x532a9988,0,style)
  e.w8(port.FLAG,0);expected=e.call(0x532a9988,0,style);e.w8(port.FLAG,on)
  ck(actual==expected,f'shared enum icon native even with film={on}, style={style}')
 for bank,icon in [(1,0x15b),(2,0x15c)]:
  ck(e.call(0x532a9b2c,0,bank,14)==icon,f'original custom slot {bank} icon preserved film={on}')

# Native command 0x5328d9ac actually chooses bank and style and serializes the
# response. Only the final response collector is stubbed, not the getters.
response={}
def collect():response[e.reg(1)]=e.reg(2);return 1
e.stubs[0x535837bc]=collect
for on in [0,1]:
 for mode in [0,1,2]:
  for bank in [0,1,2]:
   for style in [11,12,13,14,17,18,21,22]:
    e.w8(port.FLAG,on);e.w8(user+0x44,mode);e.w8(user+0x1c0,bank)
    for off in [0x1c2,0x1c4,0x1c6]:e.w8(user+off,style)
    before=bytes(u.mem_read(user,0x1000));response.clear();e.call(0x5328d9ac,0,0x70009000)
    enabled=on==1 and mode==0
    ck(response=={0:1,1:0 if enabled else bank,2:11 if enabled else style},f'native camera query on/mode/bank/style={on}/{mode}/{bank}/{style}')
    ck(bytes(u.mem_read(user,0x1000))==before,'native queries never rewrite saved recipes')
    # Actual pending full-apply config before the native CameraControl call.
    seed=bytearray((i*37+style)&255 for i in range(0x180));seed[0xb8]=style;seed=bytes(seed);u.mem_write(packet,seed)
    values=[0x70100000+i*0x1000 for i in range(14)]
    values[4]=wrapper;values[6]=packet
    for i,v in enumerate(values):u.reg_write(port.REGS[i],v)
    u.reg_write(UC_ARM_REG_SP,0x600f0000);u.reg_write(UC_ARM_REG_CPSR,0xa0000013)
    u.emu_start(0x53279a08,0x53279a0c,count=5000)
    out=bytearray(seed)
    if enabled:out[0xb8:0xc7]=bytes(iso['neutral']);out[0xcf]=out[0xd0]=4
    ck(bytes(u.mem_read(packet,len(seed)))==out,'only Std control bytes change in actual outgoing packet')
    want=values[:];want[1]=packet
    ck([e.reg(i)for i in range(14)]==want and u.reg_read(UC_ARM_REG_CPSR)==0xa0000013 and u.reg_read(UC_ARM_REG_SP)==0x600f0000,'packet preserves native ABI and flags')
    ck(bytes(u.mem_read(user,0x1000))==before,'packet neutralization never writes UserData')

# The native config builder calls the effective style getter, not the menu's
# radio getter. In still-film mode its result must be Std for all saved banks.
for on in [0,1]:
 for mode in [0,1,2]:
  for bank in [0,1,2]:
   e.w8(port.FLAG,on);e.w8(user+0x44,mode);e.w8(user+0x1c0,bank);e.w8(user+0x57c,bank)
   for off in [0x1c2,0x1c4,0x1c6,0x57e,0x580,0x582]:e.w8(user+off,14)
   ck(e.call(0x53271480,wrapper)==(11 if on and mode==0 else 14),'real config style getter scoped to still FILM')
   e.w8(model+0x1b,mode);e.w8(model+0x1c,2)
   ck(e.call(0x532bd6d4,model)==(0 if on and mode==0 else 2 if mode==2 else bank),'ImageControlModel effective bank scoped to still FILM')
   ck(e.call(0x5326c1cc,wrapper)==(11 if on and mode==0 else 0x17 if bank==1 else 0x18 if bank==2 else 14),'native still display is Std only while still FILM is on')

# Ignoring native edits is limited to the still ImageControlModel. Original
# setters are executed for OFF and movie, rather than discarding their choice.
for on in [0,1]:
 for mode in [0,1]:
  for bank in [0,1,2]:
   e.w8(port.FLAG,on);e.w8(user+0x44,mode);e.w8(model+0x1b,mode)
   e.w8(user+(0x1c0 if mode==0 else 0x57c),bank)
   off=([0x1c2,0x1c4,0x1c6] if mode==0 else [0x57e,0x580,0x582])[bank]
   e.w8(user+off,14);e.call(0x532c26c0,model,12)
   ck(e.byte(user+off)==(14 if on and mode==0 else 12),'native edits blocked only during still-film use')

# RAW-development parameter widgets were misidentified as live HUD in R11.
# Restore that entire path, including both original secondary Std badges.
for a,n in [(0x532891a8,0x98),(0x53186904,0x10),(0x5318a100,0x60)]:
 ck(e.image[a-BASE:a-BASE+n]==original[a-BASE:a-BASE+n],'RAW-development UI path unchanged '+hex(a))
e.stubs[0x5320b67c]=lambda:0x70003000
for on in [0,1]:
 e.w8(port.FLAG,on)
 for bank,icon in [(1,0x15b),(2,0x15c)]:
  ck(e.call(0x532891a8,0x70003000,bank,3)==icon,'RAW-development custom icon independent of live film')

# Execute the ACTUAL top live icon renderer from its original callback. It
# reads the cached display fields a00/a10 and calls the scoped 531710c4 site.
# Native native icon resolvers remain unmodified for menus and playback.
ck(struct.unpack_from('<I',original,0x53b2fa88-BASE)[0]==0x53171064,'original live callback table identifies the actual top renderer')
ctrl=e.alloc(0x600);cache=e.alloc(0x1000);view=e.alloc(0x200);e.w32(ctrl+0x4e8,cache);e.w32(ctrl+0x15c+3*4,view)
log=[]
e.stubs[0x5339a9a0]=lambda:log.append(('icon',e.reg(0),e.reg(1))) or 0
e.stubs[0x533ad3c0]=lambda:log.append(('visible',e.reg(0),e.reg(1))) or 0
for on in [0,1]:
 for look in range(27):
  e.w8(port.FLAG,on);e.w8(port.SELECT,look)
  for request,displayMode,cachedVisible in [(1,0,0),(1,1,0),(1,1,1),(0,0,0),(0,1,1)]:
   for style in [11,14,17]:
    e.w8(ctrl+0x2d1,displayMode);e.w8(cache+0xa10,cachedVisible);e.w8(cache+0xa00,style);log.clear()
    e.call(0x53171064,ctrl,3,request)
    visible=bool(request and (on or displayMode==0 or cachedVisible))
    expected=e.word(m['metadata']['icons']+4*look) if on else e.call(0x532a9b28,0,style)
    ck(log==([('icon',view,expected),('visible',view,1)] if visible else [('visible',view,0)]),'actual top live renderer handles film/native/off and cached Std invisibility')

# Execute the actual native 0x82 callback, not a synthesized tone event. The
# official dispatch table identifies the callback and it must copy our outgoing
# config into both current and pending ShotInfo and enqueue its native event.
ck(struct.unpack_from('<I',original,0x54093030+0x82*8-BASE)[0]==0x5353f124,'native command 0x82 dispatch identity verified')
u.reg_write(UC_ARM_REG_C1_C0_2,0xf00000);u.reg_write(UC_ARM_REG_FPEXC,0x40000000)
backend=e.alloc(0x600);common=e.alloc(0x20);shot=e.alloc(0x1100);events=e.alloc(0x600)
e.w32(backend+0x518,common);e.w32(common+4,shot);e.w32(common+8,events)
def memcpy():
 u.mem_write(e.reg(0),bytes(u.mem_read(e.reg(1),e.reg(2))));return e.reg(0)
e.stubs[0x5313fd80]=memcpy
# Commit/notification delivery is an external camera service, not the native
# copy/event body being tested. No replacement for native parameter writers.
e.stubs[0x5355198c]=lambda:0
for index,(on,look,tone) in enumerate([(1,10,11),(1,11,11),(1,12,11),(0,12,14),(1,12,11),(0,12,17),(0,12,25),(0,12,26)]):
 e.w8(port.FLAG,on);e.w8(port.SELECT,look);e.w8(user+0x44,0)
 seed=bytearray(0x180);seed[0xb8]=tone
 seed[0xb9:0xc7]=bytes([4,4,4,4,4,4,1,4,0,1,4,0,0,0]);seed[0xcf]=seed[0xd0]=4
 u.mem_write(packet,bytes(seed));u.reg_write(UC_ARM_REG_R4,wrapper);u.reg_write(UC_ARM_REG_R6,packet)
 u.reg_write(UC_ARM_REG_SP,0x600f0000);u.ctl_flush_tb();u.emu_start(0x53279a08,0x53279a0c,count=5000)
 applied=bytes(u.mem_read(packet,0x156));e.w8(events,0)
 e.call(0x5353f124,backend,packet,0)
 ck(bytes(u.mem_read(shot+0x6c4,0x156))==applied,'real backend stores current outgoing packet')
 ck(bytes(u.mem_read(shot+0xee4,0x156))==applied,'real backend stores pending outgoing packet')
 ck(e.byte(shot+0x77c)==tone,'real native full-apply style reaches ShotInfo')
 count=e.byte(events);ids=[struct.unpack('<H',u.mem_read(events+2+i*2,2))[0] for i in range(count)]
 ck(0x82 in ids,'native full apply emits redraw event even when Std stays Std')
ck(e.image[0x53558260-BASE:0x53558310-BASE]==original[0x53558260-BASE:0x53558310-BASE],'shared raw-development/native tone event writer unchanged')

report=dict(model='GRIII',status='passed',checks=len(checks),rtosSha256=hashlib.sha256(e.image).hexdigest(),hardwareTested=False,
 nativeQueriesExecuted=True,actualApplyPacketHookExecuted=True,originalCustomResolversUnchanged=True,newCinemaDefaultBranchesOnly=True,actualTopLiveRendererExecuted=True,rawDevelopmentUiUnchanged=True,nativeFullApplyAndEventWriterExecuted=True,
 limitations='External camera services and UI setters are fixtures; no camera hardware execution.')
(R/'native-isolation-checks.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
