# SPDX-License-Identifier: GPL-2.0-only
# ARM checks execute native functions. OS/hardware services are fixtures, not hardware proof.
from pathlib import Path
import sys,types,struct,json,hashlib
R=Path(__file__).resolve().parent;ws=R.parents[1]
if (R.parent/'gr3-cinema-native-r1/python').exists():sys.path.insert(0,str(R.parent/'gr3-cinema-native-r1/python'))
import numpy as np
from unicorn import UC_PROT_READ,UC_PROT_EXEC,UC_HOOK_CODE
from unicorn import arm_const as A
BASE=0x53000000
original=(R/'decoded/GRIII/RTOS.bin').read_bytes();built=(R/'resource-build/GRIII/image.rtos').read_bytes();meta=json.loads((R/'resource-build/GRIII/resources.json').read_text());models=json.loads((R/'cinema-data.json').read_text())['models'];checks=[]
native=R/'test-support/cinema'
module=types.ModuleType('emu');module.__dict__.update(R=original,BASE=BASE,SRC=0x5407b540,DST=0x55000000,LEN=0x3a080,romw=None)
source=(native/'emu.py').read_text().replace('from fw import R, BASE, SRC, DST, LEN, w as romw','')
source=source.replace('u.hook_add(UC_HOOK_CODE, self._code)', 'self.service_hooks = set()').replace('u.hook_add(UC_HOOK_MEM_READ, self._read)', '')
source=source.replace('        u = self.u\n        for i in range(13):', '        u = self.u\n        for adr in ({0x536af2a8,0x536af31c,0x536af2e4,0x536af358,0x536b93d0}|STUB_RET0|set(self.extra_stubs))-self.service_hooks:\n            u.hook_add(UC_HOOK_CODE,self._code,begin=adr,end=adr)\n            self.service_hooks.add(adr)\n        for i in range(13):')
exec(compile(source,str(native/'emu.py'),'exec'),module.__dict__);sys.modules['emu']=module
rt=types.ModuleType('tuning');exec(compile((native/'run_tuning.py').read_text(),str(native/'run_tuning.py'),'exec'),rt.__dict__)
def ck(v,msg):
 assert v,msg
 checks.append(msg)
def setup(img,stage=0):
 e,o,i,s=rt.setup(stage,img);e.u.mem_protect(BASE,(len(img)+65535)&~65535,UC_PROT_READ|UC_PROT_EXEC);return e,o,i,s
def fields(out):
 h=np.frombuffer(out,'<u2');mats=[[int(v) for v in h[272+64*(m//5)+10*(m%5):272+64*(m//5)+10*(m%5)+9]&4095]for m in range(60)]
 return h,mats
# Every stock still/live effect and Cross Process variant must remain byte-identical,
# including after running each Cinema in the same native processor context.
for stage in [0,1]:
 es,os,is_,ss=setup(original,stage);ep,op,ip,sp=setup(built,stage)
 cases=[(t,{})for t in range(11,23)]+[(21,{0x797:k})for k in [1,2,3]]+[(18,{0x786:k})for k in [2,3]]
 def run(e,o,i,s,t,extra):return rt.make(e,o,i,s,t,stage,lambda ee,st:[ee.w8(st+k,v)for k,v in extra.items()])
 for before in [None,25,26]:
  if before:run(ep,op,ip,sp,before,{})
  for t,extra in cases:
   expected=run(es,os,is_,ss,t,extra);actual=run(ep,op,ip,sp,t,extra)
   ck(expected[0x120:0x8000]==actual[0x120:0x8000],f'original ISP restored stage/tone/prior {stage}/{t}/{before}')
 for k,m in enumerate(models):
  tone=25+k;out=run(ep,op,ip,sp,tone,{})
  # First R2Y matrix block equals native Standard with only adapted sensor matrix.
  ref=bytearray(original);ref[0xdc2754:0xdc2766]=struct.pack('<9h',*m['matrix']);er,orr,ir,sr=setup(bytes(ref),stage);reference=run(er,orr,ir,sr,11,{})
  ck(out[0x120:400]==reference[0x120:400],f'Cinema {k} native color matrix stage {stage}')
  gamma=ep.r32(op+0x17c);read=lambda off:np.frombuffer(ep.u.mem_read(gamma+off,512),'<u2').astype(int)
  base=read(0);comp=[read(off)for off in [0x2a08,0x2c08,0x2e08]]
  err=max(float(np.abs(comp[c]-np.interp(np.clip(base/64,0,255),np.arange(256),m['curves'][c])).max())for c in range(3))
  ck(err<=2,f'Cinema {k} exact default curves stage {stage}: max quantization error {err}')
  h,mats=fields(out)
  ck(mats==[[v&4095 for v in m['multi'][j*9:j*9+9]]for j in range(60)],f'Cinema {k} all 60 original sector matrices stage {stage}')
  ck(list(map(int,h[224:240]&4095))==m['bounds'],f'Cinema {k} original sector boundaries stage {stage}')
  ck(out[0x120:0x8000]!=run(es,os,is_,ss,11,{})[0x120:0x8000],f'Cinema {k} affects actual native ISP stage {stage}')
 ck(not ep.asserts and not es.asserts,f'no native processing assertions stage {stage}')
 print('Native still/live color stage',stage,'passed',len(checks),flush=True)
# Film ON must own the full pipeline even after either native Cinema.
for stage in [0,1]:
 e,o,i,si=setup(built,stage);e.call(meta['preferences']['init'])
 for look in range(27):
  e.w8(0x5503a095,1);e.w8(0x5503a094,look)
  ref=rt.make(e,o,i,si,11,stage)
  for tone in [25,26]:
   actual=rt.make(e,o,i,si,tone,stage)
   ck(actual[0x120:0x8000]==ref[0x120:0x8000],f'film owns pipeline stage/look/Cinema {stage}/{look}/{tone}')
  e.w8(0x5503a095,0)
  for tone in [25,26]:
   restored=rt.make(e,o,i,si,tone,stage)
   clean,co,ci,cs=setup(built,stage);want=rt.make(clean,co,ci,cs,tone,stage)
   ck(restored[0x120:0x8000]==want[0x120:0x8000],f'film OFF restores native Cinema {stage}/{look}/{tone}')
 ck(not e.asserts,f'film/Cinema native switching no assertions {stage}')
 print('Film/Cinema isolation stage',stage,'passed',len(checks),flush=True)
report=dict(status='passed',hardwareTested=False,rtosSha256=hashlib.sha256(built).hexdigest(),checks=len(checks),nativeProcessingStages=[0,1],notes='Native ARM paths execute. Hardware and source-color matching remain unverified.')
(R/'cinema-colour-checks.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
