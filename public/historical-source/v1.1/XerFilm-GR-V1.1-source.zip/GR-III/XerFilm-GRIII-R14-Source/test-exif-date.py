# SPDX-License-Identifier: GPL-2.0-only
# Cross-check the same per-shot fields with ACTUAL native JPEG MakerNote
# Date/Time writers, then run the native JPEG entry and timestamp renderer.
# Live RTC/CPU services are deliberately unavailable (the R9 mapping was wrong).
from pathlib import Path
import struct,json,hashlib,importlib.util
from unicorn import UC_HOOK_CODE
from unicorn.arm_const import *
R=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('port',R/'test-port.py');mod=importlib.util.module_from_spec(s);s.loader.exec_module(mod)
e=mod.Emu('GRIII');u=e.u;m=e.m;checks=[]
def ck(v,msg):assert v,msg;checks.append(msg)
def forbidden():raise AssertionError('Timestamp attempted to read misidentified live CPU/power service')
e.stubs.update({0x5356e588:forbidden,0x53571d90:forbidden,0x53572ca4:forbidden,0x5383c870:lambda:0})
written=[]
def nativeWrite():written.append(bytes(u.mem_read(e.reg(1),e.reg(2))));return 0
e.stubs[0x535d034c]=nativeWrite
u.hook_del(e.hookHandle)
for a in e.stubs:u.hook_add(UC_HOOK_CODE,e.hook,begin=a,end=a)
# Prove the old 'DateTime' RTTI is PowerSourceInfo, rather than inventing a
# synthetic date to fill that unrelated 20-byte structure.
native=(R/'decoded/GRIII/RTOS.bin').read_bytes();B=0x53000000
vt=struct.unpack_from('<I',native,0x572ce0)[0];ti=struct.unpack_from('<I',native,vt-B-4)[0];nameptr=struct.unpack_from('<I',native,ti-B+4)[0];name=native[nameptr-B:].split(b'\0',1)[0].decode()
ck('PowerSourceInfo'in name,'old callback type is PowerSourceInfo, not a clock')
ck(e.word(m['stamp']['ctx']+12)==0,'JPG module has no live platform dependency')
e.call(m['preferences']['init'])
W,H,S=320,214,352;SZ=H*S;Y,C,RAW,PY,PC=0x70800000,0x70900000,0x70a00000,0x70b00000,0x70c00000
CFG,D,SHOT,PKT,TAG,OUT=0x70008000,0x70009000,0x7000a000,0x7000f000,0x7000f200,0x7000e000
proof=json.loads((R/'stamp-research/module-proof.json').read_text());layout=m['stamp']['code']+proof['symbols']['layout'];runs=[]
def glyphs(u,a,size,data):runs.append(bytes(u.mem_read(e.reg(0),e.reg(1))))
u.hook_add(UC_HOOK_CODE,glyphs,begin=layout,end=layout)
text=lambda g:''.join(str(x)if x<10 else{17:' ',18:'.',19:':'}.get(x,'?')for x in g)
for year in [1999,2000,2026]:
 for mode in range(1,6):
  for look in [0,10]:
   runs.clear();written.clear();e.time=struct.pack('<H6B',year,10,20,11,43,22,0)+bytes(8)
   for a,v in [(Y,100),(C,128),(RAW,57),(PY,110),(PC,128)]:u.mem_write(a,bytes([v])*SZ)
   u.mem_write(D,struct.pack('<B3xIII HHHH HH 4x',1,Y,C,0,W,H,S,H,0,0));e.w32(CFG+0x34,SHOT);e.w32(CFG+0x3c,D);e.w32(PKT+8,CFG)
   u.mem_write(SHOT,bytes(4096));e.attach(SHOT,look,1,0,mode)
   # Real native Date and Time entry helpers both read immutable ShotInfo.
   e.call(0x535c3f84,0,TAG,SHOT);e.call(0x535c405c,0,TAG,SHOT)
   ck(written==[struct.pack('>H2B',year,10,20),bytes([11,43,22])],'native photo metadata Date/Time matches captured fixture')
   u.mem_write(OUT-16,b'\x5a'*16+bytes(16)+b'\xa5'*16);e.call(m['stamp']['shotDate'],SHOT,OUT)
   ck(bytes(u.mem_read(OUT,6))==struct.pack('<H4B',year,10,20,11,43),'stamp uses same date as native photo metadata')
   ck(bytes(u.mem_read(OUT-16,16))==b'\x5a'*16 and bytes(u.mem_read(OUT+16,16))==b'\xa5'*16,'output buffer canaries intact')
   shot=bytes(u.mem_read(SHOT,4096));before={a:bytes(u.mem_read(a,SZ))for a in [Y,C,RAW,PY,PC]}
   # Live preference/clock time changes after exposure must not alter its date.
   e.time=struct.pack('<H6B',2030,1,1,0,1,0,0)+bytes(8);e.w8(mod.SELECT,7);e.w8(mod.FLAG,0)
   e.call(0x535047d4,0x7000f100,PKT,until=0x535047d8,limit=16000000)
   ck(bytes(u.mem_read(Y,SZ))!=before[Y],'timestamp drawn through native JPEG entry without any live service')
   yy=f'{year%100:02}';expected={1:[f'{yy}.10.20 11:43']*2,2:[f'20.10 11:43 {yy}']*2,3:[f'{yy}.10.20']*2,4:['11:43']*2,5:[f'{yy}.10.20']*2+['11:43']*2}[mode]
   ck([text(x)for x in runs]==expected,'correct format, modulo100 year and exposure date')
   ck(all(bytes(u.mem_read(a,SZ))==before[a]for a in [RAW,PY,PC]),'RAW/shared previews unchanged')
   ck(bytes(u.mem_read(SHOT,4096))==shot,'native photo metadata left read-only')
   if look==10:ck(bytes(u.mem_read(C,SZ))==before[C],'BW film uses neutral ink')
report=dict(status='passed',checks=len(checks),rtosSha256=hashlib.sha256(e.image).hexdigest(),hardwareTested=False,nativePhotoDateWriterExecuted=True,nativePhotoTimeWriterExecuted=True,jpegEntryExecuted=True,powerSourceInfoTypeVerified=name,liveClockAccessForbidden=True,limitations='ShotInfo is a fixture; physical cache/OS are doubles. Hardware testing is pending.')
(R/'exif-date-checks.json').write_text(json.dumps(report,indent=2));print(report)
