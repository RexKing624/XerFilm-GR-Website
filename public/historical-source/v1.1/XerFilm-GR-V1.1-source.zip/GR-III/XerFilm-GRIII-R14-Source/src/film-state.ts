// SPDX-License-Identifier: GPL-2.0-only
// Single family/processing identity adapter shared by ADJ and settings.
import {Patch,u32le} from './build';
import {assembleWords} from './arm';
import {installFilmPreview} from './film-preview';
import {FILM_COUNT,FILM_LOOK_COUNT,FILM_FAMILIES,FILM_LOOK_FAMILIES,FILM_FAMILY_ICONS} from './catalog';
const SELECT=0x5503a094,FLAG=0x5503a095;
const addr=(r:string,a:number)=>`movw ${r},#${a&65535};movt ${r},#${a>>>16};`;
const installed=new WeakMap<Patch,ReturnType<typeof create>>();
function create(p:Patch){
 const fn=(s:string)=>p.append(a=>assembleWords(s,a),16),preview=installFilmPreview(p);
 const parents=p.append(Uint8Array.from(FILM_LOOK_FAMILIES),4),defaults=p.append(Uint8Array.from(FILM_FAMILIES.map(f=>f.first)),4),icons=p.append(u32le([...FILM_FAMILY_ICONS]),4);
 const get=fn(`${addr('r2',SELECT)}ldrb r0,[r2];cmp r0,#${FILM_LOOK_COUNT-1};movhi r0,#0;strbhi r0,[r2];${addr('r3',parents)}ldrb r0,[r3,r0];bx lr`);
 const current=fn(`${addr('r2',FLAG)}ldrb r2,[r2];cmp r2,#1;movne r0,#0;bxne lr;push {r4,lr};mov r4,r1;bl #${get};cmp r0,r4;moveq r0,#1;movne r0,#0;pop {r4,pc}`);
 // The OFF sentinel changes the shared switch only. Retain the selected child,
 // enabled-family mask and configured grain level so ON can restore them.
 // Re-enabling the same family still applies once, even if its child is unchanged.
 const set=fn(`cmn r1,#1;beq off;cmp r1,#${FILM_COUNT-1};bxhi lr;push {r4,r5,r6,lr};mov r4,r1;mov r5,#0;bl #${get};cmp r0,r4;beq enable;
  ${addr('r2',defaults)}ldrb r1,[r2,r4];${addr('r2',SELECT)}strb r1,[r2];mov r5,#1;
  enable:${addr('r2',FLAG)}ldrb r0,[r2];cmp r0,#1;movne r5,#1;mov r1,#1;strb r1,[r2];cmp r5,#0;blne #${preview};pop {r4,r5,r6,pc};
  off:push {r4,lr};${addr('r2',FLAG)}ldrb r0,[r2];mov r1,#0;strb r1,[r2];cmp r0,#1;bleq #${preview};pop {r4,pc}`);
 const icon=fn(`cmp r0,#${FILM_COUNT-1};movhi r0,#0;${addr('r3',icons)}ldr r0,[r3,r0,lsl #2];bx lr`);
 return {get,current,set,icon,preview};
}
export function installFilmState(p:Patch){const old=installed.get(p);if(old)return old;const value=create(p);installed.set(p,value);return value;}
