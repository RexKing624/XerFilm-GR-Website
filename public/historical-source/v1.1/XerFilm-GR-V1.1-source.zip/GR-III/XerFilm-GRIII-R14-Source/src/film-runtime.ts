// SPDX-License-Identifier: GPL-2.0-only
// GR III/IIIx processing adapter. All stock resources and RAW data stay intact.
import {Patch,fn,addr,u32le,u16le,concat,expectWord,branch} from './build';
import {FLAG,SELECT} from './preferences';
import {FILM_MODELS,FILM_HUD_ICONS} from './catalog';
import {installFilmCapture} from './film-capture';
import {installNativeIsolation} from './film-native-isolation';
import cinema from '../cinema-data.json';
import native from '../processing-facts.json';
import ma from '../ma-controls.json';
const installed=new WeakMap<Patch,ReturnType<typeof create>>();
function create(p:Patch){
 const capture=installFilmCapture(p);
 // Snapshot identity when available; live preferences only for a preview buffer.
 const look=fn(p,`push {r4,lr};bl #${capture.lookup};cmp r0,#0;beq live;tst r0,#0x80000000;beq off;mov r0,r0,lsr #24;and r0,r0,#31;cmp r0,#26;bhi off;pop {r4,pc};live:${addr('r2',FLAG)}ldrb r2,[r2];cmp r2,#1;bne off;${addr('r2',SELECT)}ldrb r0,[r2];cmp r0,#26;movhi r0,#0;pop {r4,pc};off:mvn r0,#0;pop {r4,pc}`);
 const bounds=p.append(u16le(ma.bounds),4),block=new Uint8Array(72);block.set(ma.selectors);block.set(u16le(ma.control),20);const control=p.append(block,4);
 const models=FILM_MODELS.map((m,i)=>({matrix:p.append(m.matrix,4),multi:p.append(m.multi,4),gamma:[0,1,2].map(c=>p.append(m.gamma.slice(c*512,c*512+512),4))}));
 // GR IV's fitted look is relative to its Standard look. Convert that relative
 // transform onto the GR III Standard look; retain the GR III sensor basis.
 const inv=native.inverseIVStandard,three=native.iiiStandard;
 for(const[m,i]of FILM_MODELS.map((m,i)=>[m,i] as const)){
  const q=new DataView(m.matrix.buffer,m.matrix.byteOffset,m.matrix.byteLength),a=Array.from({length:9},(_,j)=>q.getInt16(j*2,true)/8192);
  const mul=(a:number[],b:number[])=>Array.from({length:9},(_,j)=>[0,1,2].reduce((s,k)=>s+a[Math.floor(j/3)*3+k]*b[k*3+j%3],0));
  const out=mul(mul(a,inv),three).map(v=>Math.round(v*8192));if(out.some(v=>v< -32768||v>32767))throw Error('GR III look matrix overflow');p.write(models[i].matrix,u16le(out.map(v=>v&65535)));
 }
 const filmCount=models.length;
 const cinemaControls=cinema.models.map(m=>{const b=p.append(u16le(m.bounds),4),a=new Uint8Array(72);a.set(m.selectors);a.set(u16le(m.control),20);return{bounds:b,control:p.append(a,4)};});
 models.push(...cinema.models.map(m=>({matrix:p.append(u16le(m.matrix.map(v=>v&65535)),4),multi:p.append(u32le(m.multi),4),gamma:m.curves.map(c=>p.append(u16le(c),4))})));
 const matrixRecords=models.map(m=>{const b=p.readMapped(p.mappedWord(0x55018d94+44),84);new DataView(b.buffer).setUint32(4,m.matrix,true);return p.append(b,4);});
 const sets=p.append(u32le(models.flatMap((m,i)=>{const c=i<filmCount?{bounds,control}:cinemaControls[i-filmCount];return[c.bounds,c.control,0x55019828,0x55019848,c.control+20,0x53dc3a40,m.multi,i];})),16);
 const matrixTable=p.append(u32le(matrixRecords),4),gammaTable=p.append(u32le(models.flatMap(m=>m.gamma)),4);
 const ctxLook=fn(p,`ldr r0,[r0,#12];${addr('r2',sets)}sub r0,r0,r2;tst r0,#31;bne missing;mov r0,r0,lsr #5;cmp r0,#29;bxlo lr;missing:mvn r0,#0;bx lr`);
 // Actual resource selection receives the ShotInfo pointer r7; each exposure
 // remains tied to its own saved look if the UI changes before encoding ends.
 for(const[site,word,dest,table,kind]of [[0x536dc2a0,0xe790e101,'lr',matrixTable,'matrix'],[0x536dc2b0,0xe79cc101,'ip',sets,'multi']] as const){
  expectWord(p,site,word);
  const original=`ldr r2,[sp,#${kind==='matrix'?8:24}];ldr r3,[sp,#12];ldr ${dest},[r2,r3,lsl #2]`;
  const get=fn(p,`push {r0,r1,r2,r3,ip,lr};mrs r3,cpsr;push {r3,r4};mov r0,r7;bl #${look};cmn r0,#1;beq original;${addr('r2',table)}${kind==='matrix'?'ldr r0,[r2,r0,lsl #2]':'add r0,r2,r0,lsl #5'};str r0,[sp,#${dest==='lr'?28:24}];b done;original:${original};str ${dest},[sp,#${dest==='lr'?28:24}];done:pop {r3,r4};msr cpsr_f,r3;pop {r0,r1,r2,r3,ip,lr};b #${site+4}`);
  p.setWord(site,branch(site,get),'film GR III snapshot resource '+kind);
 }
 // Multi-axial hardware writer: native selector/control setup, followed by the
 // complete fitted 12 sectors × 5 levels, preserving upper register bits.
 expectWord(p,0x536e4470,0xe1a0c00d);
 const multi=fn(p,`push {r4,r5,r6,r7,r8,r9,r10,lr};mov r4,r0;mov r5,r1;mov r6,r2;bl #0x536df484;mov r0,r4;mov r1,r6;bl #0x536df55c;mov r0,r5;bl #${ctxLook};cmn r0,#1;beq done;ldr r3,[r5,#12];ldr r8,[r3,#24];movw r10,#4095;add r6,r6,#256;mov r7,#12;sector:mov r4,#0;level:add r0,r4,r4,lsl #2;add r0,r6,r0,lsl #2;mov r5,#0;element:ldr r2,[r8],#4;and r2,r2,r10;add r3,r0,r5,lsl #1;ldrh ip,[r3];bic ip,ip,r10;orr ip,ip,r2;strh ip,[r3];add r5,r5,#1;cmp r5,#9;blo element;add r4,r4,#1;cmp r4,#5;blo level;add r6,r6,#128;subs r7,r7,#1;bne sector;done:pop {r4,r5,r6,r7,r8,r9,r10,pc}`);
 p.setWord(0x536e4470,branch(0x536e4470,multi),'GR III full fitted multi-axis coefficients');
 // GR III composites per-channel curves through its native Gamma object.
 // Identify a film by its context-owned set, without touching SI+0x38a98 or RAW.
 expectWord(p,0x536e8694,0xe5d4309b);
 const gammaGate=fn(p,`push {r0,r1,r2,lr};mrs r1,cpsr;push {r1,r4};mov r0,r4;bl #${ctxLook};cmn r0,#1;movne r3,#1;ldrbeq r3,[r4,#0x9b];pop {r1,r4};msr cpsr_f,r1;pop {r0,r1,r2,lr};b #0x536e8698`);p.setWord(0x536e8694,branch(0x536e8694,gammaGate),'film Gamma composite gate, context scoped');
 expectWord(p,0x536e87c4,0xeb001989);
 const gamma=fn(p,`push {r4,r5,r6,r7,r8,lr};mov r5,r0;mov r6,r1;mov r7,r2;mov r8,r3;mov r0,r4;bl #${ctxLook};cmn r0,#1;beq original;mov r1,#12;mul r0,r1,r0;${addr('r1',gammaTable)}add r1,r1,r0;ldr r2,[r1];str r2,[r6];ldr r2,[r1,#4];str r2,[r7];ldr r2,[r1,#8];str r2,[r8];pop {r4,r5,r6,r7,r8,pc};original:mov r0,r5;mov r1,r6;mov r2,r7;mov r3,r8;bl #0x536eedf0;pop {r4,r5,r6,r7,r8,pc}`);
 p.setWord(0x536e87c4,branch(0x536e87c4,gamma,true),'context-owned fitted RGB curves');
 // Force a native full refresh only when the per-processor look changes.
 expectWord(p,0x536db118,0xe5c4520d);const init=fn(p,'push {r2,r3};movw r3,#65535;add r2,r4,#512;strh r3,[r2,#14];pop {r2,r3};strb r5,[r4,#0x20d];b #0x536db11c');p.setWord(0x536db118,branch(0x536db118,init),'initialize GR III processor look identity');
 expectWord(p,0x536dcf84,0xe5d4220d);const refresh=fn(p,`push {r0,r1,r3,ip,lr};mrs r1,cpsr;push {r1,r4,r5};ldr r0,[fp,#-48];ldr r0,[r0,#0x2d0];bl #${look};add r0,r0,#1;add r3,r4,#512;ldrh r2,[r3,#14];cmp r2,r0;strhne r0,[r3,#14];ldrb r2,[r4,#0x20d];orrne r2,r2,#1;pop {r1,r4,r5};msr cpsr_f,r1;pop {r0,r1,r3,ip,lr};b #0x536dcf88`);p.setWord(0x536dcf84,branch(0x536dcf84,refresh),'look identity participates in native processing refresh');
 // Scoped inline reads never overwrite the original ShotInfo or user controls.
 const reads=[];
 for(const r of native.toneReads){
  // This read compares the OLD stored style inside SetImageTone. Virtualizing
  // it can skip a real state change. Only processing/getter reads are virtual.
  if(r.site===0x53558274||(r.site>=0x53590000&&r.site<0x53610000))continue;
  reads.push({...r,value:11});
 }
 reads.push(...native.neutralReads);
 for(const {site,word,rn,rd,offset,value} of reads){
  expectWord(p,site,word);
  if(rn>12||(rd>12&&rd!==14))throw Error('Unexpected GR III parameter register');
  const hook=fn(p,`push {r0,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,ip,lr};mrs r3,cpsr;push {r3,r4};ldr r0,[sp,#${8+rn*4}];bl #${look};cmn r0,#1;movne r2,#${value};bne result;ldr r0,[sp,#${8+rn*4}];ldrb r2,[r0,#${offset}];result:str r2,[sp,#${8+(rd===14?13:rd)*4}];pop {r3,r4};msr cpsr_f,r3;pop {r0,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,ip,lr};b #${site+4}`);
  p.setWord(site,branch(site,hook),'film virtual GR III parameter read');
 }
 // Film uses neutral native shading/clarity and JPG-only software grain.
 // Suppress the stock effect stage so a previously selected native Monotone
 // cannot layer its own grain or shading over the independent film look.
 expectWord(p,0x535131c0,0xe5d1377c);
 const effectGate=fn(p,`push {r0,r1,r2,r3,ip,lr};mrs ip,cpsr;push {r4,ip};mov r4,r0;mov r0,r1;bl #${look};cmn r0,#1;beq native;mov r3,#0;strb r3,[r4,#0x24];pop {r4,ip};msr cpsr_f,ip;pop {r0,r1,r2,r3,ip,lr};bx lr;native:pop {r4,ip};msr cpsr_f,ip;pop {r0,r1,r2,r3,ip,lr};ldrb r3,[r1,#0x77c];b #0x535131c4`);
 p.setWord(0x535131c0,branch(0x535131c0,effectGate),'film isolates native shading/clarity/grain stage');
 const isolation=installNativeIsolation(p),{effective,blockNative}=isolation;
 return {filmCount,cinemaControls,effectGate,look,ctxLook,sets,models,matrixRecords,matrixTable,gammaTable,multi,gamma,gammaGate,refresh,init,effective,blockNative,isolation,reads};
}
export function installRuntime(p:Patch){const old=installed.get(p);if(old)return old;const out=create(p);installed.set(p,out);return out;}
