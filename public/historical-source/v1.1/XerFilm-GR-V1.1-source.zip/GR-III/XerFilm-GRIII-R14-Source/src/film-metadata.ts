// SPDX-License-Identifier: GPL-2.0-only
// Per-exposure identity is written only by the ordinary JPEG-owned setter.
import {Patch,fn,addr,u32le,expectWord,branch} from './build';
import {FLAG,SELECT} from './preferences';
import {FILM_HUD_ICONS} from './catalog';
import {installFilmCapture} from './film-capture';
export function installFilmMetadata(p:Patch){
 const capture=installFilmCapture(p),icons=p.append(u32le(FILM_HUD_ICONS),4);
 // Pentax setter vtable offset-to-top / RTTI / complete native virtual entries.
 expectWord(p,0x53d31374,0x53606738);
 const dispatch=fn(p,`push {r0,r1,r2,r3,ip,lr};mrs ip,cpsr;push {r4,ip};ldrh r3,[r1,#4];cmp r3,#0x4f;bne native;ldr r0,[r0,#0x18];bl #${capture.lookup};tst r0,#0x80000000;beq native;mov r4,r0,lsr #24;and r4,r4,#31;cmp r4,#26;bhi native;ldr r0,[sp,#12];bl #0x535d02f4;ldr r0,[sp,#12];mov r1,#0;movw r2,#0x8200;add r2,r2,r4;bl #0x535d02c8;pop {r4,ip};msr cpsr_f,ip;pop {r0,r1,r2,r3,ip,lr};mov r0,#1;bx lr;native:pop {r4,ip};msr cpsr_f,ip;pop {r0,r1,r2,r3,ip,lr};b #0x53606738`);
 const words=Array.from({length:11},(_,i)=>p.word(0x53d31358+4*i));words[7]=dispatch;const vt=p.append(u32le(words),4)+8;
 expectWord(p,0x53600fbC,0x53d31040);expectWord(p,0x53600f84,0xe2840e23);expectWord(p,0x53600f88,0xeb000bfB);expectWord(p,0x53600f8c,0xe5845258);
 const own=fn(p,`${addr('r3',vt)}str r3,[r4,#0x230];str r5,[r4,#0x258];b #0x53600f90`);p.setWord(0x53600f8c,branch(0x53600f8c,own),'ordinary JPEG owns film identity setter; DNG/movie untouched');
 // Decode its actual MakerNote tag into Standard for native ShotInfo, and a
 // separate property128..154 for the current photo's INFO identity.
 expectWord(p,0x535bf7c4,0xe2400c01);const decodeShot=fn(p,'movw r3,#0x8200;sub r3,r0,r3;cmp r3,#26;movls r3,#11;bls #0x535bf7e4;sub r0,r0,#0x100;b #0x535bf7c8');p.setWord(0x535bf7c4,branch(0x535bf7c4,decodeShot),'read film JPEG as native Standard plus private identity');
 expectWord(p,0x535c2508,0xe2400c01);const decodeProperty=fn(p,'movw r3,#0x8200;sub r3,r0,r3;cmp r3,#26;bhi native;add r2,r3,#128;mov r1,#0x25;b #0x535c2528;native:movw r3,#268;sub r3,r0,r3;cmp r3,#1;bhi stock;add r2,r3,#160;mov r1,#0x25;b #0x535c2528;stock:sub r0,r0,#0x100;b #0x535c250c');p.setWord(0x535c2508,branch(0x535c2508,decodeProperty),'decode current JPEG film property');
 expectWord(p,0x532b44d8,0xe2400001);const property=fn(p,'sub r3,r0,#128;cmp r3,#26;bhi native;add r3,r3,#64;cmp r4,#0;b #0x532b44f4;native:sub r3,r0,#160;cmp r3,#1;bhi stock;add r3,r3,#96;cmp r4,#0;b #0x532b44f4;stock:sub r0,r0,#1;b #0x532b44dc');p.setWord(0x532b44d8,branch(0x532b44d8,property),'photo-owned display identity, independent of live selection');
 expectWord(p,0x532b6f34,0xe2433008);const infoIcon=fn(p,`push {r2};sub r2,r3,#64;cmp r2,#26;bhi native;${addr('r0',icons)}ldr r0,[r0,r2,lsl #2];pop {r2};b #0x532b6f54;native:sub r2,r3,#96;cmp r2,#1;bhi stock;movw r0,#858;add r0,r0,r2;pop {r2};b #0x532b6f54;stock:pop {r2};sub r3,r3,#8;b #0x532b6f38`);p.setWord(0x532b6f34,branch(0x532b6f34,infoIcon),'INFO: current JPEG packaging icon');
 expectWord(p,0x532b7d0c,0xe2422008);const infoRows=fn(p,'push {r3};sub r3,r2,#64;cmp r3,#26;movls r2,#11;sub r3,r2,#96;cmp r3,#1;movls r2,#11;pop {r3};sub r2,r2,#8;b #0x532b7d10');p.setWord(0x532b7d0c,branch(0x532b7d0c,infoRows),'INFO film parameter layout uses Standard');
 // The actual top shooting icon is 53171064 -> 532a9b28. The old R11
 // 532891a8 route belonged to RAW-development parameter views, not live HUD.
 // Keep every shared resolver AND every RAW-development widget unchanged.
 expectWord(p,0x531710c4,0xeb04e297);
 const hud=fn(p,`push {r1,r2,r3,lr};mrs r2,cpsr;${addr('r3',FLAG)}ldrb r3,[r3];cmp r3,#1;bne native;${addr('r3',SELECT)}ldrb r0,[r3];cmp r0,#26;movhi r0,#0;${addr('r3',icons)}ldr r0,[r3,r0,lsl #2];msr cpsr_f,r2;pop {r1,r2,r3,pc};native:msr cpsr_f,r2;pop {r1,r2,r3,lr};b #0x532a9b28`);
 p.setWord(0x531710c4,branch(0x531710c4,hud,true),'live shooting top icon callsite only: current film and child');
 // Respect display-off requests, but an enabled film owns this top slot even
 // when the native Std icon's cached per-mode visibility flag is zero.
 expectWord(p,0x53171080,0x0a000006);
 const hudVisibility=fn(p,`beq #0x531710a0;push {r2,r3};mrs r2,cpsr;${addr('r3',FLAG)}ldrb r3,[r3];cmp r3,#1;beq film;msr cpsr_f,r2;pop {r2,r3};b #0x53171084;film:msr cpsr_f,r2;pop {r2,r3};b #0x531710b4`);
 p.setWord(0x53171080,branch(0x53171080,hudVisibility),'live film icon bypasses native Std visibility suppression');
 return {vt,dispatch,own,decodeShot,decodeProperty,property,infoIcon,infoRows,hud,icons,hudVisibility};
}
