// SPDX-License-Identifier: GPL-2.0-only
// Mutable records MUST NOT live in the read-only RTOS image (v18/v19 defect).
// A boot-zeroed pointer in verified .data alignment padding owns one bounded
// native-allocator RAM block. No native ShotInfo/user-record bytes are added.
import {Patch,expectWord} from './build';
import {assembleWords} from './arm';
import {CAPTURE_PUBLISH,CAPTURE_INCREMENT} from './film-capture-atomic';
export const FILM_CAPTURE_ROOT=0x5503a09c;
const installed=new WeakMap<Patch,{lookup:number,attach:number,root:number,ensure:number}>();
const addr=(r:string,a:number)=>`movw ${r},#${a&65535};movt ${r},#${a>>>16};`;
const branch=(a:number,b:number)=>{const d=(b-a-8)>>2;if(d< -0x800000||d>0x7fffff)throw Error('capture branch range');return(0xea000000|(d&0xffffff))>>>0;};
export function installFilmCapture(p:Patch){
 const old=installed.get(p);if(old)return old;
 const fn=(s:string)=>p.append(a=>assembleWords(s,a),16),slots=128,bytes=16+slots*16;
 const publish=p.append(CAPTURE_PUBLISH,16),increment=p.append(CAPTURE_INCREMENT,16);
 // Native allocator domain2 must already exist. Unknown/early boot or failed
 // allocation returns null: native constructor/bind still executes normally.
 // Racing initializers publish by exclusive CAS; the loser frees only its own
 // unpublished allocation. The published block lives until camera power-off.
 const ensure=fn(`push {r4,r5,r6,lr};${addr('r6',FILM_CAPTURE_ROOT)}ldr r0,[r6];cmp r0,#0;bne done;
  ${addr('r0',0x5536c7c0)}ldr r0,[r0];cmp r0,#0;beq done;
  movw r0,#${bytes};bl #0x536af2a8;cmp r0,#0;beq done;mov r4,r0;
  mov r1,r0;mov r2,#0;movw r3,#${bytes/4};zero:str r2,[r1],#4;subs r3,r3,#1;bne zero;
  mov r0,r6;mov r1,r4;bl #${publish};mov r5,r0;cmp r0,r4;beq done;
  mov r0,r4;bl #0x536af2e4;mov r0,r5;
  done:pop {r4,r5,r6,pc}`);
 // Lookup is allocation-free and preserves ip/callee-saved registers: inline
 // grain wrappers keep NZCV in ip while querying immutable shot preferences.
 const lookup=fn(`cmp r0,#0;beq missing;${addr('r1',FILM_CAPTURE_ROOT)}ldr r1,[r1];cmp r1,#0;beq missing;
  dmb ish;add r1,r1,#16;mov r2,#${slots};
  loop:ldr r3,[r1];cmp r3,r0;beq found;add r1,r1,#16;subs r2,r2,#1;bne loop;
  missing:mov r0,#0;bx lr;
  found:dmb ish;ldr r2,[r1,#4];dmb ish;ldr r3,[r1];cmp r3,r0;moveq r0,r2;movne r0,#0;bx lr`);
 const attach=fn(`cmp r0,#0;bxeq lr;push {r4,r5,r6,r7,r8,lr};mov r4,r0;
  ${addr('r5',FILM_CAPTURE_ROOT)}ldr r8,[r5];cmp r8,#0;bne ready;
  ${addr('r7',0x5503a090)}ldrb r3,[r7,#5];cmp r3,#1;bne done;
  bl #${ensure};cmp r0,#0;beq done;mov r8,r0;
  ready:dmb ish;add r5,r8,#16;mov r6,#${slots};
  scan:ldr r3,[r5];cmp r3,r4;beq slot;add r5,r5,#16;subs r6,r6,#1;bne scan;
  mov r0,r8;bl #${increment};and r6,r0,#127;add r5,r8,#16;add r5,r5,r6,lsl #4;
  slot:mov r3,#0;str r3,[r5];dmb ish;
  ${addr('r7',0x5503a090)}ldrb r6,[r7,#0];ldrb r3,[r7,#1];orr r6,r6,r3,lsl #8;ldrb r3,[r7,#2];orr r6,r6,r3,lsl #16;
  ldrb r3,[r7,#4];cmp r3,#26;movhi r3,#0;orr r6,r6,r3,lsl #24;
  ldrb r3,[r7,#5];cmp r3,#1;orreq r6,r6,#0x80000000;str r6,[r5,#4];dmb ish;str r4,[r5];
  done:pop {r4,r5,r6,r7,r8,pc}`);
 // Processing jobs and their ShotInfo buffers are allocated/rebound ahead of
 // the next exposure. Capturing preferences there records the PREVIOUS look.
 // Freeze them at the native per-shot date/identity capture instead, before
 // that shot is queued. Later pool constructor/bind operations remain native
 // and cannot overwrite the exposure's immutable preferences.
 expectWord(p,0x5346afec,0xe1a0c00d);
 expectWord(p,0x5346b004,0xebffffc4); // native shot date snapshot
 expectWord(p,0x5346b010,0xebfffedc); // native shot serial/identity snapshot
 const shot=fn(`push {r0,r1,r2,r3,ip,lr};mrs ip,cpsr;push {r4,ip};mov r0,r1;bl #${attach};pop {r4,ip};msr cpsr_f,ip;pop {r0,r1,r2,r3,ip,lr};mov ip,sp;b #0x5346aff0`);
 p.setWord(0x5346afec,branch(0x5346afec,shot),'film: freeze preferences with native per-exposure date/identity, never at pool allocation');
 const out={lookup,attach,root:FILM_CAPTURE_ROOT,ensure};installed.set(p,out);return out;
}
