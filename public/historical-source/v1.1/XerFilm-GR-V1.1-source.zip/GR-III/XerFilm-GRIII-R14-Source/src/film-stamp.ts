// SPDX-License-Identifier: GPL-2.0-only
// JPG-only grain + timestamp. Original DNG/RAW processors and buffers unchanged.
import {Patch,fn,addr,u32le,expectWord,branch} from './build';
import {installFilmCapture} from './film-capture';
import {FILM_STAMP_CODE,FILM_STAMP_CODE_LENGTH} from './film-stamp-code';
export function installFilmStamp(p:Patch){
 const capture=installFilmCapture(p),site=0x535047d4;
 expectWord(p,site,0xe1a0c00d);expectWord(p,site+4,0xe92ddff0);expectWord(p,site+24,0xe5914008);
 // Both native job builders store ShotInfo at config+34 and main YCbCr at +3c.
 for(const[a,w]of [[0x5350e6b4,0xe59114c8],[0x5350e6c4,0xe5841938],[0x5350e6dc,0xe584c940],[0x5350ea70,0xe59224c8],[0x5350ea7c,0xe58429ec],[0x5350ea8c,0xe58419f4],[0x536bbc30,0xe30d01b4],[0x536bbcac,0xe1a00001],[0x536bbcc0,0xe1a0c00d]])expectWord(p,a,w);
 // 536bbcac is INVALIDATE, not CLEAN: its tail target 5383c834 eventually
 // executes DCIMVAC (c7,c6,1), discarding our dirty pixels before JPEG DMA.
 // Use the native range CLEAN service instead (operation1 -> DCCMVAC).
 // Keep its full native locking/range/large-buffer handling; adapt only ABI.
 expectWord(p,0x5383c870,0xe1a0c00d);expectWord(p,0x5383c874,0xe3a03001);
 expectWord(p,0x5385303c,0xea000000|(((0x53000904-0x5385303c-8)>>2)&0xffffff));
 expectWord(p,0x53000918,0xee074f3a);
 const clean=fn(p,'mov r0,r1;mov r1,r2;b #0x5383c870');
 // Read the SAME immutable per-photo fields consumed by native Pentax Date
 // (tag6:535c3f84) and Time (tag7:535c405c). Do not query CpuInformationService:
 // 53571d90/53572ca4 belong to PowerSourceInfo, not the RTC/DateTime class.
 // Native writer: year944, month946, day947, hour949, minute94a, second94b.
 for(const[a,w]of [[0x535c3f84,0xe3000944],[0x535c3f9c,0xe19260b0],[0x535c3fa0,0xe5d2c946],[0x535c3fa8,0xe5d20949],[0x535c3fc0,0xe5d23947],[0x535c4074,0xe19260b0]])expectWord(p,a,w);
 const shotDate=fn(p,'movw r3,#0x944;add r3,r0,r3;ldrh r2,[r3];strh r2,[r1];ldrb r2,[r0,#0x946];strb r2,[r1,#2];ldrb r2,[r0,#0x947];strb r2,[r1,#3];ldrb r2,[r0,#0x949];strb r2,[r1,#4];ldrb r2,[r0,#0x94a];strb r2,[r1,#5];bx lr');
 const ctx=p.append(u32le([0x536bbc30,0x536bbcc0,clean,0,shotDate,capture.lookup]),16);
 const raw=Uint8Array.from(atob(FILM_STAMP_CODE),c=>c.charCodeAt(0));if(raw.length!==FILM_STAMP_CODE_LENGTH)throw Error('JPG module length mismatch');const code=p.append(raw,16);
 const stub=fn(p,`push {r0,r1,r2,r3,ip,lr};mrs ip,cpsr;push {r4,ip};ldr r1,[r1,#8];${addr('r0',ctx)}bl #${code};pop {r4,ip};msr cpsr_f,ip;pop {r0,r1,r2,r3,ip,lr};mov ip,sp;b #${site+4}`);
 p.setWord(site,branch(site,stub),'JPG encode: ISO grain, photo-owned EXIF date and CLEAN writeback');return {ctx,code,stub,clean,shotDate,bytes:raw.length};
}
