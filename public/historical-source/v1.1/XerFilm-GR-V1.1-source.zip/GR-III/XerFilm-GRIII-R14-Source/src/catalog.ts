// SPDX-License-Identifier: GPL-2.0-only
// The GR III family uses precisely the same XerFilm assets and stable identities.
export * from './assets/film-catalog';
export {FILM_MODELS} from './assets/film-models';
