// SPDX-License-Identifier: GPL-2.0-only
// Native, cached 4x3 management grid; its cursor is separate from the shooting film.
import {Patch,expectWord,u32le,u16le,concat,ICON_CATALOG,LOOKUP_BOUNDS} from './build';
import {assembleWords,movWord,movImmediate} from './arm';
import {FILM_FAMILIES,FILM_ICONS,FILM_FIRST_ICON,FILM_FIRST_TEXT} from './catalog';
import {installFilmEnabled} from './film-enabled';
import {installPreferences} from './preferences';
const RECORD=3,ROOT=0x1e4,CURSOR=0x1e8,CAPTION=0x1ec,CELLS=0x1f0,BACKGROUND=0x220;
export const FILM_GRID_ICON_FIRST=788,FILM_GRID_CELLS=12;
const addr=(r:string,a:number)=>`movw ${r},#${a&65535};movt ${r},#${a>>>16};`;
const branch=(a:number,b:number)=>{const n=(b-a-8)>>2;if(n< -0x800000||n>0x7fffff)throw Error('grid branch range');return(0xea000000|(n&0xffffff))>>>0;};
// Paint the complete tile through the working native IconView path. ADJ row
// focus only styles its optional text/mark children; it never paints a panel.
export const FILM_GRID_WIDTH=164,FILM_GRID_HEIGHT=92;
export function gridIcon(family:number,on:boolean,focused=false){
 const src=FILM_ICONS[FILM_FAMILIES[family].icon-FILM_FIRST_ICON],dst=new Uint8Array(164*92*4);
 const pixel=(x:number,y:number,c:number[])=>dst.set(c,(y*164+x)*4);
 for(let y=0;y<92;y++)for(let x=0;x<164;x++){
  const edge=x<1||x>=163||y<1||y>=91;
  pixel(x,y,focused?[255,240,0,255]:edge?[105,108,108,255]:[46,49,49,255]);
 }
 // 80px packaging centered inside a fully opaque tile, preserving alpha.
 for(let y=0;y<80;y++)for(let x=0;x<80;x++){
  const a=((y>>1)*40+(x>>1))*4,b=((y+6)*164+x+42)*4;
  const l=(77*src[a]+150*src[a+1]+29*src[a+2])>>8,v=Math.round(l*0.58+24);
  const alpha=src[a+3]/255;
  for(let k=0;k<3;k++)dst[b+k]=Math.round((on?src[a+k]:v)*alpha+dst[b+k]*(1-alpha));
 }
 // Enabled marker is independent of the yellow keyboard focus tile.
 if(on){for(let y=1;y<20;y++)for(let x=59;x<79;x++)pixel(x+42,y+6,[24,24,24,255]);
  for(let k=0;k<5;k++)for(let t=-1;t<=1;t++)pixel(104+k,16+k+t,[255,240,0,255]);
  for(let k=0;k<10;k++)for(let t=-1;t<=1;t++)pixel(108+k,20-k+t,[255,240,0,255]);}
 return dst;
}
export function installFilmGrid(p:Patch){
 const fn=(s:string)=>p.append(a=>assembleWords(s,a),16),en=installFilmEnabled(p),prefs=installPreferences(p);
 // The shared native controller is extended, with zeroed optional ownership.
 expectWord(p,0x5317090c,0xe3a00f75);p.setWord(0x5317090c,movWord(0,0x228),'film grid: extend SelectMenu controller');
 expectWord(p,0x531be7e0,0xe584c1a8);
 const zero=fn(`str ip,[r4,#0x1a8];str ip,[r4,#${ROOT}];str ip,[r4,#${CURSOR}];str ip,[r4,#${CAPTION}];str ip,[r4,#${BACKGROUND}];${Array.from({length:12},(_,k)=>`str ip,[r4,#${CELLS+4*k}];`).join('')}b #0x531be7e4`);
 p.setWord(0x531be7e0,branch(0x531be7e0,zero),'film grid: initialize optional owners');
 const backgroundDesc=p.append(u32le([11,0,0,720,360,0]),4);
 const rootDesc=p.append(u32le([0,0,60,720,360,0]),4),captionDesc=p.append(u32le([17,10,0,700,40,0]),4);
 const cells=p.append(u32le(Array.from({length:12},(_,k)=>[25,20+170*(k%4),54+98*Math.floor(k/4),164,92,0]).flat()),4);
 const iconRect=p.append(u32le([0,0,164,92]),4);
 const leftFooterRect=p.append(u32le([10,430,250,40]),4),rightFooterRect=p.append(u32le([380,430,330,40]),4);
 const layout=`ldr r0,[r4,#0x158];ldr r3,[r0];ldr r3,[r3,#0x48];mov lr,pc;bx r3;
  ldr r0,[r4,#0x158];ldr r3,[r0];ldr r3,[r3,#0x28];mov lr,pc;bx r3;
  ldr r0,[r4,#0x158];ldr r3,[r0];ldr r3,[r3,#0x34];mov lr,pc;bx r3;
  ldr r0,[r4,#0x158];bl #0x533ad2c8;`;
 const init=fn(`push {r4,r5,r6,r7,r8,lr};mov r4,r0;${addr('r0',rootDesc)}bl #0x533ad7f0;mov r5,r0;str r5,[r4,#${ROOT}];
  ldr r0,[r4,#0x158];mov r1,r5;bl #0x533aba64;
  ${addr('r0',backgroundDesc)}bl #0x533ad7f0;str r0,[r4,#${BACKGROUND}];mov r1,#20;bl #0x53393e00;ldr r1,[r4,#${BACKGROUND}];mov r0,r5;bl #0x533aba64;
  ${addr('r0',captionDesc)}bl #0x533ad7f0;str r0,[r4,#${CAPTION}];mov r1,r0;mov r0,r5;bl #0x533aba64;
  mov r6,#0;loop:${addr('r0',cells)}mov r1,#24;mul r1,r6,r1;add r0,r0,r1;bl #0x533ad7f0;mov r8,r0;add r7,r4,#${CELLS};str r8,[r7,r6,lsl #2];
  mov r0,r5;mov r1,r8;bl #0x533aba64;add r6,r6,#1;cmp r6,#12;blo loop;
  bl #${en.rawFamily};str r0,[r4,#${CURSOR}];mov r0,r4;pop {r4,r5,r6,r7,r8,pc}`);
 const render=fn(`push {r4,r5,r6,r7,r8,r9,r10,lr};mov r4,r0;ldr r0,[r4,#${ROOT}];cmp r0,#0;mov r0,r4;bleq #${init};
  ldr r5,[r4,#${CURSOR}];cmp r5,#${FILM_FAMILIES.length};movhs r5,#0;str r5,[r4,#${CURSOR}];
  mov r6,#0;cmp r5,#12;movhs r6,#12;
  ldr r0,[r4,#${CAPTION}];movw r1,#${FILM_FIRST_TEXT};add r1,r1,r5;mov r2,#0;bl #0x53396f80;
  ldr r0,[r4,#${CAPTION}];mov r1,#1;bl #0x53396f4c;
  mov r7,#0;loop:add r8,r6,r7;add r0,r4,#${CELLS};ldr r9,[r0,r7,lsl #2];cmp r8,#${FILM_FAMILIES.length};bhs hidden;
  mov r0,r8;bl #${en.enabled};movw r1,#${FILM_GRID_ICON_FIRST};add r1,r1,r8,lsl #2;add r1,r1,r0;cmp r8,r5;addeq r1,r1,#2;
  ldr r2,[r9,#0xf0];cmp r2,#0;beq seticon;ldrh r2,[r2,#0xea];cmp r2,r1;beq iconready;
  seticon:mov r0,r9;bl #0x533a1734;
  iconready:ldr r0,[r9,#0xf0];${addr('r1',iconRect)}bl #0x533ab548;
  mov r0,r9;cmp r8,r5;bne unfocus;bl #0x533a14ac;b focused;unfocus:bl #0x533a14b8;focused:
  mov r0,r9;mov r1,#1;bl #0x533ad3c0;b next;
  hidden:mov r0,r9;mov r1,#0;bl #0x533ad3c0;
  next:add r7,r7,#1;cmp r7,#12;blo loop;
  ${[0x168,0x16c,0x170,0x180,0x184,0x188,0x18c,0x190,0x194].map(o=>`ldr r0,[r4,#${o}];cmp r0,#0;movne r1,#0;blne #0x533ad3c0;`).join('')}
  ldr r0,[r4,#${ROOT}];mov r1,#1;bl #0x533ad3c0;
  ldr r0,[r4,#0x178];${addr('r1',leftFooterRect)}bl #0x5339b484;
  ldr r0,[r4,#0x17c];${addr('r1',rightFooterRect)}bl #0x5339b484;
  ldr r0,[r4,#0x178];movw r1,#0x1d1;movw r2,#878;bl #0x5339b61c;
  ldr r0,[r4,#0x17c];movw r1,#0x1d4;movw r2,#877;bl #0x5339b61c;ldr r0,[r4,#0x17c];mov r1,#2;bl #0x5339b5e8;
  ${layout}mov r0,r4;pop {r4,r5,r6,r7,r8,r9,r10,pc}`);
 const toggle=fn(`push {r4,lr};mov r4,r0;ldr r0,[r4,#${CURSOR}];bl #${en.toggle};bl #${prefs.save};mov r0,r4;bl #${render};pop {r4,pc}`);
 // Run stock page preparation first, then display our independent grid.
 expectWord(p,0x531be238,0xe1a0c00d);
 const originalRender=fn(`mov ip,sp;b #0x531be23c`);
 const page=fn(`push {r4,lr};mov r4,r0;bl #${originalRender};ldrb r1,[r4,#0x1d8];cmp r1,#${RECORD};bne ordinary;mov r0,r4;bl #${render};b done;
  ordinary:ldr r0,[r4,#${ROOT}];cmp r0,#0;movne r1,#0;blne #0x533ad3c0;done:mov r0,r4;pop {r4,pc}`);
 p.setWord(0x531be238,branch(0x531be238,page),'film grid: render only our settings record');
 expectWord(p,0x531be2d8,0xe1d130b0);
 const keys=fn(`push {r0,r1,r2,r3,r4,r5,ip,lr};mov r4,r0;ldrb r2,[r0,#0x1d8];cmp r2,#${RECORD};bne native;
  ldrh r3,[r1];cmp r3,#0xd8;beq change;cmp r3,#0xda;beq close;ldr r5,[r4,#${CURSOR}];
  cmp r3,#0xce;beq left;cmp r3,#0xcf;beq right;cmp r3,#0xd0;beq up;cmp r3,#0xd1;beq down;cmp r3,#0xd4;beq left;cmp r3,#0xd5;beq right;b native;
  left:cmp r5,#0;subhi r5,r5,#1;b move;
  right:cmp r5,#${FILM_FAMILIES.length-1};addlo r5,r5,#1;b move;
  up:cmp r5,#4;subhs r5,r5,#4;b move;
  down:add r2,r5,#4;cmp r2,#${FILM_FAMILIES.length};movlo r5,r2;blo move;cmp r5,#${FILM_FAMILIES.length-1};movlo r5,#${FILM_FAMILIES.length-1};b move;
  close:mov r0,r4;movw r1,#0x1a0;movt r1,#0x200;movw r2,#0x4a;movt r2,#0x200;bl #0x5316c9d8;b consumed;
  change:mov r0,r4;bl #${toggle};b consumed;
  move:str r5,[r4,#${CURSOR}];mov r0,r4;bl #${render};
  consumed:pop {r0,r1,r2,r3,r4,r5,ip,lr};mov r0,#1;bx lr;
  native:pop {r0,r1,r2,r3,r4,r5,ip,lr};ldrh r3,[r1];b #0x531be2dc`);
 p.setWord(0x531be2d8,branch(0x531be2d8,keys),'film grid: four-way cursor and non-closing OK toggle');
 // BaseController sends physical keys through the view tree before its
 // controller key callback, then forwards unconsumed keys to the menu manager.
 // Intercept ONLY this record at that real entry point, before either route.
 expectWord(p,0x5316d5dc,0xe1a0c00d);
// Raw OK ID8 and Left/Right IDs11/12 precede logical E0/D4/D5.
 // Act only on press2 and consume release1 before the native manager can close.
 // Translate in a stack-local packet without modifying the shared event.
 const dispatch=fn(`push {r0,r1,r2,r3,ip,lr};ldr r2,[r0];${addr('r3',0x53b3c4c8)}cmp r2,r3;bne native;
  ldrb r2,[r0,#0x1d8];cmp r2,#${RECORD};bne native;ldrh r3,[r1];
  cmp r3,#8;beq physical;cmp r3,#11;beq physical;cmp r3,#12;beq physical;
  cmp r3,#0xd8;beq managed;cmp r3,#0xda;beq managed;
  cmp r3,#0xce;blo native;cmp r3,#0xd1;bls managed;cmp r3,#0xd4;beq managed;cmp r3,#0xd5;bne native;
  managed:pop {r0,r1,r2,r3,ip,lr};b #${keys};
  physical:ldr r2,[r1,#4];cmp r2,#0;beq rawdone;ldrb r2,[r2];cmp r2,#2;bne rawdone;
  cmp r3,#11;moveq r2,#0xce;movne r2,#0xcf;cmp r3,#8;moveq r2,#0xd8;sub sp,sp,#8;str r2,[sp];
  ldr r2,[r1,#4];str r2,[sp,#4];mov r1,sp;bl #${keys};add sp,sp,#8;
  rawdone:pop {r0,r1,r2,r3,ip,lr};mov r0,#1;bx lr;
  native:pop {r0,r1,r2,r3,ip,lr};mov ip,sp;b #0x5316d5e0`);
 p.setWord(0x5316d5dc,branch(0x5316d5dc,dispatch),'film grid: consume keys before native confirm/close dispatch');
 // The touchable stock OK footer must perform the same toggle and stay open.
 expectWord(p,0x531ba21c,0xe1a0c00d);
 const button=fn(`push {r0,r1,r2,r3,ip,lr};ldrb r3,[r0,#0x1d8];cmp r3,#${RECORD};bne native;bl #${toggle};pop {r0,r1,r2,r3,ip,pc};native:pop {r0,r1,r2,r3,ip,lr};mov ip,sp;b #0x531ba220`);
 p.setWord(0x531ba21c,branch(0x531ba21c,button),'film grid: native confirm toggles without leaving');
 // The stock footer closure posts a close event after calling confirm; consume
 // our record at the closure entry as well as the physical-key route.
 expectWord(p,0x531ba284,0xe1a0c00d);
 const footer=fn(`push {r0,r1,r2,r3,ip,lr};ldr r2,[r0];ldr r2,[r2];ldrb r3,[r2,#0x1d8];cmp r3,#${RECORD};bne native;mov r0,r2;bl #${toggle};pop {r0,r1,r2,r3,ip,pc};native:pop {r0,r1,r2,r3,ip,lr};mov ip,sp;b #0x531ba288`);
 p.setWord(0x531ba284,branch(0x531ba284,footer),'film grid footer consumes confirm before stock close');
 // Plain root views do not own their children. Release the fourteen explicit
 // child owners first, then their root, only at controller teardown.
 expectWord(p,0x531b3d94,0xe1a0c00d);
 const destroy=fn(`push {r0,r1,r2,r3,r4,r5,ip,lr};mov r4,r0;add r1,r0,#${CAPTION};mov r2,#14;bl #0x5316cde8;mov r0,r4;add r1,r0,#${ROOT};mov r2,#1;bl #0x5316cde8;mov r2,#0;str r2,[r4,#${ROOT}];str r2,[r4,#${CAPTION}];str r2,[r4,#${BACKGROUND}];
  ${Array.from({length:12},(_,k)=>`str r2,[r4,#${CELLS+4*k}];`).join('')}
  pop {r0,r1,r2,r3,r4,r5,ip,lr};mov ip,sp;b #0x531b3d98`);
 p.setWord(0x531b3d94,branch(0x531b3d94,destroy),'film grid: release cached tree before original root');
 return {init,render,toggle,keys,dispatch,destroy};
}
