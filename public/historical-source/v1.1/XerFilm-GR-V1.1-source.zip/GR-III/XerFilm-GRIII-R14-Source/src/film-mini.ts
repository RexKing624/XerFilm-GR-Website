// SPDX-License-Identifier: GPL-2.0-only
// GR IV 1.11: a separate native ADJListView with text-only ADJListItemViews.
// The stock menu skins provide its background and selection frame.
import {Patch,expectWord,u32le} from './build';
import {assembleWords,movWord} from './arm';
import {installFilmPreview} from './film-preview';
import {FILM_FAMILIES,FILM_FIRST_CHILD_TEXT} from './catalog';
import {installFilmEnabled} from './film-enabled';
import {installFilmSession,FILM_SESSION_WORD} from './film-session';
const SELECTION=0x5503a094;
export const MINI_PTR=0x294, MINI_FOCUS=0x2a0, MINI_TEXT=FILM_FIRST_CHILD_TEXT, MINI_SAVED=0x2a4;
// Native redraw work can outlive the callback requesting it. Keep each popup
// attached and alive until the ADJ controller closes; never delete it in render.
export const MINI_CACHE=0x2a8;
const addr=(r:string,a:number)=>`movw ${r},#${a&65535};movt ${r},#${a>>>16};`;
const branch=(a:number,b:number)=>{const d=(b-a-8)>>2;if(d< -0x800000||d>0x7fffff)throw Error('mini branch range');return(0xea000000|(d&0xffffff))>>>0;};
export function installFilmMini(p:Patch){
 const fn=(s:string)=>p.append(a=>assembleWords(s,a),16);
 const preview=installFilmPreview(p),enabled=installFilmEnabled(p),session=installFilmSession(p);
 let cachedGroups=0;
 // first processing look, number of children, first child string, controller cache offset.
 const groups=p.append(u32le(FILM_FAMILIES.flatMap(f=>[f.first,f.count>1?f.count:0,f.childText??0,f.count>1?MINI_CACHE+4*cachedGroups++:0])),4);
 if(cachedGroups!==3)throw Error('Update ADJ controller cache allocation for changed popup families');
 // This constructor has one factory call, at 0x53186a54; original allocation is 0x294.
 expectWord(p,0x5316fef4,0xe3a00f9f);
 p.setWord(0x5316fef4,movWord(0,0x2b8),'film mini: extend ADJ controller allocation with lifetime popup caches');
 expectWord(p,0x531a2080,0xe5c4c270);
 const zero=fn(`strb ip,[r4,#0x270];str ip,[r4,#0x294];str ip,[r4,#0x298];str ip,[r4,#0x29c];str ip,[r4,#0x2a0];str ip,[r4,#${MINI_SAVED}];str ip,[r4,#${MINI_CACHE}];str ip,[r4,#${MINI_CACHE+4}];str ip,[r4,#${MINI_CACHE+8}];str ip,[r4,#${FILM_SESSION_WORD}];b #0x531a2084`);
 p.setWord(0x531a2080,branch(0x531a2080,zero),'film mini: initialize reserved fields before native UI construction');
 const padding=fn(`ldr r2,[r0,#0xf4];ldr r3,[r0,#0xf8];cmp r2,r3;bxeq lr;loop:ldr ip,[r2],#4;strb r1,[ip,#0x10];cmp r2,r3;bne loop;bx lr`);
 const defs=[p.append(u32le([13,470,180,140,180,0]),4)];
 const kinds=p.append(Uint8Array.from([25,25,25,25,25,25,25]),4);
 const layout=`ldr r0,[r4,#0x15c];ldr r3,[r0];ldr r3,[r3,#0x48];mov lr,pc;bx r3;
  ldr r0,[r4,#0x15c];ldr r3,[r0];ldr r3,[r3,#0x28];mov lr,pc;bx r3;
  ldr r0,[r4,#0x15c];ldr r3,[r0];ldr r3,[r3,#0x34];mov lr,pc;bx r3;
  ldr r0,[r4,#0x15c];bl #0x533ad2c8;`;
 const init=fn(`push {r4,r5,r6,lr};mov r4,r0;${addr('r0',defs[0])}bl #0x533ad7f0;
  mov r5,r0;str r5,[r4,#${MINI_PTR}];mov r1,#0;bl #0x53394768;
  ldr r2,[r4,#0x298];cmp r2,#0;moveq r2,#3;str r2,[r4,#0x298];
  mov r0,r5;${addr('r1',kinds)}mov r3,#58;bl #0x53394610;
  mov r0,r5;mov r1,#16;bl #0x533958a8;
  mov r0,r5;mov r1,#16;bl #${padding};
  mov r0,r5;mov r1,#0;bl #0x533ac1b4;
  ldr r0,[r4,#0x15c];mov r1,r5;bl #0x533aba64;
  mov r0,r5;mov r1,#0;bl #0x533ad3c0;
  ${layout}mov r0,r4;pop {r4,r5,r6,pc}`);
 const cancel=fn(`push {r4,r5,r6,lr};mov r4,r0;ldrb r1,[r4,#${MINI_FOCUS}];cmp r1,#1;bne done;
  mov r1,#0;strb r1,[r4,#${MINI_FOCUS}];ldrb r1,[r4,#${MINI_SAVED}];
  ${addr('r2',SELECTION)}ldrb r3,[r2];cmp r3,r1;beq done;strb r1,[r2];bl #${preview};
  done:mov r0,r4;pop {r4,r5,r6,pc}`);
 const hide=fn(`push {r4,r5,r6,lr};mov r4,r0;bl #${cancel};mov r1,#0;strb r1,[r4,#${MINI_FOCUS}];
  ldr r0,[r4,#${MINI_PTR}];cmp r0,#0;beq done;bl #0x533ad3c0;
  done:mov r0,r4;pop {r4,r5,r6,pc}`);
 // Place the middle numeric row beside the parent row, clamping the entire
 // popup to y=60..420. At the bottom, its last row is therefore the nearest.
 const render=fn(`push {r4,r5,r6,r7,r8,r9,r10,lr};sub sp,sp,#16;mov r4,r0;
  ldr r2,[r4,#0x29c];cmp r2,r1;movne r2,#0;strbne r2,[r4,#${MINI_FOCUS}];str r1,[r4,#0x29c];
  cmp r1,#${FILM_FAMILIES.length};bhs hidden;${addr('r6',groups)}add r6,r6,r1,lsl #4;
  ldr r10,[r6,#4];cmp r10,#0;beq hidden;
  ldr r2,[r6,#12];ldr r9,[r4,r2];ldr r0,[r4,#${MINI_PTR}];cmp r0,r9;beq cached;
  cmp r0,#0;movne r1,#0;blne #0x533ad3c0;
  cached:cmp r9,#0;bne reuse;
  str r10,[r4,#0x298];mov r0,r4;bl #${init};ldr r9,[r4,#${MINI_PTR}];ldr r2,[r6,#12];str r9,[r4,r2];b ready;
  reuse:str r9,[r4,#${MINI_PTR}];str r10,[r4,#0x298];
  ready:ldr r9,[r4,#${MINI_PTR}];${addr('r2',SELECTION)}ldrb r7,[r2];ldr r0,[r6];sub r7,r7,r0;cmp r7,r10;movhs r7,#0;
  ldr r0,[r4,#0x1f0];bl #0x5339606c;
  ldr r0,[r4,#0x1f0];ldr r3,[r0];ldr r3,[r3,#0x28];mov lr,pc;bx r3;
  ldr r0,[r4,#0x29c];bl #${enabled.rank};mov r1,r0;ldr r0,[r4,#0x1f0];bl #0x53394758;
  ldr r1,[r0,#0x68];ldr r2,[r0,#0x70];cmp r2,#0;ldreq r1,[r0,#0x34];ldreq r2,[r0,#0x3c];
  add r1,r1,r2,lsr #1;mov r2,r10;cmp r2,#6;movhi r2,#6;mov r3,#60;mul r3,r2,r3;str r3,[sp,#12];
  sub r1,r1,r3,lsr #1;movw r2,#420;sub r2,r2,r3;cmp r1,#60;movlt r1,#60;cmp r1,r2;movgt r1,r2;
  str r1,[sp,#4];ldr r0,[r4,#0x1f0];ldr r1,[r0,#0x30];sub r1,r1,#148;cmp r1,#0;movlt r1,#0;
  str r1,[sp];mov r2,#140;str r2,[sp,#8];
  mov r0,r9;mov r1,sp;ldr r3,[r0];ldr r3,[r3,#0x18];mov lr,pc;bx r3;
  mov r5,#0;
  loop:mov r0,r9;mov r1,r5;bl #0x53394758;mov r8,r0;
  mov r2,#2;strb r2,[r8,#0x102];ldr r1,[r6,#8];add r1,r1,r5;
  ldr r2,[r8,#0xf4];cmp r2,#0;beq settext;ldrh r2,[r2,#0xea];cmp r2,r1;beq textready;
  settext:bl #0x533a1808;
  textready:
  ldrb r1,[r4,#${MINI_FOCUS}];cmp r1,#1;ldrbeq r1,[r4,#${MINI_SAVED}];ldreq r2,[r6];subeq r1,r1,r2;movne r1,r7;
  cmp r1,r5;moveq r1,#1;movne r1,#0;mov r0,r8;bl #0x533a19b4;
  mov r2,#10;str r2,[sp];mov r2,#9;str r2,[sp,#4];mov r2,#120;str r2,[sp,#8];mov r2,#40;str r2,[sp,#12];
  ldr r0,[r8,#0xf4];mov r1,sp;bl #0x533ab548;
  add r5,r5,#1;cmp r5,r10;blo loop;
  mov r0,r9;mov r1,r7;bl #0x53395430;
  mov r0,r9;ldrb r1,[r4,#${MINI_FOCUS}];bl #0x5339482c;
  mov r0,r9;mov r1,#1;bl #0x533ad3c0;
  ${layout}b done;
  hidden:bl #${hide};done:mov r0,r4;add sp,sp,#16;pop {r4,r5,r6,r7,r8,r9,r10,pc}`);
 // Destroy our views while the original parent is alive. Native view destructors unlink them.
 expectWord(p,0x5319ff24,0xe1a0c00d);
 const destroy=fn(`push {r0,r1,r2,r3,r4,r5,ip,lr};mov r4,r0;bl #${cancel};bl #${session.rollback};add r1,r0,#${MINI_CACHE};mov r2,#${cachedGroups};bl #0x5316cde8;
  mov r2,#0;str r2,[r4,#${MINI_PTR}];str r2,[r4,#${MINI_PTR+4}];str r2,[r4,#${MINI_PTR+8}];strb r2,[r4,#${MINI_FOCUS}];
  str r2,[r4,#${MINI_CACHE}];str r2,[r4,#${MINI_CACHE+4}];str r2,[r4,#${MINI_CACHE+8}];
  pop {r0,r1,r2,r3,r4,r5,ip,lr};mov ip,sp;b #0x5319ff28`);
 p.setWord(0x5319ff24,branch(0x5319ff24,destroy),'film mini: release own views before original destructor');
 // Restore before entering another ADJ function, so its first native current
 // scan and preview see the original Image Control instead of temporary Std.
 expectWord(p,0x531a462c,0xe1a0c00d);
 const leave=fn(`push {r0,r1,r2,r3,r4,r5,r6,r7,ip,lr};mrs r5,cpsr;mov r4,r0;mov r6,r1;
  ldrb r1,[r0,#0x1f4];bl #0x531a2820;cmp r0,#20;bne done;mov r0,r4;mov r1,r6;bl #0x531a2820;cmp r0,#20;beq done;
  mov r0,r4;bl #${hide};bl #${session.rollback};done:msr cpsr_f,r5;pop {r0,r1,r2,r3,r4,r5,r6,r7,ip,lr};mov ip,sp;b #0x531a4630`);
 p.setWord(0x531a462c,branch(0x531a462c,leave),'film session: rollback before leaving unconfirmed film ADJ');
 // Clear the panel whenever the header changes to another ADJ function.
 expectWord(p,0x531a2c28,0xe1a0c00d);
 const header=fn(`push {r0,r1,r2,r3,r4,r5,ip,lr};mrs r5,cpsr;mov r4,r0;ldrb r1,[r0,#0x1f4];bl #0x531a2820;
  cmp r0,#20;beq done;mov r0,r4;bl #${hide};done:msr cpsr_f,r5;pop {r0,r1,r2,r3,r4,r5,ip,lr};mov ip,sp;b #0x531a2c2c`);
 p.setWord(0x531a2c28,branch(0x531a2c28,header),'film mini: hide on other ADJ functions');
 // Accept the visible child AND its stable family as one operation. Native
 // parent refresh re-enters the family setter; hold the exact child separately
 // and publish/commit it after that refresh. A cursor-only child acceptance
 // could otherwise leave the prior family selected until a second parent OK.
 const acceptChild=fn(`push {r4,r5,r6,r7,r8,lr};mov r4,r0;mov r5,r1;
  ${addr('r6',groups)}add r6,r6,r5,lsl #4;
  ldr r0,[r4,#${MINI_PTR}];bl #0x53394820;ldr r1,[r6,#4];cmp r0,r1;movhs r0,#0;ldr r8,[r6];add r8,r8,r0;
  mov r0,#0;strb r0,[r4,#${MINI_FOCUS}];
  ${addr('r2',SELECTION)}strb r8,[r2];mov r1,#1;strb r1,[r2,#1];
  mov r0,r5;bl #${enabled.rank};mov r7,r0;
  ldr r0,[r4,#0x1f0];mov r1,r7;bl #0x53395430;
  mov r0,r4;bl #0x531a4cfc;
  ${addr('r2',SELECTION)}strb r8,[r2];mov r1,#1;strb r1,[r2,#1];bl #${preview};
  mov r0,r4;bl #${session.commit};
  bl #${enabled.count};mov r6,r0;mov r5,#0;
  marks:ldr r0,[r4,#0x1f0];mov r1,r5;bl #0x53394758;cmp r5,r7;moveq r1,#1;movne r1,#0;bl #0x533a19b4;
  add r5,r5,#1;cmp r5,r6;blo marks;
  mov r0,r4;pop {r4,r5,r6,r7,r8,pc}`);
 expectWord(p,0x531a4db8,0xe1d130b0);
 const keys=fn(`push {r0,r1,r2,r3,r4,r5,r6,r7,ip,lr};mrs r5,cpsr;mov r4,r0;
  ldrb r1,[r0,#0x1f4];bl #0x531a2820;cmp r0,#20;bne native;
  ldr r0,[r4,#0x1f0];bl #0x53394820;bl #${enabled.at};mov r6,r0;cmp r6,#${FILM_FAMILIES.length};bhs native;
  ${addr('r7',groups)}add r7,r7,r6,lsl #4;ldr r2,[r7,#4];cmp r2,#0;beq native;
  ldr r1,[sp,#4];ldrh r3,[r1];cmp r3,#0xce;beq enter;
  ldrb r2,[r4,#${MINI_FOCUS}];cmp r3,#0xcf;beq leave;cmp r2,#1;bne native;
  cmp r3,#0xd8;beq confirm;cmp r3,#0xd0;beq up;cmp r3,#0xd4;beq up;cmp r3,#0xd1;beq down;cmp r3,#0xd5;beq down;b native;
  enter:ldrb r2,[r4,#${MINI_FOCUS}];cmp r2,#1;beq repaint;
  mov r0,r4;bl #${session.begin};
  ${addr('r2',SELECTION)}ldrb r3,[r2];strb r3,[r4,#${MINI_SAVED}];mov r2,#1;strb r2,[r4,#${MINI_FOCUS}];b repaint;
  leave:cmp r2,#1;bne native;mov r0,r4;bl #${cancel};mov r0,r4;bl #0x531a4cfc;b repaint;
  confirm:mov r0,r4;mov r1,r6;bl #${acceptChild};b repaint;
  up:${addr('r2',SELECTION)}ldrb r3,[r2];ldr ip,[r7];ldr r1,[r7,#4];add r1,ip,r1;sub r1,r1,#1;
  cmp r3,ip;movlo r3,ip;cmp r3,r1;movhi r3,ip;cmp r3,ip;subhi r3,r3,#1;b store;
  down:${addr('r2',SELECTION)}ldrb r3,[r2];ldr ip,[r7];ldr r1,[r7,#4];add r1,ip,r1;sub r1,r1,#1;
  cmp r3,ip;movlo r3,ip;cmp r3,r1;movhi r3,ip;cmp r3,r1;addlo r3,r3,#1;
  store:ldrb r1,[r2];cmp r1,r3;beq repaint;strb r3,[r2];bl #${preview};mov r0,r4;bl #0x531a4cfc;
  repaint:mov r0,r4;mov r1,r6;bl #${render};msr cpsr_f,r5;pop {r0,r1,r2,r3,r4,r5,r6,r7,ip,lr};mov r0,#0;bx lr;
  native:msr cpsr_f,r5;pop {r0,r1,r2,r3,r4,r5,r6,r7,ip,lr};ldrh r3,[r1];b #0x531a4dbc`);
 p.setWord(0x531a4db8,branch(0x531a4db8,keys),'film mini: scoped left/right and speed keys');
 return {init,hide,render,keys,zero,destroy,header,defs,preview,cancel,groups,acceptChild};
}
