// SPDX-License-Identifier: GPL-2.0-only
import {Patch,fn,expectWord} from './build';
const installed=new WeakMap<Patch,number>();
export function installFilmPreview(p:Patch){const old=installed.get(p);if(old)return old;expectWord(p,0x532750f8,0xeef17a0c);expectWord(p,0x532750fc,0xe1a0c00d);const x=fn(p,'push {r4,lr};bl #0x5320ad88;bl #0x5320b31c;bl #0x532750f8;pop {r4,pc}');installed.set(p,x);return x;}
