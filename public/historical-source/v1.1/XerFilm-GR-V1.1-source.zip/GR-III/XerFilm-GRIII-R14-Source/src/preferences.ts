// SPDX-License-Identifier: GPL-2.0-only
// Private preferences use verified .data alignment padding and a separate file.
// The original GR III UserData/APData record schema remains untouched.
import {Patch,fn,addr,expectWord,branch,u32le} from './build';
export const ROOT=0x5503a080,MASK_BASE=ROOT+0x10,SELECT=ROOT+0x14,FLAG=ROOT+0x15,CAPTURE_ROOT=ROOT+0x1c;
const installed=new WeakMap<Patch,ReturnType<typeof create>>();
function create(p:Patch){
 expectWord(p,0x53000450,0x5407b540);expectWord(p,0x53000454,0x55000000);expectWord(p,0x53000458,0x3a080);expectWord(p,0x5300045c,0x5503a100);
 if(p.read(0x540b55c0,32).some(x=>x!==0))throw Error('Capture preferences zero initializer is occupied');
 p.setWord(0x53000458,0x3a0a0,'initialize only GR III data-alignment padding, before BSS');
 const magic=0x31475258,defaults=0x00c9ffff;
 const init=fn(p,`${addr('r2',ROOT)}ldr r3,[r2];${addr('r1',magic)}cmp r3,r1;bxeq lr;str r1,[r2];mov r3,#0;str r3,[r2,#20];str r3,[r2,#24];str r3,[r2,#28];${addr('r3',defaults)}str r3,[r2,#16];bx lr`);
 const file=p.append(new TextEncoder().encode('XerFilmGR.bin\0'),4);
 // FS helpers mirror AppData's real calls, while using a distinct basename.
 for(const a of [0x53828014,0x53825fa8,0x53825648])expectWord(p,a,0xe1a0c00d);
 const save=fn(p,`push {r4,r5,r6,lr};sub sp,sp,#16;bl #${init};${addr('r4',ROOT)}${addr('r0',magic)}str r0,[sp];ldr r1,[r4,#16];str r1,[sp,#4];ldr r2,[r4,#20];movw r3,#65535;and r2,r2,r3;str r2,[sp,#8];eor r0,r0,r1;eor r0,r0,r2;str r0,[sp,#12];
  bl #0x53828014;ldr r0,[r0,#8];cmp r0,#0;beq done;ldr r0,[r0];cmp r0,#0;beq done;${addr('r1',file)}mov r2,#16;mov r3,sp;bl #0x53825fa8;
  done:add sp,sp,#16;pop {r4,r5,r6,pc}`);
 const load=fn(p,`push {r4,r5,r6,lr};sub sp,sp,#16;bl #${init};mov r1,#0;str r1,[sp];str r1,[sp,#4];str r1,[sp,#8];str r1,[sp,#12];
  bl #0x53828014;ldr r0,[r0,#8];cmp r0,#0;beq done;ldr r0,[r0];cmp r0,#0;beq done;${addr('r1',file)}mov r2,#16;mov r3,sp;bl #0x53825648;
  ldr r0,[sp];${addr('r1',magic)}cmp r0,r1;bne done;ldr r1,[sp,#4];ldr r2,[sp,#8];eor r3,r0,r1;eor r3,r3,r2;ldr r0,[sp,#12];cmp r3,r0;bne done;
  mov r3,r2,lsr #16;cmp r3,#0;bne done;and r3,r2,#255;cmp r3,#26;bhi done;mov r3,r2,lsr #8;cmp r3,#1;bhi done;
  ${addr('r4',ROOT)}str r1,[r4,#16];str r2,[r4,#20];
  done:add sp,sp,#16;pop {r4,r5,r6,pc}`);
 // Run the stock save first; preserve its result and callee-saved registers.
 expectWord(p,0x5323f274,0xe1a0c00d);
 const originalSave=fn(p,'mov ip,sp;b #0x5323f278');
 const saveHook=fn(p,`push {r4,lr};bl #${originalSave};push {r0,r1,r2,r3,ip,lr};mrs ip,cpsr;push {r4,ip};bl #${save};pop {r4,ip};msr cpsr_f,ip;pop {r0,r1,r2,r3,ip,lr};pop {r4,pc}`);
 p.setWord(0x5323f274,branch(0x5323f274,saveHook),'save private film preferences after unchanged native APData save');
 expectWord(p,0x5324b42c,0xe24bd028);
 const loadHook=fn(p,`push {r0,r1,r2,r3,ip,lr};mrs ip,cpsr;push {r4,ip};bl #${load};pop {r4,ip};msr cpsr_f,ip;pop {r0,r1,r2,r3,ip,lr};sub sp,fp,#0x28;b #0x5324b430`);
 p.setWord(0x5324b42c,branch(0x5324b42c,loadHook),'load film preferences at native UserData load exit');
 return {init,save,load,saveHook,loadHook,root:ROOT};
}
export function installPreferences(p:Patch){const old=installed.get(p);if(old)return old;const x=create(p);installed.set(p,x);return x;}
