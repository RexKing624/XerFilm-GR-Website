// SPDX-License-Identifier: GPL-2.0-only
// Native GR III/IIIx additional ADJ id20 is separate from Image Control id12 and all movie entries.
import {Patch,fn,addr,u32le,expectWord,branch} from './build';
import {movWord} from './arm';
import {FILM_COUNT,FILM_FIRST_TEXT,FILM_FAMILY_ICONS} from './catalog';
import {FLAG} from './preferences';
import {installFilmState} from './film-state';import {installFilmEnabled} from './film-enabled';import {installFilmMini} from './film-mini';import {installFilmSession} from './film-session';
import facts from '../adj-facts.json';
import {FILM_SWITCH_OFF} from './assets/gr4-switch-icons';
export function installFilmAdj(p:Patch){
 const state=installFilmState(p),en=installFilmEnabled(p),mini=installFilmMini(p),session=installFilmSession(p);
 const enter=fn(p,`push {r4,lr};bl #${mini.hide};bl #${session.begin};pop {r4,pc}`),leave=fn(p,`push {r4,lr};bl #${mini.hide};bl #${session.rollback};pop {r4,pc}`);
 const icons=p.append(u32le([...FILM_FAMILY_ICONS]),4);
 const draw=fn(p,`push {r4,r5,r6,lr};mov r5,r0;mov r4,r1;mov r0,r1;bl #${en.at};mov r6,r0;ldr r0,[r5,#0x1f0];uxtb r1,r4;bl #0x53394758;cmp r6,#${FILM_COUNT};movwhs r1,#${FILM_SWITCH_OFF};bhs off;${addr('r2',icons)}ldr r1,[r2,r6,lsl #2];off:bl #0x533a1734;pop {r4,r5,r6,pc}`);
 const current=fn(p,`push {r4,r5,r6,lr};mov r4,r0;mov r5,r1;mov r0,r1;bl #${en.at};cmp r0,#${FILM_COUNT};bhs off;mov r1,r0;mov r0,r4;bl #${state.current};pop {r4,r5,r6,pc};off:mov r0,#0;cmp r5,#0;popne {r4,r5,r6,pc};${addr('r2',FLAG)}ldrb r1,[r2];cmp r1,#1;movne r0,#1;pop {r4,r5,r6,pc}`);
 const set=fn(p,`push {r4,r5,r6,lr};mov r4,r0;mov r5,r1;bl #${session.begin};mov r0,r5;bl #${en.at};cmp r0,#${FILM_COUNT};blo apply;cmp r5,#0;popne {r4,r5,r6,pc};apply:mov r1,r0;mov r0,r4;bl #${state.set};pop {r4,r5,r6,pc}`);
 const subtitle=fn(p,`push {r4,r5,r6,lr};mov r4,r0;mov r0,r1;bl #${en.at};mov r6,r0;cmp r6,#${FILM_COUNT};movhs r1,#2;bhs title;movw r2,#${FILM_FIRST_TEXT};add r1,r6,r2;title:ldr r5,[r4,#0x164];mov r0,r5;mov r2,#0;bl #0x53396f80;mov r0,r5;mov r1,#1;bl #0x53396f4c;mov r0,r4;mov r1,r6;bl #${mini.render};pop {r4,r5,r6,pc}`);
 const table=0x53b39a14,record=p.read(table+12*68,68),dv=new DataView(record.buffer);
 for(const[o,a]of [[0,enter],[8,leave],[16,subtitle],[24,draw],[32,current],[40,set],[48,en.count]]){dv.setUint32(o,a,true);dv.setUint32(o+4,0,true);}dv.setUint32(56,1,true);dv.setUint32(60,0,true);dv.setUint32(64,0,true);
 const moved=p.append(new Uint8Array([...p.read(table,20*68),...record]),16);for(const[lo,hi,r]of facts.tableSites){expectWord(p,lo,movWord(r,table&65535));expectWord(p,hi,movWord(r,table>>>16,true));p.setWord(lo,movWord(r,moved&65535),'extended independent ADJ table');p.setWord(hi,movWord(r,moved>>>16,true),'extended independent ADJ table');}
 expectWord(p,0x531a1e54,0xe2846e55);const end=fn(p,'movw r6,#0x594;add r6,r4,r6;b #0x531a1e58');p.setWord(0x531a1e54,branch(0x531a1e54,end),'scan all 21 ADJ records for allocation size');
 const original=p.read(0x53b4eba0,19);if([...original].join()!=='0,1,2,3,4,16,5,6,7,8,9,18,19,10,11,12,13,17,14')throw Error('ADJ assignment array mismatch');
 const list=p.append(Uint8Array.from([...original,20]),4);
 for(const[lo,hi,r]of facts.assignmentSites){expectWord(p,lo,movWord(r,0xeba0));expectWord(p,hi,movWord(r,0x53b4,true));p.setWord(lo,movWord(r,list&65535),'ADJ assignment includes FILM');p.setWord(hi,movWord(r,list>>>16,true),'ADJ assignment includes FILM');}
 for(let i=0;i<5;i++){const a=0x531b3bac+8*i;expectWord(p,a,0xe3a00013);p.setWord(a,0xe3a00014,'ADJ assignment count');}
 // Scoped enum wrappers keep all factory name/icon cases unchanged.
 expectWord(p,0x53292810,0xe3510000);const name=fn(p,'cmp r1,#20;movweq r0,#841;bxeq lr;cmp r1,#0;b #0x53292814');p.setWord(0x53292810,branch(0x53292810,name),'FILM name for ADJ assignment');
 expectWord(p,0x53293a30,0xe3510000);const icon=fn(p,'cmp r1,#20;movweq r0,#732;bxeq lr;cmp r1,#0;b #0x53293a34');p.setWord(0x53293a30,branch(0x53293a30,icon),'fixed FILM ADJ icon');
 return {moved,end,enter,leave,draw,current,set,subtitle,mini,session,list,name,icon};
}
