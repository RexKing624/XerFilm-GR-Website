// SPDX-License-Identifier: GPL-2.0-only
// Presentation only: reuse SelectListItem's own icon/text children and lifecycle.
import {Patch,fn,addr,expectWord,branch} from './build';
import {FILM_SWITCH_OFF,FILM_SWITCH_ON} from './assets/gr4-switch-icons';
export function installMotherPresentation(p:Patch,get:number,grain:number,stamp:number,labels:number){
 // GetRect/SetRect use the camera's rectangle type, not a new view or buffer.
 // Preserve each child's vertical position; change only horizontal placement.
 const place=fn(p,`push {r4,r5,r6,lr};sub sp,sp,#16;mov r4,r0;mov r5,r1;mov r6,r2;mov r0,sp;mov r1,r4;bl #0x533accd8;str r5,[sp];str r6,[sp,#8];mov r0,r4;mov r1,sp;ldr r3,[r0];ldr r3,[r3,#0x18];mov lr,pc;bx r3;mov r0,sp;bl #0x536b5604;add sp,sp,#16;pop {r4,r5,r6,pc}`);
 const layout=fn(p,`push {r4,r5,r6,lr};mov r4,r0;ldr r0,[r4,#0xfc];mov r1,#10;movw r2,#570;bl #${place};ldr r0,[r4,#0xf0];bl #0x5339aa58;mov r6,r0;movw r1,#660;sub r1,r1,r6;ldr r0,[r4,#0xf0];mov r2,r6;bl #${place};pop {r4,r5,r6,pc}`);
 const restore=fn(p,`push {r4,lr};mov r4,r0;ldr r0,[r4,#0xfc];mov r1,#100;movw r2,#400;bl #${place};ldr r0,[r4,#0xf0];mov r1,#40;mov r2,#60;bl #${place};pop {r4,pc}`);
 // Four existing mother rows: live switch, fixed FILM, grain switch, stamp switch.
 const draw=fn(p,`push {r4,r5,r6,lr};mov r4,r0;mov r5,r1;cmp r5,#1;beq film;cmp r5,#0;beq power;cmp r5,#2;beq grain;bl #${stamp};b boolean;grain:bl #${grain};b boolean;power:bl #${get};boolean:cmp r0,#0;movweq r6,#${FILM_SWITCH_OFF};movwne r6,#${FILM_SWITCH_ON};b paint;film:movw r6,#732;paint:mov r0,r4;mov r1,r6;${addr('r3',labels)}ldr r2,[r3,r5,lsl #2];bl #0x5339e8b0;mov r0,r4;bl #${layout};pop {r4,r5,r6,pc}`);
 // Keep the native current-index calculation for focus restoration, but hide its
 // radio dot exclusively for our mother context at this concrete Select callsite.
 const markSite=0x531be144;expectWord(p,markSite,branch(markSite,0x5339e738,true));
 const mark=fn(p,'ldr ip,[r4,#0x1d8];cmp ip,#1;moveq r1,#0;b #0x5339e738');
 p.setWord(markSite,branch(markSite,mark,true),'hide selection dot only in film mother menu');
 return {place,layout,restore,draw,mark,markSite,labelX:10,labelWidth:570,valueRight:660};
}
