// SPDX-License-Identifier: GPL-2.0-only
// All film settings reuse probe01's original Select record44 and stock page ID.
import {Patch,fn,addr,u32le,expectWord,branch} from './build';
import {movWord,assembleWords} from './arm';
import {FLAG,installPreferences} from './preferences';
import {installFilmEnabled} from './film-enabled';
import {installFilmState} from './film-state';
import {installMotherPresentation} from './mother-presentation';
import {FILM_SWITCH_OFF,FILM_SWITCH_ON} from './assets/gr4-switch-icons';
export const MENU_ID=0x020001a0,SWITCH_ID=MENU_ID+1,GRID_ID=MENU_ID+2,GRAIN_ID=MENU_ID+3,STAMP_ID=MENU_ID+4;
export const CONTEXT=0x1d8,PENDING=0x1dc,MOTHER_CURSOR=0x1e0;
const TABLE=0x53b3c6c0,HORIZON=0x0200007d,MAIN=0x0200004a;
export function installMenu(p:Patch){
 const prefs=installPreferences(p),en=installFilmEnabled(p),state=installFilmState(p);
 const target=(site:number)=>{const w=p.word(site);if((w>>>24)!==0xea)throw Error('Expected prior grid hook');return site+8+((w<<8)>>6);};
 expectWord(p,0x5317090c,movWord(0,0x228));
 const gridCtor=target(0x531be7e0),init=fn(p,`str ip,[r4,#${CONTEXT}];str ip,[r4,#${PENDING}];str ip,[r4,#${MOTHER_CURSOR}];b #${gridCtor}`);
 p.setWord(0x531be7e0,branch(0x531be7e0,init),'initialize scoped contexts before existing grid initializer');
 const controller=fn(p,`push {r4,lr};bl #0x5316f350;${addr('r1',HORIZON)}bl #0x5316f3b8;pop {r4,pc}`);
 const get=fn(p,`push {r4,lr};bl #${prefs.init};${addr('r2',FLAG)}ldrb r0,[r2];cmp r0,#1;movne r0,#0;pop {r4,pc}`);
 const assign=fn(p,`push {r4,lr};bl #0x5320ad88;bl #0x5320b31c;ldr r4,[r0,#4];movw r2,#0x918;add r2,r4,r2;mov r3,#5;scan:ldrb r0,[r2],#2;cmp r0,#20;beq done;subs r3,r3,#1;bne scan;mov r0,#20;strb r0,[r4,#0x918];done:pop {r4,pc}`);
 const set=fn(p,`cmp r1,#1;bxhi lr;push {r4,r5,r6,lr};mov r4,r1;bl #${prefs.init};cmp r4,#0;beq off;bl #${en.ensureOne};bl #${assign};bl #${en.rawFamily};mov r1,r0;b apply;off:mvn r1,#0;apply:mov r0,#0;bl #${state.set};bl #${prefs.save};pop {r4,r5,r6,pc}`);
 const titles=p.append(u32le([0,841,842,843,879,883]),4),labels=p.append(u32le([842,843,879,883]),4);
 const modes=p.append(Uint8Array.from([0,1,2,5,3,4]),4),stampLabels=p.append(u32le([2,884,885,888,886,887]),4);
 const originalCount=p.word(TABLE+44*64+8),originalDraw=p.word(TABLE+44*64+16),originalSet=p.word(TABLE+44*64+24),originalCurrent=p.word(TABLE+44*64+32);
 const count=fn(p,`ldr ip,[r0,#${CONTEXT}];cmp ip,#0;beq #${originalCount};cmp ip,#1;moveq r0,#4;bxeq lr;cmp ip,#2;moveq r0,#2;bxeq lr;cmp ip,#3;moveq r0,#1;bxeq lr;cmp ip,#4;moveq r0,#4;movne r0,#6;bx lr`);
 const presentation=installMotherPresentation(p,get,en.grain,en.stamp,labels);
 const draw=fn(p,`push {r0,r1,r2,lr};ldr ip,[r0,#${CONTEXT}];cmp ip,#1;beq keep;mov r0,r1;bl #${presentation.restore};keep:pop {r0,r1,r2,lr};ldr ip,[r0,#${CONTEXT}];cmp ip,#0;beq #${originalDraw};cmp ip,#2;beq switch;cmp ip,#1;beq mother;cmp ip,#3;beq grid;cmp ip,#4;beq grain;
  mov r0,r1;cmp r2,#0;movweq r1,#${FILM_SWITCH_OFF};movwne r1,#${FILM_SWITCH_ON};${addr('r3',stampLabels)}ldr r2,[r3,r2,lsl #2];b #0x5339e8b0;
  switch:mov r0,r1;cmp r2,#0;movweq r1,#${FILM_SWITCH_OFF};moveq r2,#2;movwne r1,#${FILM_SWITCH_ON};movne r2,#1;b #0x5339e8b0;
  grain:mov r0,r1;cmp r2,#0;movweq r1,#${FILM_SWITCH_OFF};movwne r1,#${FILM_SWITCH_ON};moveq r2,#2;movw r3,#879;addne r2,r2,r3;b #0x5339e8b0;
  grid:mov r0,r1;mov r1,#0;movw r2,#843;b #0x5339e8b0;
  mother:mov r0,r1;mov r1,r2;b #${presentation.draw}`);
 const grainSet=fn(p,`mov r0,r1;b #${en.setGrain}`),stampSet=fn(p,`cmp r1,#5;bxhi lr;${addr('r3',modes)}ldrb r0,[r3,r1];b #${en.setStamp}`);
 const current=fn(p,`ldr ip,[r0,#${CONTEXT}];cmp ip,#0;beq #${originalCurrent};cmp ip,#1;ldreq r2,[r0,#${MOTHER_CURSOR}];beq compare;cmp ip,#3;moveq r2,#0;beq compare;
  push {r4,lr};mov r4,r1;cmp ip,#2;beq switch;cmp ip,#4;beq grain;${addr('r3',modes)}ldrb r4,[r3,r4];bl #${en.stamp};b got;switch:bl #${get};b got;grain:bl #${en.grain};got:cmp r0,r4;moveq r0,#1;movne r0,#0;pop {r4,pc};
  compare:cmp r2,r1;moveq r0,#1;movne r0,#0;bx lr`);
 const setter=fn(p,`ldr ip,[r0,#${CONTEXT}];cmp ip,#0;beq #${originalSet};cmp ip,#2;beq #${set};cmp ip,#4;beq #${grainSet};cmp ip,#5;beq #${stampSet};bx lr`);
 for(const[o,a]of [[8,count],[16,draw],[24,setter],[32,current]]){expectWord(p,TABLE+44*64+o+4,0);p.setWord(TABLE+44*64+o,a,'scoped callback in original native record44');}
 const nativeSlotHeader=fn(p,`ldrh r1,[r3,#4];ldrb ip,[r4,#0x198];cmp ip,#44;bne done;ldr ip,[r4,#${CONTEXT}];cmp ip,#1;blo done;cmp ip,#5;bhi done;${addr('r3',titles)}ldr r1,[r3,ip,lsl #2];done:b #0x531ba660`);
 expectWord(p,0x531ba65c,assembleWords('ldrh r1,[r3,#4]',0)[0]);p.setWord(0x531ba65c,branch(0x531ba65c,nativeSlotHeader),'context-specific header with original native title fallback');
 // Publish pending context only at InitSettings, after the old page has left.
 // Both target and parent exposed to the native engine stay original IDs.
 const request=fn(p,`${addr('ip',MENU_ID)}subs ip,r1,ip;cmp ip,#4;bls film;${addr('ip',HORIZON)}cmp r1,ip;bne out;push {r0,r1,r2,r3,ip,lr};bl #${controller};mov r1,#0;str r1,[r0,#${PENDING}];pop {r0,r1,r2,r3,ip,lr};b out;
  film:push {r0,r1,r2,r3,ip,lr};add r3,ip,#1;push {r3,r4};bl #${controller};pop {r3,r4};str r3,[r0,#${PENDING}];pop {r0,r1,r2,r3,ip,lr};${addr('r1',HORIZON)}${addr('r2',MAIN)}out:mov ip,sp;b #0x5316c9dc`);
 expectWord(p,0x5316c9d8,0xe1a0c00d);p.setWord(0x5316c9d8,branch(0x5316c9d8,request),'verified native transport ID with pending film context');
 const applyContext=fn(p,`ldr ip,[r1];${addr('r3',HORIZON)}cmp ip,r3;bne other;ldr ip,[r0,#${PENDING}];cmp ip,#5;ldrhi ip,[r0,#${CONTEXT}];b store;other:mov ip,#0;store:str ip,[r0,#${CONTEXT}];mov ip,#255;str ip,[r0,#${PENDING}];mov ip,sp;b #0x531b9fb4`);
 expectWord(p,0x531b9fb0,0xe1a0c00d);p.setWord(0x531b9fb0,branch(0x531b9fb0,applyContext),'apply context after original Leave');
 const factoryHook=fn(p,`${addr('ip',MENU_ID)}subs ip,r1,ip;cmp ip,#4;movwls r1,#0x7d;movtls r1,#0x200;movw r3,#0x13b;b #0x5316f3bc`);
 expectWord(p,0x5316f3b8,movWord(3,0x13b));p.setWord(0x5316f3b8,branch(0x5316f3b8,factoryHook),'fallback aliases retain original native Select cache');
 const back=fn(p,`${addr('r1',MENU_ID)}${addr('r2',MAIN)}b #0x5316c9d8`);
 const accept=fn(p,`push {r4,r5,r6,lr};mov r4,r0;ldr r5,[r0,#${CONTEXT}];ldr r0,[r0,#0x18c];bl #0x53394820;mov r6,r0;cmp r5,#1;beq open;mov r1,r6;mov r0,r4;bl #${setter};bl #${prefs.save};mov r0,r4;bl #${back};pop {r4,r5,r6,pc};
  open:cmp r6,#3;pophi {r4,r5,r6,pc};str r6,[r4,#${MOTHER_CURSOR}];${addr('r1',SWITCH_ID)}add r1,r1,r6;${addr('r2',MAIN)}mov r0,r4;bl #0x5316c9d8;pop {r4,r5,r6,pc}`);
 const gridKeys=target(0x531be2d8),keys=fn(p,`ldr r2,[r0,#${CONTEXT}];cmp r2,#0;beq #${gridKeys};cmp r2,#3;beq #${gridKeys};ldrh r3,[r1];cmp r3,#0xd8;beq #${accept};cmp r3,#0xcf;beq #${accept};cmp r2,#1;beq mother;cmp r3,#0xda;beq #${back};cmp r3,#0xce;beq #${back};b #${gridKeys};mother:cmp r3,#0xcf;beq #${accept};cmp r3,#0xce;beq #0x5316ca28;b #${gridKeys}`);
 p.setWord(0x531be2d8,branch(0x531be2d8,keys),'scoped mother and child confirm/back');
 const gridDispatch=target(0x5316d5dc),dispatch=fn(p,`push {r0,r1,r2,r3,ip,lr};ldr r2,[r0];${addr('r3',0x53b3c4c8)}cmp r2,r3;bne native;ldr r2,[r0,#${CONTEXT}];cmp r2,#0;beq native;cmp r2,#3;beq native;
  ldrh r3,[r1];cmp r3,#8;beq physical;cmp r3,#11;beq physical;cmp r3,#12;beq physical;cmp r3,#0xd8;beq managed;cmp r3,#0xcf;beq managed;cmp r3,#0xce;beq managed;cmp r2,#1;beq native;cmp r3,#0xda;bne native;
  managed:pop {r0,r1,r2,r3,ip,lr};push {r4,lr};bl #${keys};mov r0,#1;pop {r4,pc};
  physical:ldr r2,[r1,#4];cmp r2,#0;beq consumed;ldrb r2,[r2];cmp r2,#2;bne consumed;cmp r3,#11;moveq r2,#0xce;movne r2,#0xcf;cmp r3,#8;moveq r2,#0xd8;sub sp,sp,#8;str r2,[sp];ldr r2,[r1,#4];str r2,[sp,#4];mov r1,sp;bl #${keys};add sp,sp,#8;
  consumed:pop {r0,r1,r2,r3,ip,lr};mov r0,#1;bx lr;native:pop {r0,r1,r2,r3,ip,lr};b #${gridDispatch}`);
 p.setWord(0x5316d5dc,branch(0x5316d5dc,dispatch),'consume scoped confirm before native view/close dispatch');
 const gridButton=target(0x531ba21c),button=fn(p,`ldr r2,[r0,#${CONTEXT}];cmp r2,#0;beq #${gridButton};cmp r2,#3;beq #${gridButton};b #${accept}`);
 p.setWord(0x531ba21c,branch(0x531ba21c,button),'touch confirm uses same mother/child action');
 const gridFooter=target(0x531ba284),footer=fn(p,`ldr r2,[r0];ldr r2,[r2];ldr r3,[r2,#${CONTEXT}];cmp r3,#0;beq #${gridFooter};cmp r3,#3;beq #${gridFooter};mov r0,r2;b #${accept}`);
 p.setWord(0x531ba284,branch(0x531ba284,footer),'touch footer consumes action before stock close');
 const cancelFooter=fn(p,`ldr r2,[r0];ldr r2,[r2];ldr r3,[r2,#${CONTEXT}];cmp r3,#1;bls native;cmp r3,#5;bhi native;mov r0,r2;b #${back};native:mov ip,sp;b #0x531ba2f8`);
 expectWord(p,0x531ba2f4,0xe1a0c00d);p.setWord(0x531ba2f4,branch(0x531ba2f4,cancelFooter),'child touch-back returns to film mother');
 const top=fn(p,`push {r4,lr};mov r4,r1;bl #${get};movw r1,#732;mov r2,#0;mov r0,r4;bl #0x5339df08;mov r0,r4;movw r1,#841;mov r2,r1;pop {r4,lr};b #0x5339dc70`);
 const original=p.read(0x53b36dec,0x384);
 function still(remove:number){const b=original.slice(),v=new DataView(b.buffer),items=Array.from({length:38},(_,i)=>i).filter(i=>i!==remove);for(const[j,i]of items.entries())for(const[o,n]of [[0x8c,8],[0x1bc,4],[0x254,8]])b.set(original.subarray(o+i*n,o+(i+1)*n),o+j*n);v.setUint32(0x8c+37*8,top,true);v.setUint32(0x90+37*8,0,true);v.setUint32(0x1bc+37*4,MENU_ID,true);v.setUint32(0x254+37*8,0,true);v.setUint32(0x258+37*8,0,true);b.set(remove===25?[0,8,16,19,25,30,34]:[0,8,15,18,25,30,34],0x80);return p.append(b,16);}
 const regular=still(25),hdf=still(13),build=fn(p,`push {r0,r1,r2,r3,ip,lr};bl #0x5320ad88;bl #0x5320c09c;bl #0x532dbee8;${addr('r1',regular)}cmp r0,#1;movweq r1,#${hdf&65535};movteq r1,#${hdf>>>16};${addr('r2',0x55001eb8)}str r1,[r2];pop {r0,r1,r2,r3,ip,lr};mov ip,sp;b #0x5319a77c`);
 expectWord(p,0x5319a778,0xe1a0c00d);p.setWord(0x5319a778,branch(0x5319a778,build),'retain verified probe01 main-entry shape');
 return {presentation,lists:TABLE,init,controller,get,set,current,count,draw,setter,originalCount,originalDraw,originalSet,originalCurrent,request,applyContext,factoryHook,nativeSlotHeader,keys,dispatch,accept,back,button,footer,cancelFooter,regular,hdf,top,build,grainSet,stampSet,assign,context:CONTEXT,pending:PENDING,motherCursor:MOTHER_CURSOR};
}
