// SPDX-License-Identifier: GPL-2.0-only
// GR III 2.10 / GR IIIx 1.60 shared ARM adapter. No GR IV addresses are used here.
import {assembleWords,wordsToBytes,movWord} from './arm';
export const BASE=0x53000000,OFFICIAL_RTOS_LENGTH=0x10b55c0,APPEND_LIMIT=0x55000000;
export const RAM={source:0x5407b540,destination:0x55000000,length:0x3a080,bss:0x5503a100};
export const ICON_CATALOG=0x540b5600,TEXT_CATALOG=0x540b6600,LANGUAGES=21,TEXT_CAPACITY=896;
export const NATIVE_ICON_CATALOG=0x550020fc,NATIVE_TEXT_ROOTS=0x55002bac,NATIVE_ICON_COUNT=0x29f,NATIVE_TEXT_COUNT=0x312;
export type WordEdit={address:number,before:number,after:number,reason:string};
export class Patch{
 private data:Uint8Array;private len:number;readonly words:WordEdit[]=[];
 constructor(original:Uint8Array){if(original.length!==OFFICIAL_RTOS_LENGTH)throw Error('Wrong native RTOS size');this.data=new Uint8Array(APPEND_LIMIT-BASE);this.data.set(original);this.len=original.length;}
 get length(){return this.len;}
 next(align:number){return BASE+Math.ceil(this.len/align)*align;}
 extendTo(size:number){if(size<this.len||BASE+size>=APPEND_LIMIT)throw Error('Invalid image extension');this.len=size;}
 append(input:Uint8Array|readonly number[]|((address:number)=>readonly number[]),alignment=4){
  const at=this.next(alignment),blob=typeof input==='function'?wordsToBytes(input(at)):input instanceof Uint8Array?input:wordsToBytes(input);
  if(at+blob.length>=APPEND_LIMIT)throw Error('RTOS extension overlaps writable data');this.data.set(blob,at-BASE);this.len=at-BASE+blob.length;return at;
 }
 private off(address:number,n:number){const at=address-BASE;if(at<0||at+n>this.len)throw Error(`Outside RTOS image: ${address.toString(16)}`);return at;}
 read(a:number,n:number){return this.data.slice(this.off(a,n),this.off(a,n)+n);}
 readMapped(a:number,n:number){if(a>=RAM.destination&&a+n<=RAM.destination+RAM.length)a=RAM.source+a-RAM.destination;return this.read(a,n);}
 word(a:number){return new DataView(this.data.buffer).getUint32(this.off(a,4),true);}
 mappedWord(a:number){return new DataView(this.readMapped(a,4).buffer).getUint32(0,true);}
 write(a:number,bytes:Uint8Array){this.data.set(bytes,this.off(a,bytes.length));}
 setWord(a:number,v:number,reason:string){const before=this.word(a);new DataView(this.data.buffer).setUint32(this.off(a,4),v>>>0,true);if(a<BASE+OFFICIAL_RTOS_LENGTH)this.words.push({address:a,before,after:v>>>0,reason});}
 bytes(){return this.data.slice(0,this.len);}
}
export const u32le=wordsToBytes;
export function u16le(v:readonly number[]){const out=new Uint8Array(v.length*2);v.forEach((x,i)=>new DataView(out.buffer).setUint16(i*2,x,true));return out;}
export function concat(v:readonly Uint8Array[]){const out=new Uint8Array(v.reduce((x,y)=>x+y.length,0));let at=0;for(const b of v){out.set(b,at);at+=b.length;}return out;}
export function utf16z(s:string){return u16le([...Array.from({length:s.length},(_,i)=>s.charCodeAt(i)),0]);}
export function expectWord(p:Patch,a:number,w:number){if(p.word(a)!==(w>>>0))throw Error(`Native instruction mismatch at ${a.toString(16)}: ${p.word(a).toString(16)} != ${(w>>>0).toString(16)}`);}
export function branch(a:number,b:number,link=false){const d=b-a-8;if(d%4||d<-(1<<25)||d>=(1<<25))throw Error('Branch outside ARM range');return ((link?0xeb000000:0xea000000)|((d>>2)&0xffffff))>>>0;}
export function fn(p:Patch,s:string){return p.append(a=>assembleWords(s,a),16);}
export const addr=(r:string,a:number)=>`movw ${r},#${a&65535};movt ${r},#${a>>>16};`;
export const LOOKUP_BOUNDS=[[0x53209fb8,3],[0x53209fec,3],[0x5320a7cc,1]] as const;
export function initializeCatalogs(p:Patch){
 const icons=p.readMapped(NATIVE_ICON_CATALOG,NATIVE_ICON_COUNT*4);
 const rows=Array.from({length:21},(_,i)=>p.readMapped(p.mappedWord(NATIVE_TEXT_ROOTS+i*4),NATIVE_TEXT_COUNT*4));
 p.extendTo(TEXT_CATALOG-BASE+0x100+21*TEXT_CAPACITY*4);
 p.write(ICON_CATALOG,icons);
 for(let i=0;i<21;i++){const row=TEXT_CATALOG+0x100+i*TEXT_CAPACITY*4;p.setWord(TEXT_CATALOG+i*4,row,'new language directory');p.write(row,rows[i]);}
 for(const [lo,hi,reg] of [[0x53209fcc,0x53209fd0,3],[0x5320a000,0x5320a004,3],[0x5320a804,0x5320a808,2]] as const){
  expectWord(p,lo,movWord(reg,NATIVE_ICON_CATALOG&65535));expectWord(p,hi,movWord(reg,NATIVE_ICON_CATALOG>>>16,true));
  p.setWord(lo,movWord(reg,ICON_CATALOG&65535),'extended GR III icon directory');p.setWord(hi,movWord(reg,ICON_CATALOG>>>16,true),'extended GR III icon directory');
 }
 for(const [lo,hi] of [[0x533966e8,0x533966f0],[0x533970fc,0x53397100]] as const){
  expectWord(p,lo,movWord(3,NATIVE_TEXT_ROOTS&65535));expectWord(p,hi,movWord(3,NATIVE_TEXT_ROOTS>>>16,true));
  p.setWord(lo,movWord(3,TEXT_CATALOG&65535),'extended GR III text directory');p.setWord(hi,movWord(3,TEXT_CATALOG>>>16,true),'extended GR III text directory');
 }
 for(const a of [0x533966d4,0x533970ec]){expectWord(p,a,movWord(3,0x311));p.setWord(a,movWord(3,895),'extended text bounds');}
 // New icon pixels live in the free RX RTOS tail. Leave ICONBIN and all its
 // referenced RAM tail untouched. Bit31 is an internal absolute-pixel marker.
 const site=0x5320a834;expectWord(p,site,0xe08ec106);
 const pixel=fn(p,`push {r0};mrs r0,cpsr;tst r6,#0x80000000;bicne ip,r6,#0x80000000;addeq ip,lr,r6,lsl #2;msr cpsr_f,r0;pop {r0};b #${site+4}`);
 p.setWord(site,branch(site,pixel),'custom GR III pixel pointer; native ICONBIN remains unchanged');
 return {pixel};
}
export function installText(p:Patch,id:number,s:string,lang?:number){
 if(id>=TEXT_CAPACITY)throw Error('Text outside catalog');const raw=p.append(utf16z(s),4),d=p.append(concat([Uint8Array.from([s.length+1,1,0,0]),u32le([raw])]),4);
 for(let l=0;l<21;l++)if(lang===undefined||lang===l)p.setWord(p.word(TEXT_CATALOG+4*l)+4*id,d,'film text');return d;
}
export function installIcon(p:Patch,id:number,width:number,height:number,pixels:Uint8Array){
 if(id<NATIVE_ICON_COUNT||id>=1024||pixels.length!==width*height*4)throw Error('Invalid added icon');
 if(p.word(ICON_CATALOG+4*id)!==0)throw Error('Icon id already in use');
 const data=p.append(pixels,16),desc=p.append(concat([u16le([width,height]),u32le([(data|0x80000000)>>>0])]),4);
 p.setWord(ICON_CATALOG+4*id,desc,'film icon descriptor');return{data,desc};
}
export function updateIconBounds(p:Patch,max:number){for(const[a,r]of LOOKUP_BOUNDS){expectWord(p,a,movWord(r,0x29e));p.setWord(a,movWord(r,max),'extended icon bounds');}}
