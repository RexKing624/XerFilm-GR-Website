// SPDX-License-Identifier: GPL-2.0-only
import {Patch,initializeCatalogs,installText,installIcon,updateIconBounds} from './build';
import {readFileSync} from 'node:fs';
import {FILM_ICONS,FILM_NAMES,FILM_CHILD_LABELS} from './catalog';
import {gridIcon} from './film-grid';
import {FILM_SWITCH_OFF,FILM_SWITCH_ON,GR4_SWITCH_OFF,GR4_SWITCH_ON} from './assets/gr4-switch-icons';
export function installResources(p:Patch){
 const native=initializeCatalogs(p);const icons=[];
 for(let i=0;i<FILM_ICONS.length;i++)icons.push({id:721+i,...installIcon(p,721+i,40,40,FILM_ICONS[i]),width:40,height:40});
 for(let family=0;family<17;family++)for(const focus of [false,true])for(const on of [false,true]){
  const id=788+family*4+Number(focus)*2+Number(on);icons.push({id,...installIcon(p,id,164,92,gridIcon(family,on,focus)),width:164,height:92});
 }
 for(const[id,pixels]of [[FILM_SWITCH_OFF,GR4_SWITCH_OFF],[FILM_SWITCH_ON,GR4_SWITCH_ON]] as const)icons.push({id,...installIcon(p,id,40,40,pixels),width:40,height:40});
 for(let i=0;i<2;i++)icons.push({id:858+i,...installIcon(p,858+i,40,40,new Uint8Array(readFileSync(new URL(`../cinema-input/cinema-${i}.rgba`,import.meta.url)))),width:40,height:40});
 updateIconBounds(p,859);
 installText(p,889,'Cinema (Yellow)');installText(p,890,'Cinema (Green)');
 installText(p,889,'电影（黄）',19);installText(p,890,'电影（绿）',19);installText(p,889,'電影（黃）',18);installText(p,890,'電影（綠）',18);
 FILM_NAMES.forEach((s,i)=>installText(p,846+i,s));FILM_CHILD_LABELS.forEach((s,i)=>installText(p,863+i,s));
 for(const[id,en,zh,zht]of [[841,'Film Simulation','胶片模拟','膠片模擬'],[842,'On/Off','开关','開關'],[843,'Film List','胶片列表','膠片列表'],[877,'Toggle','启用/停用','啟用/停用'],[878,'Back','返回','返回'],[879,'Grain','颗粒','顆粒'],[880,'Weak','弱','弱'],[881,'Medium','中','中'],[882,'Strong','强','強'],[883,'Timestamp','时间戳','時間戳'],[884,'YY.MM.DD hh:mm','年.月.日 时:分','年.月.日 時:分'],[885,'DD.MM hh:mm YY','日.月 时:分 年','日.月 時:分 年'],[886,'Date','日期','日期'],[887,'Time','时间','時間'],[888,'Date + Time','日期＋时间','日期＋時間']] as const){installText(p,id,en);installText(p,id,zh,19);installText(p,id,zht,18);}
 return {icons,...native};
}
