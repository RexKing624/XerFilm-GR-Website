// SPDX-License-Identifier: GPL-2.0-only
// Clang ARMv7 reference assembly; leaf, position-independent, no literal/global relocations.
export const CAPTURE_PUBLISH = [0xe1a02000,0xe1920f9f,0xe3500000,0x1a000004,0xf57ff05b,0xe1823f91,0xe3530000,0x1afffff8,0xe1a00001,0xf57ff01f,0xf57ff05b,0xe12fff1e] as const;
export const CAPTURE_INCREMENT = [0xe1a02000,0xe1920f9f,0xe2801001,0xe1823f91,0xe3530000,0x1afffffa,0xf57ff05b,0xe12fff1e] as const;
