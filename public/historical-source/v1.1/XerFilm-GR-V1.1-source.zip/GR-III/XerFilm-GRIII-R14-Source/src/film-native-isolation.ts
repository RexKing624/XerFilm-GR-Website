// SPDX-License-Identifier: GPL-2.0-only
// GR III 2.10: virtual Std applies to still shooting only. Native saved recipes,
// custom-slot identities, movie controls and the original UserData stay intact.
import {Patch,fn,addr,expectWord,branch} from './build';
import {FLAG} from './preferences';

export function installNativeIsolation(p:Patch){
 const active=`${addr('r3',FLAG)}ldrb r3,[r3];cmp r3,#1;bne native;`;
 const still='ldr r3,[r0,#4];ldrb r3,[r3,#0x44];cmp r3,#0;bne native;';
 const modelStill='ldrb r3,[r0,#0x1b];cmp r3,#0;bne native;';
 function getter(site:number,word:number,value:number,guard:string,original:string){
  expectWord(p,site,word);
  const hook=fn(p,`push {r2,r3};mrs r2,cpsr;${active}${guard}msr cpsr_f,r2;pop {r2,r3};mov r0,#${value};bx lr;native:msr cpsr_f,r2;pop {r2,r3};${original};b #${site+4}`);
  p.setWord(site,branch(site,hook),'still FILM virtual Std; saved native controls unchanged');return hook;
 }
 const bank=getter(0x53244284,0xe5903004,0,still,'ldr r3,[r0,#4]');
 const style=getter(0x53244290,0xe5903004,11,still,'ldr r3,[r0,#4]');
 const configStyle=getter(0x53271480,0xe1a0c00d,11,still,'mov ip,sp');
 const displayStyle=getter(0x5326c1cc,0xe1a0c00d,11,still,'mov ip,sp');
 const effective=getter(0x532bd6b4,0xe1a0c00d,11,modelStill,'mov ip,sp');
 const modelBank=getter(0x532bd6d4,0xe1a0c00d,0,modelStill,'mov ip,sp');
 expectWord(p,0x532c26c0,0xe1a0c00d);
 const blockNative=fn(p,`push {r2,r3};mrs r2,cpsr;${active}${modelStill}msr cpsr_f,r2;pop {r2,r3};bx lr;native:msr cpsr_f,r2;pop {r2,r3};mov ip,sp;b #0x532c26c4`);
 p.setWord(0x532c26c0,branch(0x532c26c0,blockNative),'block native still filter edits only while FILM is active');

 // The actual UserData::Apply packet, immediately before CameraControl accepts
 // it. Neutralize the same bytes as the official Std constructor; never edit
 // persistent recipes or ShotInfo. Fixing a UI getter alone did not do this.
 const neutral=[11,4,4,4,4,4,4,1,4,0,1,4,0,0,0];
 const stores=neutral.map((v,i)=>`mov r3,#${v};strb r3,[r6,#${0xb8+i}];`).join('');
 expectWord(p,0x53279a08,0xe1a01006);
 const cinemaStores=neutral.slice(1).map((v,i)=>`mov r3,#${v};strb r3,[r6,#${0xb9+i}];`).join('');
 const packet=fn(p,`push {r2,r3};mrs r2,cpsr;ldr r3,[r4,#4];ldrb r3,[r3,#0x44];cmp r3,#0;bne native;${addr('r3',FLAG)}ldrb r3,[r3];cmp r3,#1;beq film;ldrb r3,[r6,#0xb8];sub r3,r3,#25;cmp r3,#2;bhs native;${cinemaStores}b extras;film:${stores}extras:mov r3,#4;strb r3,[r6,#0xcf];strb r3,[r6,#0xd0];native:msr cpsr_f,r2;pop {r2,r3};mov r1,r6;b #0x53279a0c`);
 p.setWord(0x53279a08,branch(0x53279a08,packet),'actual still camera packet uses neutral Std while FILM is on');

 // Apply packet 0x82 already emits its own native change event on every
 // application. Retain that event writer unchanged; do not add per-frame
 // notifications or touch the shared/raw-development tone setter.
 return {bank,style,configStyle,displayStyle,effective,modelBank,blockNative,packet,neutral};
}
