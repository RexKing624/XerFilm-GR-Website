from pathlib import Path
import importlib.util,struct,json,hashlib
from unicorn import UC_HOOK_CODE
from unicorn.arm_const import *
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('port_emu',R/'test-port.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
results=[]
for model in ['GRIII']:
 e=mod.Emu(model);u=e.u;m=e.m;checks=[]
 # Pixel/format suite stubs cache services. The separate entry suite executes
 # the real native cache dispatcher against distinct CPU/DMA buffers.
 e.stubs[0x5383c870]=lambda:0
 u.hook_del(e.hookHandle)
 for address in e.stubs:u.hook_add(UC_HOOK_CODE,e.hook,begin=address,end=address)
 def ck(v,msg):assert v,(model,msg);checks.append(msg)
 e.call(m['preferences']['init']);W,H,S=320,214,352;Y,C,RAW,PY,PC=0x70800000,0x70900000,0x70a00000,0x70b00000,0x70c00000
 CFG,D,SHOT=0x70008000,0x70009000,0x7000a000;size=S*H
 e.w32(0x70003004,0x7000b000)
 proof=json.loads((R/'stamp-research/module-proof.json').read_text());layout=m['stamp']['code']+proof['symbols']['layout'];runs=[]
 def capture(u,at,size,data):
  if at==layout:runs.append(bytes(u.mem_read(e.reg(0),e.reg(1))))
 u.hook_add(UC_HOOK_CODE,capture,begin=layout,end=layout)
 def reset(on=1,look=0,grain=0,stamp=0,sv=5.,year=2026):
  runs.clear();u.mem_write(Y,bytes([100])*size);u.mem_write(C,bytes([120,140])*(size//2));u.mem_write(RAW,bytes([57])*size);u.mem_write(PY,bytes([110])*size);u.mem_write(PC,bytes([128])*size)
  for a in [Y,C,RAW,PY,PC]:u.mem_write(a-64,b'\x5a'*64);u.mem_write(a+size,b'\xa5'*64)
  u.mem_write(D,struct.pack('<B3xIII HHHH HH 4x',1,Y,C,0,W,H,S,H,3,7));u.mem_write(D+32,struct.pack('<B3xIII HHHH HH 4x',1,PY,PC,0,W,H,S,H,0,0))
  u.mem_write(CFG,bytes(96));e.w32(CFG+0x34,SHOT);e.w32(CFG+0x3c,D);e.w32(CFG+0x40,D+32)
  u.mem_write(SHOT,bytes(4096));u.mem_write(SHOT+0xb60,struct.pack('<f',sv));e.time=struct.pack('<H6B',year,10,19,21,36,0,0)+bytes(8)
  e.attach(SHOT,look,on,grain,stamp);e.w8(mod.SELECT,(look+7)%27);e.w8(mod.FLAG,1-on)
 def snap():return [bytes(u.mem_read(a,size)) for a in [Y,C,RAW,PY,PC]]
 def render():return e.call(m['stamp']['code'],m['stamp']['ctx'],CFG,limit=12000000)
 def chars(g):return ''.join(str(x)if x<10 else{16:"'",17:' ',18:'.',19:':'}.get(x,'?')for x in g)
 for on in [0,1]:
  reset(on=on);before=snap();render();ck(before==snap(),'grain and stamp OFF are pixel-identical')
 reset(on=0,grain=3,stamp=5);before=snap();render();ck(before==snap(),'film OFF bypasses configured grain and timestamp')
 stats=[]
 for sv in [5.,7.,7+1/3,8.,8+1/3]:
  for strength in [1,2,3]:
   reset(grain=strength,sv=sv);before=snap();shot=bytes(u.mem_read(SHOT,4096));render();after=snap();ck(after[0]!=before[0],'JPG luminance grain applied');ck(after[1:]==before[1:],'grain leaves chroma RAW and shared preview intact');ck(bytes(u.mem_read(SHOT,4096))==shot,'grain does not write ShotInfo')
   ck(all(after[0][y*S+W:(y+1)*S]==bytes([100])*(S-W)for y in range(H)),'grain respects row padding')
   stats.append(dict(sv=sv,strength=strength,meanAbs=round(sum(abs(z-100)for row in range(H)for z in after[0][row*S:row*S+W])/(W*H),3)))
 # ISO adaptation must grow coarser AND stronger, while each menu level
 # remains ordered at every ISO band.
 for strength in [1,2,3]:
  values=[z['meanAbs']for z in stats if z['strength']==strength and z['sv']in [5.,7+1/3,8+1/3]]
  ck(values[0]<values[1]<values[2],'grain increases across ISO bands')
 for sv in [5.,7.,7+1/3,8.,8+1/3]:
  values=[z['meanAbs']for z in stats if z['sv']==sv]
  ck(values[0]<values[1]<values[2],'weak medium strong remain ordered')
 # Actual generated glyph runs: five formats, two-digit years, BW identity.
 for year in [1999,2000]:
  for mode in range(1,6):
   for look in [0,10]:
    reset(stamp=mode,look=look,year=year);before=snap();render();after=snap();yy=f'{year%100:02}';expected={1:f'{yy}.10.19 21:36',2:f'19.10 21:36 {yy}',3:f'{yy}.10.19',4:'21:36',5:f'{yy}.10.19 21:36'}[mode]
    ck(bool(runs) and ([chars(x)for x in runs]==[expected]*2 if mode!=5 else [chars(x)for x in runs]==[f'{yy}.10.19']*2+['21:36']*2),'format and year '+expected)
    ck(after[0]!=before[0] and after[2:]==before[2:],'timestamp changes main JPG only')
    if look==10:ck(min(after[1][::2])>=120 and max(after[1][1::2])<=140,'BW film uses neutral timestamp ink')
    else:ck(min(after[1])<120 and max(after[1])>140,'colour film uses orange timestamp ink')
    for a in [Y,C,RAW,PY,PC]:ck(bytes(u.mem_read(a-64,64))==b'\x5a'*64 and bytes(u.mem_read(a+size,64))==b'\xa5'*64,'image guards intact')
 # Same-shot MakerNote identity: no previous-shot carry-over, shared native VT untouched.
 setter=e.alloc(64);tag=e.alloc(64)
 for look in [10,11,26,0]:
  reset(look=look);e.w32(setter+0x18,SHOT);e.w16(tag+4,0x4f);e.w32(tag+0x10,0);e.call(m['metadata']['dispatch'],setter,tag);ck(int.from_bytes(u.mem_read(tag+12,2),'little')==0x8200+look,'ordinary JPG writes its own exposure look')
  # Actual shared native decoder writes only Standard into derived ShotInfo.
  dest=e.alloc(4096);u.reg_write(UC_ARM_REG_R4,dest);e.call(0x535bf7c4,0x8200+look,until=0x535bf7e8);ck(e.byte(dest+0x77c)==11,'JPEG decode native style stays Standard')
  e.call(0x535c2508,0x8200+look,until=0x535c2528);ck(e.reg(2)==128+look,'JPEG identity property matches its tag')
 ck(e.word(0x53d31374)==0x53606738,'original shared JPEG/DNG setter vtable untouched')
 result=dict(model=model,checks=len(checks),status='passed',pixelStats=stats,hardwareTested=False,clockAndCacheServicesStubbed=True);results.append(result);print(model,len(checks),'JPG pixel/format/identity checks passed',flush=True)
(R/'jpg-checks.json').write_text(json.dumps(results,indent=2))
