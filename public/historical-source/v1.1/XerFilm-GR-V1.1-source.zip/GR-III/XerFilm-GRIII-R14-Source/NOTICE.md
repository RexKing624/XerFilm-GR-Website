XerFilm GR III Series R1 — 2026-10-19

The firmware container codec, ARM assembler and GRMod-derived date imprint are GPL-2.0-only components. The original license is included. Existing XerFilm v23 film resources and interaction designs are retained, with GR III/IIIx-specific menu, state, processing and JPEG adapters.

GR III image-pipeline ABI research was cross-checked with the local gr3-film-mods project and its FINDINGS, including native MultiAxial enablement and the ImageTuning test fixture. Its emu.py and run_tuning.py are included only as offline test support, under its supplied MIT license (Copyright 2026 idontknownihil). No third-party compiled firmware was used as the base; both bases are pinned official Ricoh files.

Camera manufacturer firmware binaries and film/brand names remain the property of their respective rights holders. This source package describes the modifications; it does not contain Ricoh's proprietary original firmware source. Place the separately obtained official firmware at the documented input paths to rebuild.

R13 (2026-10-21) adds two separate native Cinema effects to the verified GR III R12 base. Native list-extension and enum conversion locations were cross-checked against gr3-film-mods make_slots15/16 (MIT, Copyright 2026 idontknownihil); its compiled firmware and carving strategy are not used. The MIT native-pipeline fixtures are retained in test-support/cinema with their license. Native Cinema extracted data and icons remain Ricoh data; code licenses do not relicense those assets. No new license claims are made over camera firmware.
