# SPDX-License-Identifier: GPL-2.0-only
from pathlib import Path
import subprocess,sys,json,hashlib
r=Path(__file__).resolve().parent
before=hashlib.sha256((r/'resource-build/GRIII/image.rtos').read_bytes()).hexdigest()
for name in ['test-menu-native.py','test-switch-icons.py','test-port.py','test-resources.py','test-jpg.py','test-jpg-entry.py','test-exif-date.py','test-native-colour.py','test-native-isolation.py','test-child-family-accept.py','test-cinema-ui.py','test-cinema-colour.py','test-settings-image-control.py']:
 print('Checking',name,flush=True)
 subprocess.run([sys.executable,str(r/name)],check=True)
assert before==hashlib.sha256((r/'resource-build/GRIII/image.rtos').read_bytes()).hexdigest()
for name in ['menu-native-checks.json','switch-icon-checks.json','port-checks.json','resources-checks.json','jpg-checks.json','jpg-entry-checks.json','exif-date-checks.json','native-colour-checks.json','native-isolation-checks.json','child-family-accept-checks.json','cinema-ui-checks.json','cinema-colour-checks.json','settings-image-control-checks.json']:
 report=json.loads((r/name).read_text());rows=report if isinstance(report,list) else [report]
 assert rows and all(x['status']=='passed' and x['hardwareTested']==False for x in rows),name
(r/'verified-images.json').write_text(json.dumps({'GRIII':before},indent=2))
print('All current R14 offline suites passed for',before,flush=True)
