import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {Firmware,sectionsOf} from '../gr4-kodak-fw-v23/core/src/fw/container';
const source='work/gr4-kodak-fw-v23/build-v23-a/candidate.bin';
const fw=new Firmware(new Uint8Array(readFileSync(source))),ss=sectionsOf(fw.decoded),rt=ss.find(s=>s.name==='RTOS')!,ic=ss.find(s=>s.name==='ICONBIN')!;
const r=fw.decoded.slice(rt.offset,rt.offset+rt.size),v=new DataView(r.buffer);
function off(a:number){return (a>=0x55000000&&a<0x55057480?0x5437b640+a-0x55000000:a)-0x53000000;}
const word=(a:number)=>v.getUint32(off(a),true);
for(const id of [310,311]){
 const desc=word(0x543d3ac0+id*4),o=off(desc),raw=r.slice(o,o+16);console.log(JSON.stringify({id,desc:desc.toString(16),raw:Array.from(raw),u16:[0,2,4,6].map(x=>v.getUint16(o+x,true)),words:[0,4,8,12].map(x=>v.getUint32(o+x,true)),iconbinBytes:ic.size,sourceSha256:createHash('sha256').update(fw.raw).digest('hex')}));
}
const root='work/gr3-live-adj-r12';mkdirSync(`${root}/extracted-gr4`,{recursive:true});
const records=[];
for(const [label,id]of [['OFF',310],['ON',311]] as const){
 const desc=word(0x543d3ac0+id*4),o=off(desc),type=v.getUint16(o,true),width=v.getUint16(o+2,true),height=v.getUint16(o+4,true),start=ic.offset+v.getUint32(o+8,true)*4;
 if(type!==1||width!==40||height!==40)throw Error('Unexpected GR4 switch format');
 const rgba=fw.decoded.slice(start,start+width*height*4);if(rgba.length!==6400)throw Error('Truncated switch');
 writeFileSync(`${root}/extracted-gr4/${label}-40x40.rgba`,rgba);
 records.push({label,id,desc,width,height,type,sourcePixelOffset:start-ic.offset,sha256:createHash('sha256').update(rgba).digest('hex')});
}
writeFileSync(`${root}/extracted-gr4/provenance.json`,JSON.stringify({source,sourceSha256:createHash('sha256').update(fw.raw).digest('hex'),pixelFormat:'RGBA8; copied exactly, not redrawn',records},null,2));
