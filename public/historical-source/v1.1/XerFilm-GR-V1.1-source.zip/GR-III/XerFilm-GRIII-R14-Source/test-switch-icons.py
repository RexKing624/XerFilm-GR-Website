# SPDX-License-Identifier: GPL-2.0-only
from pathlib import Path
import importlib.util,struct,json,hashlib,zlib
from unicorn.arm_const import *
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('icons_port',R/'test-port.py');port=importlib.util.module_from_spec(spec);spec.loader.exec_module(port)
e=port.Emu('GRIII');u=e.u;checks=[]
def ck(v,label):
 assert v,label
 checks.append(label)
def png(path,rgba):
 def chunk(t,b):return struct.pack('>I',len(b))+t+b+struct.pack('>I',zlib.crc32(t+b)&0xffffffff)
 rows=b''.join(b'\0'+rgba[y*160:(y+1)*160] for y in range(40));path.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',40,40,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(rows))+chunk(b'IEND',b''))
def assertion():
 if not e.reg(0):raise AssertionError(('native icon assert',hex(u.reg_read(UC_ARM_REG_LR))))
e.stubs[0x536b93d0]=assertion
painter=e.alloc(32);e.w32(painter,0x51600000);bitmap=e.alloc(64);e.w8(bitmap+2,5);e.w16(bitmap+0x18,128);pixels=0x70b00000;e.w32(bitmap+8,pixels);packet=e.alloc(64)
proof=json.loads((R/'extracted-gr4/provenance.json').read_text())
for label,icon in [('OFF',856),('ON',857)]:
 source=(R/f'extracted-gr4/{label}-40x40.rgba').read_bytes();record=next(x for x in proof['records'] if x['label']==label)
 ck(hashlib.sha256(source).hexdigest()==record['sha256'],'GR4 extracted source SHA '+label)
 descriptor=e.word(0x540b5600+4*icon);w,h,data=struct.unpack('<HHI',u.mem_read(descriptor,8))
 ck(w==40 and h==40 and data&0x80000000,'new40x40 absolute pixel descriptor '+label)
 ck(bytes(u.mem_read(data&0x7fffffff,6400))==source,'installed pixels exactly equal GR4 source '+label)
 u.mem_write(pixels,bytes(128*80*4));u.mem_write(packet,struct.pack('<11I',bitmap,0,0,40,40,0,0,40,40,icon,0));e.call(0x5320a7a8,painter,packet,limit=2000000)
 rendered=b''.join(bytes(u.mem_read(pixels+4*128*y,160)) for y in range(40))
 # Opaque pixels must retain their exact RGB when drawn by the actual III code.
 opaque=[i for i in range(1600) if source[i*4+3]==255]
 ck(len(opaque)>500,'substantial opaque source area '+label)
 ck(all(rendered[i*4:i*4+3]==source[i*4:i*4+3] for i in opaque),'native III rasterizer preserves GR4 opaque RGB '+label)
 ck(sum(any(rendered[(y*40+x)*4:(y*40+x)*4+3]) for y in range(8,32) for x in range(4,36))>100,'glyph region has visible letter strokes '+label)
 png(R/f'extracted-gr4/{label}-rendered-on-GRIII.png',rendered)
# Native Horizon line resources are preserved, rather than overwritten globally.
native=(R/'decoded/GRIII/RTOS.bin').read_bytes();source,dest,n=struct.unpack_from('<III',native,0x450)
def native_word(va):
 at=source+va-dest if dest<=va<dest+n else va
 return struct.unpack_from('<I',native,at-0x53000000)[0]
for icon in [344,345]:
 desc=native_word(0x550020fc+4*icon);ck(e.word(0x540b5600+4*icon)==desc,'native Horizon resource pointer unchanged '+str(icon))
# ADJ's OFF sentinel also uses the imported OFF image, not a native line icon.
a=e.alloc(0x500);lst=e.makeview();e.w32(a+0x1f0,lst)
u.reg_write(port.REGS[0],lst);u.reg_write(port.REGS[2],2);e.items()
e.call(e.m['adj']['draw'],a,0);row=e.word(e.word(e.word(lst+0xf4)))
ck(e.views[row]['icon']==856,'ADJ OFF row selects imported OFF glyph')
report={'status':'passed','model':'GRIII','hardwareTested':False,'checks':len(checks),'details':checks,'rtosSha256':e.m['sha256'],'method':'actual original GR III icon rasterizer; no bitmap drawing substitutes; all opaque RGB values match extracted GR IV icon bytes','provenance':proof}
(R/'switch-icon-checks.json').write_text(json.dumps(report,indent=2));print({'checks':len(checks),'status':'passed','nativeRasterizer':True},flush=True)
