# SPDX-License-Identifier: GPL-2.0-only
from pathlib import Path
import json,hashlib,zipfile,shutil
R=Path(__file__).resolve().parent;O=R.parents[1]/'outputs/XerFilm-GRIII-R14-MenuFix-2026-10-21'
notes='''XerFilm GR III R14 / R14-H — 设置菜单「影像控制」卡死修正版

仅适用于 GR III / GR III HDF。不要用于 IIIx / IV。
本版已通过本地 ARM 回归检查，仍待本次修复的实机复测。

选择：
当前使用普通版（安装版本2.10）：使用 GRIII-R14-ordinary-2.10。
当前使用增强版（安装版本2.11）：使用 GRIII-R14-enhanced-2.11。
两个文件夹中的 BIN 名称相同，但不是同一个文件。只选对应的一份。
只把 fwdc239b.bin 放在存储卡根目录，JSON/TXT/源码无需复制到卡。

本次修复：
设置菜单的影像控制原来只创建14个显示项，新增电影两项后需要16项。
现已同步原生最大容量，保留电影黄/绿和自定义1/2。
仅修改三个容量值及必要校验和；胶片模拟、ADJ、颗粒、日期、INFO及影像处理不变。
安装版本保持2.10/2.11，没有再次加版本号。

复测：
1. 胶片模拟关闭时，从设置菜单进入「影像控制」，上下遍历完整列表，包含电影黄/绿和自定义1/2，确认可选择和返回。
2. 开启胶片模拟，再进入同一个设置菜单，确认能够操作和返回；胶片效果仍独立，原生处理仍锁定Std。
3. 简单确认ADJ原生影像控制、胶片母子菜单仍可正常使用。

输出目录包含各文件完整SHA-256、本地回归与独立解包检查记录。
旧版R13与R13-H原文件保留在原交付目录。本次没有更改官网或IIIx/IV固件。
'''
(O/'使用说明.txt').write_text(notes)
shutil.copy2(R/'settings-image-control-checks.json',O/'settings-image-control-checks.json')
for folder in O.glob('GRIII-R14-*'):
 report=json.loads((folder/'validation.json').read_text());check=json.loads((folder/'independent-checks.json').read_text())
 assert check['status']=='passed' and hashlib.sha256((folder/'fwdc239b.bin').read_bytes()).hexdigest()==report['sha256']
 (folder/'使用说明.txt').write_text(notes)
 name=f"XerFilm-GRIII-{'R14-H-enhanced-2.11' if report['build']=='R14-H' else 'R14-ordinary-2.10'}-TEST.zip"
 with zipfile.ZipFile(O/name,'w',zipfile.ZIP_DEFLATED)as z:
  for p in folder.iterdir():
   if p.is_file():z.write(p,p.name)
 with zipfile.ZipFile(O/name)as z:assert z.testzip()is None
 print(name,report['size'],report['sha256'])
with zipfile.ZipFile(O/'XerFilm-GRIII-R14-MenuFix-SOURCE.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in R.rglob('*'):
  if not p.is_file()or any(x in p.parts for x in ['decoded','resource-build','__pycache__']):continue
  if p.suffix in ['.ts','.py','.json','.md','.txt','.rgba']or p.name=='LICENSE':z.write(p,'XerFilm-GRIII-R14-Source/'+str(p.relative_to(R)))
with zipfile.ZipFile(O/'XerFilm-GRIII-R14-MenuFix-SOURCE.zip')as z:assert z.testzip()is None
