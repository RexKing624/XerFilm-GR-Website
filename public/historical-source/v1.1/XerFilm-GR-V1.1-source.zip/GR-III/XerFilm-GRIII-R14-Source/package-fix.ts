// SPDX-License-Identifier: GPL-2.0-only
// Minimal, guarded replacement of three capacity bytes in each distributed GR III build.
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {Firmware,build,verifyContainer,sum32,sectionsOf} from './src/container';
const root='work/gr3-native-menu-r14',out='outputs/XerFilm-GRIII-R14-MenuFix-2026-10-21';
const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
const candidate=new Uint8Array(readFileSync(`${root}/resource-build/GRIII/image.rtos`));
const verified=JSON.parse(readFileSync(`${root}/verified-images.json`,'utf8'));
if(verified.GRIII!==sha(candidate))throw Error('Current regression validation required');
const regression=JSON.parse(readFileSync(`${root}/settings-image-control-checks.json`,'utf8'));
if(regression.status!=='passed'||regression.rtosSha256!==sha(candidate)||regression.checks!==100)throw Error('Settings reproduction and fix validation required');
const targets=[
 {kind:'ordinary',version:'2.10',path:'outputs/XerFilm-GRIII-R13-Cinema-2026-10-21/GRIII-2.10-XerFilm-R13/fwdc239b.bin',sha:'284c08e6f260382ff2d566053910f488e4a6ce8a548c9414def61d5b80554a65'},
 {kind:'enhanced',version:'2.11',path:'outputs/XerFilm-GRIII-Series-R13-H-2026-10-21/GRIII-R13-H-2.11/fwdc239b.bin',sha:'5044d8f1a9bab32ac93c6a5e0e7a1c90d25b9760aa9cee27d33d66a1cc7f868b'},
];
const reports=[];
for(const target of targets){
 const input=new Uint8Array(readFileSync(target.path));if(sha(input)!==target.sha)throw Error('Original distributed BIN changed');
 const fw=new Firmware(input);if(fw.project!==588)throw Error('GR III model guard');
 const data=fw.decoded.slice(),sections=sectionsOf(data),rtos=sections.find(s=>s.name==='RTOS')!;
 const edits:Array<{rtosOffset:number,address:string,before:number,after:number}>=[];
 for(const offset of [0xb5d36b,0xb5d36c,0xb5d36d]){
  if(data[rtos.offset+offset]!==12)throw Error('Native count table mismatch');
  data[rtos.offset+offset]=14;edits.push({rtosOffset:offset,address:(0x53000000+offset).toString(16),before:12,after:14});
 }
 const restored=data.slice();for(const e of edits)restored[rtos.offset+e.rtosOffset]=e.before;
 if(!Buffer.from(restored).equals(Buffer.from(fw.decoded)))throw Error('Unexpected firmware change');
 // The ordinary build must match the independently rebuilt and regression-tested
 // source image exactly. Enhanced differs only by previously verified versions/gate.
 const ordinary=new Firmware(new Uint8Array(readFileSync(targets[0].path)));const ordinaryRtos=sectionsOf(ordinary.decoded).find(s=>s.name==='RTOS')!;
 const featureBytes=data.slice(rtos.offset,rtos.offset+candidate.length);
 if(target.kind==='enhanced'){
  const baseline=ordinary.decoded.subarray(ordinaryRtos.offset,ordinaryRtos.offset+candidate.length);
  for(const offset of [0x2038,0x81fe6c,0x81fe7c,0x6285dc])featureBytes.set(baseline.subarray(offset,offset+4),offset);
 }
 if(!Buffer.from(featureBytes).equals(Buffer.from(candidate)))throw Error('Final firmware differs from verified feature image');
 const view=new DataView(data.buffer);view.setUint32(data.length-4,0,true);view.setUint32(data.length-4,(-sum32(data))>>>0,true);
 const result=build(fw,data),validation=verifyContainer(result.out,data);
 if(!Object.values(validation.checks).every(Boolean)||!Buffer.from(build(fw,data).out).equals(Buffer.from(result.out)))throw Error('Final container validation');
 const again=new Firmware(result.out);if(!Buffer.from(again.header).equals(Buffer.from(fw.header))||again.project!==588)throw Error('Version/model header changed');
 const diffs=[];for(let i=0;i<data.length;i++)if(data[i]!==fw.decoded[i])diffs.push(i);
 if(diffs.some(i=>!edits.some(e=>i===rtos.offset+e.rtosOffset)&&i<data.length-4))throw Error('Unexpected final change');
 const folder=`${out}/GRIII-R14-${target.kind}-${target.version}`;mkdirSync(folder,{recursive:true});writeFileSync(`${folder}/fwdc239b.bin`,result.out);
 const report={build:target.kind==='enhanced'?'R14-H':'R14',model:'GR III / HDF',installationVersion:target.version,filename:'fwdc239b.bin',size:result.out.length,sha256:sha(result.out),basePath:target.path,baseSha256:target.sha,hardwareTested:false,verifiedRtosSha256:sha(candidate),edits,decodedChangedOffsets:diffs,checks:{...validation.checks,exactFeatureImage:true,onlyThreeCapacityBytesAndPayloadChecksumChanged:true,originalHeaderModelAndDecodedLengthRetained:true,reproducibleBuild:true},regression};
 writeFileSync(`${folder}/validation.json`,JSON.stringify(report,null,2));writeFileSync(`${folder}/SHA256SUMS.txt`,report.sha256+'  fwdc239b.bin\n');reports.push(report);console.log(report.build,target.version,report.size,report.sha256);
}
writeFileSync(`${out}/validation.json`,JSON.stringify({status:'local ARM regression passed; hardware retest pending',reports},null,2));
