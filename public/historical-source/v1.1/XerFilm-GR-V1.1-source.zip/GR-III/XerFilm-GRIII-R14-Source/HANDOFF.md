# R14 GR III Settings Image Control freeze fix, 2026-10-21

User confirms both independent FILM ON and OFF freeze on entering Settings Image Control, regardless of ADJ native tone. Root cause independently reproduced: GetCount now14 styles but GetMaxCount reads table53b5d368 still[10,10,10,12,12,12]. Settings531abc3c allocates14 views includingCustom1/2, populate531ab7e4 uses16; native getter53394758 reads array index14 beyond14-capacity. ADJ different path works.

Minimal fix tablebytes53b5d36b/c/d each0c->0e. R14 rebuilt feature image differs from R13 by exactly3 bytes; SHAab7811c7f811d68ff4a444ea9bb1d2b74aada9bce7e331e08166058316e3ea55. Existing12 ARM suites plus100 focused regression checks passed, including old failure reproduction/native lookup bounds with all3 banks×3 modes×2 FILMstates. Strict TS passed. JIT run via escalated local checks, no camera access.

package-fix.ts patches pinned distributed ordinaryR13 and enhancedR13-H containers. Independently decoded final containers match corresponding originals except3 count bytes+decodedchecksum. All original header and version bytes, model588, sectiongeometry, CPU/DSP/etc retained. Exact final feature RTOS equals ARM-tested image after reverting only pre-existing enhancedversion/gate bytes for comparison. Repacking storedframes changes physical length. Independent Python decoder checks50passed. Firmware versions unchanged; no additional bump.

Outputs outputs/XerFilm-GRIII-R14-MenuFix-2026-10-21:
- GRIII-R14-ordinary-2.10/fwdc239b.bin35542300bytes SHA67d62f0f9a66ce71743cf9cecb7faaa1c02930f2edaa2bda69bf0b5f77ccf6cd
- GRIII-R14-enhanced-2.11/fwdc239b.bin35579496bytes SHA9ae280c3e5a3eb5230c1480ecb2d949baeac1c7791e8b9ec173020cb191f4e53
- Separate TESTZIPs/sourceZIP, Chineseinstructions, independentchecks.

Physical-camera retest pending. Website still previousR13/R13-H, not replaced with untestedfix. IIIx and IV unchanged. OriginalR13/R13-H source/artifacts preserved. No cardwrites.
