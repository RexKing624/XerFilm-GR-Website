# SPDX-License-Identifier: GPL-2.0-only
# Feature parity with hardware-confirmed GR III R13, preserving every original
# GR IIIx identity/version/calendar-specific byte in its own official RTOS.
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;reference=R.parent/'gr3-native-menu-r14'
native3=(reference/'decoded/GRIII/RTOS.bin').read_bytes()
nativex=(R/'decoded/GRIIIx/RTOS.bin').read_bytes()
patched3=(reference/'resource-build/GRIII/image.rtos').read_bytes()
patchedx=(R/'resource-build/GRIIIx/image.rtos').read_bytes()
sha=lambda x:hashlib.sha256(x).hexdigest()
assert sha(native3)=='8a4eafcad2716e0b21e9909264e1242e534f0e39e05cba82a53546ceb4070b67'
assert sha(nativex)=='0f11b0d28bc67932d044c5d01bc0314844a756057c89984278c73a23449a24c6'
assert len(native3)==len(nativex) and len(patched3)==len(patchedx)
assert sha(patched3)=='ab7811c7f811d68ff4a444ea9bb1d2b74aada9bce7e331e08166058316e3ea55'
differences=[i for i,(a,b) in enumerate(zip(native3,nativex)) if a!=b]
assert len(differences)==31
actual=[i for i,(a,b) in enumerate(zip(patched3,patchedx)) if a!=b]
assert actual==differences,'Port changed bytes beyond official model differences'
for i in differences:
 assert patched3[i]==native3[i] and patchedx[i]==nativex[i],hex(0x53000000+i)
assert patched3[len(native3):]==patchedx[len(nativex):],'Feature extension must match regression-validated R14 exactly'
modules=[]
for p in sorted((reference/'src').rglob('*')):
 if p.is_file():
  rel=p.relative_to(reference/'src');target=R/'src'/rel
  assert target.read_bytes()==p.read_bytes(),str(rel)
  modules.append({'file':str(rel),'sha256':sha(p.read_bytes())})
meta=json.loads((R/'resource-build/GRIIIx/resources.json').read_text())
assert meta['model']=='GRIIIx' and meta['rtosSha256']==sha(patchedx)
report=dict(status='passed',model='GRIIIx',rtosSha256=sha(patchedx),hardwareTested=False,
 referenceModel='GRIII',referenceBuild='R14',referenceHardwareVerifiedByUser=False,referenceRtosSha256=sha(patched3),
 originalModelDifferenceBytes=31,allOriginalDifferencesPreserved=True,patchedModelDifferencesOnlyOriginal=True,
 featureExtensionByteIdentical=True,identicalCoreFiles=modules,
 nativeDifferences=[{'address':hex(0x53000000+i),'GRIII':native3[i],'GRIIIx':nativex[i]} for i in differences],
 limitations='R14 menu-capacity fix requires separate hardware retest on both models.')
(R/'model-parity-checks.json').write_text(json.dumps(report,indent=2))
print({k:v for k,v in report.items() if k not in ['identicalCoreFiles','nativeDifferences']},flush=True)
