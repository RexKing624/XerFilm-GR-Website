# SPDX-License-Identifier: GPL-2.0-only
# ARM execution checks with hardware/services stubbed. This is not camera validation.
from pathlib import Path
from unicorn import *
from unicorn.arm_const import *
import struct,json,math
from collections import deque
R=Path(__file__).resolve().parent;BASE=0x53000000;STOP=0x100
REGS=[UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3,UC_ARM_REG_R4,UC_ARM_REG_R5,UC_ARM_REG_R6,UC_ARM_REG_R7,UC_ARM_REG_R8,UC_ARM_REG_R9,UC_ARM_REG_R10,UC_ARM_REG_R11,UC_ARM_REG_R12,UC_ARM_REG_LR]
ROOT=0x5503a080;MASK=ROOT+16;SELECT=ROOT+20;FLAG=ROOT+21
class Emu:
 def __init__(self,model):
  self.image=(R/'resource-build'/model/'image.rtos').read_bytes();self.m=json.loads((R/'resource-build'/model/'resources.json').read_text());self.u=Uc(UC_ARCH_ARM,UC_MODE_ARM);u=self.u
  u.mem_map(BASE,0x2000000);u.mem_write(BASE,self.image);u.mem_protect(BASE,0x2000000,UC_PROT_READ|UC_PROT_EXEC)
  u.mem_map(0x55000000,0x1000000);source,dest,count=struct.unpack_from('<III',self.image,0x450);u.mem_write(dest,self.image[source-BASE:source-BASE+count]);u.mem_map(0x60000000,0x100000);u.mem_map(0x70000000,0x1000000);u.mem_map(0,0x1000)
  self.trace=deque(maxlen=80);self.heap=0x70010000;self.calls=[];self.file=None;self.props=1;self.time=struct.pack('<H6B',2026,10,19,21,36,0,0)+bytes(8);self.stubs={};self.views={};self.log=[]
  self.vt=0x70001000;self.w32(self.vt+0x18,0x70002000);self.w32(self.vt+0x28,0x70002004);self.w32(self.vt+0x34,0x70002004);self.w32(self.vt+0x48,0x70002004)
  self.w32(0x5536c7c0,0x70003000);self.w32(0x70004004,0x70005000)
  self.stubs={0x5320ad88:lambda:0x70003000,0x5320b31c:lambda:0x70004000,0x532750f8:self.preview,0x536af2a8:lambda:self.alloc(self.reg(0)),0x536af2e4:lambda:0,0x53828014:lambda:0x70006000,0x53825fa8:self.save,0x53825648:self.load,0x533ad7f0:self.factory,0x53394610:self.items,0x53394768:lambda:0,0x533958a8:lambda:0,0x533ac1b4:lambda:0,0x533aba64:lambda:0,0x53393e00:lambda:0,0x533ad2c8:lambda:0,0x53396f4c:lambda:0,0x53396f80:self.settext,0x533a1734:self.seticon,0x533a1808:self.setitemtext,0x533a19b4:self.setmark,0x533ab548:self.rect,0x533a14ac:self.focus,0x533a14b8:self.unfocus,0x533ad3c0:self.visible,0x5339b484:self.rect,0x5339b61c:self.footer,0x5339b5e8:lambda:0,0x5339606c:lambda:0,0x53395430:self.index,0x5339482c:self.active,0x5316cde8:lambda:0,0x531a4cfc:lambda:0,0x531ba2ac:self.close,0x531a2820:lambda:20,0x5339e8b0:self.drawrow,0x533a6a70:self.subicon,0x5339df08:lambda:0,0x5339dc70:lambda:0,0x536df484:lambda:0,0x536df55c:lambda:0,0x536bbc30:lambda:0x70003000,0x536bbcc0:lambda:0,0x536bbcac:lambda:0,0x5356e588:lambda:0x70003000,0x53571d90:self.clock,0x535d02f4:lambda:0,0x535be018:lambda:self.props,0x5320b97c:lambda:0x70007000}
  self.hookHandle=u.hook_add(UC_HOOK_CODE,self.hook)
 def alloc(self,n=0x400):a=(self.heap+15)&~15;self.heap=a+max(n,16);assert self.heap<0x70e00000;return a
 def reg(self,n):return self.u.reg_read(REGS[n])
 def w32(self,a,v):self.u.mem_write(a,struct.pack('<I',v&0xffffffff))
 def w16(self,a,v):self.u.mem_write(a,struct.pack('<H',v))
 def w8(self,a,v):self.u.mem_write(a,bytes([v]))
 def word(self,a):return struct.unpack('<I',self.u.mem_read(a,4))[0]
 def byte(self,a):return self.u.mem_read(a,1)[0]
 def hook(self,u,a,size,data):
  self.trace.append((hex(a),hex(u.reg_read(UC_ARM_REG_SP))))
  if a==0:
   raise RuntimeError(('NULL jump',hex(self.reg(9)),hex(self.word(self.reg(9))) if self.reg(9) else '',list(self.trace)[-12:]))
  if a in [0x70002000,0x70002004]:
   if a==0x70002000:self.rect()
   u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR));return
  if a in self.stubs:
   self.calls.append((a,tuple(self.reg(i)for i in range(4))))
   v=self.stubs[a]();u.reg_write(UC_ARM_REG_R0,(v or 0)&0xffffffff);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
 def call(self,a,*args,limit=500000,until=STOP):
  u=self.u;u.reg_write(UC_ARM_REG_SP,0x600f0000);u.reg_write(UC_ARM_REG_LR,STOP)
  for i,v in enumerate(args):u.reg_write(REGS[i],v)
  u.emu_start(a,until,count=limit)
  assert u.reg_read(UC_ARM_REG_PC)==until,('not returned',hex(a),hex(u.reg_read(UC_ARM_REG_PC)))
  assert u.reg_read(UC_ARM_REG_SP)==0x600f0000,('unbalanced SP',hex(a),hex(u.reg_read(UC_ARM_REG_SP)),list(self.trace))
  return self.reg(0)
 def preview(self):self.log.append(('preview',self.byte(SELECT),self.byte(FLAG)));return 1
 def save(self):self.file=bytes(self.u.mem_read(self.reg(3),self.reg(2)));return 1
 def load(self):
  if self.file:self.u.mem_write(self.reg(3),self.file)
  return int(self.file is not None)
 def factory(self):
  d=struct.unpack('<6I',self.u.mem_read(self.reg(0),24));a=self.alloc();self.views[a]={'kind':d[0],'rect':d[1:5],'visible':1,'mark':0,'focus':0};self.w32(a,self.vt)
  if d[0]==25:
   for o,k in [(0xf0,10),(0xf4,17)]:c=self.alloc();self.w32(a+o,c);self.w32(c,self.vt);self.views[c]={'kind':k,'visible':1}
  return a
 def items(self):
  obj=self.reg(0);count=self.reg(2);arr=self.alloc(count*4)
  for i in range(count):
   d=self.alloc(24);self.u.mem_write(d,struct.pack('<6I',25,0,i*60,140,58,0));self.u.reg_write(REGS[0],d);a=self.factory();node=self.alloc(24);self.w32(node,a);self.w32(arr+4*i,node)
  self.w32(obj+0xf4,arr);self.w32(obj+0xf8,arr+count*4);return 0
 def settext(self):self.views.setdefault(self.reg(0),{})['text']=self.reg(1);return 0
 def seticon(self):
  a=self.reg(0);self.views[a]['icon']=self.reg(1);child=self.word(a+0xf0);self.w16(child+0xea,self.reg(1));return 0
 def setitemtext(self):a=self.reg(0);self.views[a]['text']=self.reg(1);self.w16(self.word(a+0xf4)+0xea,self.reg(1));return 0
 def setmark(self):self.views[self.reg(0)]['mark']=self.reg(1);return 0
 def focus(self):self.views[self.reg(0)]['focus']=1;return 0
 def unfocus(self):self.views[self.reg(0)]['focus']=0;return 0
 def visible(self):self.views.setdefault(self.reg(0),{})['visible']=self.reg(1);return 0
 def rect(self):
  a=self.reg(0);r=struct.unpack('<4I',self.u.mem_read(self.reg(1),16));self.views.setdefault(a,{})['rect']=r
  for o,v in zip([0x30,0x34,0x38,0x3c],r):self.w32(a+o,v)
  self.w32(a+0x68,r[1]);self.w32(a+0x70,r[3]);return 0
 def footer(self):self.log.append(('footer',self.reg(1),self.reg(2)));return 0
 def index(self):self.w16(self.reg(0)+0x110,self.reg(1));return 0
 def active(self):self.views.setdefault(self.reg(0),{})['active']=self.reg(1);return 0
 def close(self):self.log.append(('CLOSE',));return 0
 def drawrow(self):self.log.append(('row',self.reg(1),self.reg(2)));return 0
 def subicon(self):self.log.append(('subicon',self.reg(1)));return 0
 def clock(self):raise AssertionError('PowerSourceInfo is not a clock; stamp must read the shot EXIF date')
 def makeview(self):a=self.alloc();self.w32(a,self.vt);self.views[a]={'visible':1};return a
 def ctrl(self):
  c=self.alloc(0x500)
  for o in range(0x158,0x198,4):self.w32(c+o,self.makeview())
  self.w32(c,0x53b3c4c8);self.w8(c+0x198,44);self.w32(c+0x1d8,3);return c
 def attach(self,si,look,on=1,grain=0,stamp=0):
  self.w8(SELECT,look);self.w8(FLAG,on);tag=0x40|(grain<<1)|(stamp<<3);self.w32(MASK,0x1ffff|(tag<<16));self.call(self.m['runtime']['look'],0)
  # Cached ensure() builds the bounded RAM registry through the real ARM code.
  # Registry is deliberately read-only to consumers after per-shot publication.
  # Reuse the capture attach function from the address table generated below.
  # Actual native EXIF Date/Time fields, not any live service object.
  year,month,day,hour,minute,second,_=struct.unpack('<H6B',self.time[:8])
  self.w16(si+0x944,year);self.u.mem_write(si+0x946,bytes([month,day,0,hour,minute,second]))
  self.call(self.m['capture']['attach'],si)

def check_model(model):
 e=Emu(model);m=e.m;u=e.u;count=0
 def check(x,msg):
  nonlocal count
  assert x,(model,msg);count+=1
 e.w32(0x70006008,0x70008000);e.w32(0x70008000,0x70009000)
 e.call(m['preferences']['init']);check(e.byte(FLAG)==0,'default off');check(e.call(m['enabled']['count'])==18,'17 families plus OFF')
 # Separate private-file settings survive a round trip; malformed input ignored.
 e.w8(SELECT,20);e.w8(FLAG,1);e.call(m['enabled']['setGrain'],2);e.call(m['enabled']['setStamp'],5);saved=bytes(u.mem_read(MASK,8));e.call(m['preferences']['save']);e.w32(MASK,0);e.w32(SELECT,0);e.call(m['preferences']['load']);check(bytes(u.mem_read(MASK,8))==saved,'preferences round trip')
 old=e.file;e.file=bytes(16);e.w8(SELECT,3);e.call(m['preferences']['load']);check(e.byte(SELECT)==3,'invalid preference checksum ignored');e.file=old
 e.w32(MASK,0xc9ffff);e.w8(SELECT,0);e.w8(FLAG,0)
 # Context routing now reuses native record44; native mapping is unmodified.
 e.call(0x531b9640,0x7000a000,0x0200007d);check(e.byte(0x7000a198)==44,'original native Horizon selector retained')
 for key in ['regular','hdf']:
  a=m['menu'][key];check(e.byte(a+0x68)==7 and e.byte(a+0x8b)==38,'native main menu capacity preserved')
 for i in range(20):check(e.call(0x53292810,0,i)!=841,'native ADJ enum name intact')
 check(e.call(0x53292810,0,20)==841,'independent FILM name');check(e.call(0x53293a30,0,20)==732,'fixed FILM icon')
 # Film assignment is made once when enabling the main switch.
 e.call(m['menu']['set'],0,1);check(e.byte(0x70005000+0x918)==20,'Film placed in ADJ');check(e.byte(FLAG)==1,'main switch on')
 e.call(m['menu']['set'],0,0);check(e.byte(FLAG)==0,'main switch off')
 # Grid has an independent cursor; OK never calls native close.
 c=e.ctrl();e.call(m['grid']['render'],c);check(e.word(c+0x1e4)!=0,'grid owns root');check(len([v for v in e.views.values() if v.get('icon',0)>=788])==12,'12 opaque tiles')
 packet=e.alloc(8);keys=m['grid']['keys']
 for ev,expected in [(0xcf,1),(0xd1,5),(0xce,4),(0xd0,0),(0xd5,1),(0xd4,0)]:
  e.w16(packet,ev);e.call(keys,c,packet);check(e.word(c+0x1e8)==expected,'four-way grid cursor')
 e.w16(packet,0xd8);before=e.call(m['enabled']['enabled'],0);e.call(keys,c,packet);check(e.call(m['enabled']['enabled'],0)!=before,'OK toggles without close');check(not any(x[0]=='CLOSE' for x in e.log),'OK stays in grid')
 # Raw OK press/release both consumed before native menu manager dispatch.
 data=e.alloc(8);e.w32(packet+4,data);e.w16(packet,8)
 for state in [1,2]:e.w8(data,state);check(e.call(m['grid']['dispatch'],c,packet)==1,'raw OK consumed')
 e.w32(MASK,0xc9ffff)
 # Three child menu trees remain allocated across rapid changes.
 a=e.alloc(0x500);root=e.makeview();parent=e.makeview();e.w32(a+0x15c,root);e.w32(a+0x1f0,parent);e.w32(a+0x164,e.makeview());e.w32(a,0x53b394e0)
 e.u.reg_write(UC_ARM_REG_R4,a);e.u.reg_write(UC_ARM_REG_R12,0);e.call(m['adj']['mini']['zero'],until=0x531a2084)
 # Re-create parent items with native node-vector layout.
 e.u.reg_write(REGS[0],parent);e.u.reg_write(REGS[2],18);e.items()
 for r in range(5):
  for family in [10,11,16,0]:e.call(m['adj']['mini']['render'],a,family)
 check(all(e.word(a+o)!=0 for o in [0x2a8,0x2ac,0x2b0]),'three cached child families')
 after=e.heap
 for family in [10,11,16,10,0,11,16]:e.call(m['adj']['mini']['render'],a,family)
 check(e.heap==after,'fast-scroll cached views do not allocate or delete')
 # Session rollback and commit preserve independently stored native filters.
 e.w8(SELECT,10);e.w8(FLAG,0);e.w32(a+0x2b4,0);e.call(m['adj']['session']['begin'],a);e.w8(SELECT,12);e.w8(FLAG,1);e.call(m['adj']['session']['rollback'],a);check(e.byte(SELECT)==10 and e.byte(FLAG)==0,'cancel restores initial native/film state')
 e.call(m['adj']['session']['begin'],a);e.w8(SELECT,12);e.w8(FLAG,1);e.call(m['adj']['session']['commit'],a);e.call(m['adj']['session']['rollback'],a);check(e.byte(SELECT)==12 and e.byte(FLAG)==1,'confirmed child remains applied')
 # Actual child-key adapter: enter, change speed, commit, re-enter, cancel.
 e.w32(MASK,0xc9ffff);e.w8(SELECT,10);e.w8(FLAG,1);e.w32(a+0x2b4,0);e.w8(a+0x2a0,0);e.w16(parent+0x110,11);e.call(m['adj']['mini']['render'],a,10)
 for ev,selection,focus in [(0xce,10,1),(0xd1,11,1),(0xd1,12,1),(0xd8,12,0),(0xce,12,1),(0xd0,11,1),(0xcf,12,0)]:
  e.w16(packet,ev);e.call(m['adj']['mini']['keys'],a,packet);check(e.byte(SELECT)==selection and e.byte(a+0x2a0)==focus,'child key '+hex(ev)+' expected '+str((selection,focus))+' got '+str((e.byte(SELECT),e.byte(a+0x2a0))))
 check(not any(x[0]=='CLOSE' for x in e.log),'child OK returns to mother without native close')
 # Per-shot latch does not lag one exposure behind; OFF is frozen too.
 for si,look,on in [(0x70c00000,10,1),(0x70c01000,11,1),(0x70c02000,0,0)]:
  e.attach(si,look,on,2,5);packed=e.call(m['capture']['lookup'],si);check((packed>>24&31)==look and bool(packed>>31)==bool(on),'same exposure identity')
 # Every virtual parameter read preserves all non-output registers and NZCV.
 for r in m['runtime']['reads']:
  for enabled in [0,1]:
   e.w8(FLAG,enabled);e.w8(SELECT,4)
   values=[0x70b00000+i*0x1000 for i in range(14)];values[13]=0x70b0f000
   for i,x in enumerate(values):u.reg_write(REGS[i],x)
   base=values[r['rn']];e.w8(base+r['offset'],17);u.reg_write(UC_ARM_REG_CPSR,0xa0000013);u.reg_write(UC_ARM_REG_SP,0x600f0000)
   u.emu_start(r['site'],r['site']+4,count=3000)
   rd=13 if r['rd']==14 else r['rd'];expect=values[:];expect[rd]=r['value'] if enabled else 17
   check([e.reg(i)for i in range(14)]==expect,'parameter wrapper register preservation '+hex(r['site']));check(u.reg_read(UC_ARM_REG_CPSR)==0xa0000013 and u.reg_read(UC_ARM_REG_SP)==0x600f0000,'parameter flags/SP preserved')
 # Resource-bank identity, snapshot takes precedence over live state.
 for look in range(27):
  si=0x70c10000+look*0x1000;e.attach(si,look,1);e.w8(SELECT,(look+1)%27)
  for site,dest,table,expected in [(0x536dc2a0,13,0x55018d94,m['runtime']['matrixRecords'][look]),(0x536dc2b0,12,0x55018cf0,m['runtime']['sets']+look*32)]:
   u.reg_write(UC_ARM_REG_SP,0x600f0000);u.reg_write(REGS[7],si);u.reg_write(REGS[0],0x55018d94);u.reg_write(REGS[1],11);u.reg_write(REGS[12],0x55018cf0);u.reg_write(REGS[13],0x12345678);u.emu_start(site,site+4,count=3000);check(e.reg(dest)==expected,'snapshot resource identity')
 # Context-owned curves are stable after the live selector changes.
 ctx=e.alloc(256);out=e.alloc(16)
 for look in range(27):
  e.w32(ctx+12,m['runtime']['sets']+look*32);u.reg_write(REGS[4],ctx);e.call(m['runtime']['gamma'],0,out,out+4,out+8);check([e.word(out+i*4) for i in range(3)]==m['runtime']['models'][look]['gamma'],'context curve pointers')
 # Native Monotone's grain/shading cannot leak into a film JPG.
 plan=e.alloc(128);shot=e.alloc(4096)
 for tone in [11,12,13,14,15,16,17,18,19,20,21,22]:
  e.w8(shot+0x77c,tone);e.w8(shot+0x793,4);e.w8(shot+0x794,4);e.w8(shot+0x795,3);e.w8(shot+0x796,0)
  e.w8(FLAG,1);e.w8(plan+0x24,77);e.call(0x535131c0,plan,shot);check(e.byte(plan+0x24)==0,'film suppresses native effect overlay')
 e.w8(FLAG,0);e.w8(shot+0x77c,13);e.call(0x535131c0,plan,shot);check(e.byte(plan+0x24)==1,'OFF restores native Monotone grain stage')
 # Decoder and INFO icon use the current JPEG's tag, not global selection.
 for look in [10,11,0,26,17]:
  e.props=128+look;ptr=e.alloc(4);check(e.call(0x532b44bc,0x70007000,ptr)==1 and e.byte(ptr)==64+look,'photo property decoded')
  expected=e.word(m['metadata']['icons']+4*look);check(e.call(0x532b6eec,0)==expected,'per-photo INFO packaging icon')
 # Same binary preserves distinct model RTOS inputs, ROM remains RX throughout.
 return dict(model=model,checks=count,status='passed',romWriteProtected=True,hardwareServicesStubbed=True,hardwareTested=False)

if __name__=='__main__':
 reports=[]
 for model in ['GRIIIx']:
  result=check_model(model);reports.append(result);print(result,flush=True)
 (R/'port-checks.json').write_text(json.dumps(reports,indent=2))
