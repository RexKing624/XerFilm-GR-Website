# SPDX-License-Identifier: GPL-2.0-only
# Runs native settings allocation + population, retaining native item lookup.
# Hardware widgets/services are fixtures; not physical-camera verification.
from pathlib import Path
import importlib.util,json,hashlib,struct
from unicorn import UC_HOOK_MEM_READ
from unicorn.arm_const import UC_ARM_REG_PC
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('settings_emu',R/'native-emu.py');native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
checks=[]
def ck(value,label):
 assert value,label
 checks.append(label)
class CapacityError(Exception):pass

def fixture(folder,bank,mode):
 native.R=folder
 e=native.Emu();model=e.alloc(0x100);e.u.mem_write(model+0x1b,bytes([mode]))
 e.stubs.update({0x5320ba9c:lambda:model,0x5320b67c:lambda:0,0x532bd6d4:lambda:bank,0x533958b4:lambda:0})
 controller=e.alloc(0x200);view=e.view();e.w32(controller+0x174,view)
 allocations=[];draws=[]
 original_items=e.items
 def items():
  allocations.append(e.reg(2));return original_items()
 e.stubs[0x53394610]=items
 def bounds(u,access,address,size,value,user):
  if u.reg_read(UC_ARM_REG_PC)==0x5339475c:
   start=e.word(view+0xf4);end=e.word(view+0xf8)
   if not start<=address<end:raise CapacityError(f'item {(address-start)//4} outside allocated {allocations[-1]} items')
 e.u.hook_add(UC_HOOK_MEM_READ,bounds)
 def icon():draws.append((e.reg(0),e.reg(1)));return 0
 e.stubs[0x533a1734]=icon
 return e,controller,model,allocations,draws

old=R.parent/'gr3x-native-cinema-r13/resource-build/GRIIIx'
e,c,m,allocs,draws=fixture(old,0,0)
e.call(0x531abc3c,c)
ck(allocs==[14],'R13 settings allocates only14 views including both Custom banks')
try:e.call(0x531ab7e4,c)
except RuntimeError as error:
 ck('item 14 outside allocated 14 items' in str(error),'R13 reproduces native settings out-of-bounds read at item14')
else:raise AssertionError('The reported R13 regression must reproduce before accepting the fix')
print('R13 failure reproduced: 14 allocated views, first Custom view is out of bounds',flush=True)

for bank in [0,1,2]:
 for mode in [0,1,2]:
  for film in [0,1]:
   e,c,m,allocs,draws=fixture(R/'resource-build/GRIIIx',bank,mode)
   e.u.mem_write(0x5503a095,bytes([film]));e.call(0x531abc3c,c)
   n=e.call(0x532c2a9c,m);ck(allocs==[16],f'R14 allocates16 views bank/mode/film {bank}/{mode}/{film}')
   ck(n==[14,10,12][mode],f'Only still selector count extended {bank}/{mode}/{film}')
   e.call(0x531ab7e4,c)
   ck(len(draws)==16,f'Native settings populates all16 allocated views without overflow {bank}/{mode}/{film}')
   ck(draws[n][1]==e.call(0x532a9988,0,23) and draws[n+1][1]==e.call(0x532a9988,0,24),f'Custom1/2 retain independent icons {bank}/{mode}/{film}')
   if mode==0:
    ck([item[1]for item in draws[12:14]]==[858,859],f'Cinema icons occupy new native slots {bank}/{film}')
   e.call(0x531ab750,c)
   ck(not e.log,f'No native exit triggered while refreshing settings {bank}/{mode}/{film}')
# Both standard and high-version R13 share the same faulty capacity table.
old_rtos=(old/'image.rtos').read_bytes();new_rtos=(R/'resource-build/GRIIIx/image.rtos').read_bytes()
diffs=[i for i,(a,b)in enumerate(zip(old_rtos,new_rtos))if a!=b]
ck(len(old_rtos)==len(new_rtos),'RTOS length unchanged')
ck(diffs==[0xb5d36b,0xb5d36c,0xb5d36d],'Only the three still capacity bytes changed; code, processing, resources and ADJ identical')
report={'status':'passed','hardwareTested':False,'checks':len(checks),'rtosSha256':hashlib.sha256(new_rtos).hexdigest(),'reproducedOldFailure':'native settings item14 beyond14 allocated items','fixedCapacity':16,'changedRtosOffsets':diffs,'nativeAllocation':hex(0x531abc3c),'nativePopulation':hex(0x531ab7e4),'nativeLookup':hex(0x53394758),'notes':'Native settings allocation/population and item access execute; hardware services and widgets are fixtures.'}
(R/'settings-image-control-checks.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
