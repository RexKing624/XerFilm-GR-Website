# SPDX-License-Identifier: GPL-2.0-only
# Exercise actual child keys -> actual native parent refresh/dispatch -> film
# family setter, including filtered parent lists and existing transactions.
from pathlib import Path
import importlib.util,struct,json,hashlib
from unicorn import UC_HOOK_CODE
R=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('port',R/'test-port.py');port=importlib.util.module_from_spec(s);s.loader.exec_module(port)
checks=[]
def ck(v,msg):
 assert v,msg
 checks.append(msg)
e=port.Emu('GRIIIx');u=e.u;m=e.m;e.call(m['preferences']['init'])
families={10:(10,3),11:(13,7),16:(20,3)}
# Native refresh itself and its table-based SetValue are NOT stubbed. Only
# window/layout refresh endpoints and device application are test doubles.
e.stubs.pop(0x531a4cfc,None)
for a in [0x531a2fa8,0x531a2c28,0x531a2cf0]:e.stubs[a]=lambda:0
setter_hits=[]
u.hook_add(UC_HOOK_CODE,lambda uc,pc,size,ud:setter_hits.append(pc),begin=m['adj']['set'],end=m['adj']['set'])
for mask in [0x1ffff,(1<<7)|(1<<10)|(1<<11)|(1<<16)]:
 for start_on in [0,1]:
  for family,(first,count) in families.items():
   for child in range(count):
    e.w32(port.MASK,0xc80000|mask);e.w8(port.SELECT,7);e.w8(port.FLAG,start_on)
    ctrl=e.alloc(0x500);parent=e.makeview();e.w32(ctrl,0x53b394e0);e.w32(ctrl+0x1f0,parent)
    for off in [0x15c,0x164,0x168,0x1a8,0x1ac]:e.w32(ctrl+off,e.makeview())
    e.w8(ctrl+0x1f4,0);e.w8(0x70005000+0x918,20)
    rows=e.call(m['enabled']['count']);u.reg_write(port.REGS[0],parent);u.reg_write(port.REGS[2],rows);e.items()
    rank=e.call(m['enabled']['rank'],family);e.w16(parent+0x110,rank)
    e.call(m['adj']['enter'],ctrl);e.call(m['adj']['mini']['render'],ctrl,family)
    packet=e.alloc(8)
    def key(k):e.w16(packet,k);return e.call(m['adj']['mini']['keys'],ctrl,packet)
    # Enter from a different family without manufacturing an already-applied
    # parent selection. The displayed first child must also be accept-able.
    key(0xce)
    popup=e.word(ctrl+0x294);e.w16(popup+0x110,child)
    # A UI repaint can leave live preview pointing to a previous family. OK
    # accepts the actual visible child cursor rather than trusting that byte.
    e.w8(port.SELECT,7);e.w8(port.FLAG,start_on);setter_hits.clear();key(0xd8)
    wanted=first+child
    ck(e.byte(port.SELECT)==wanted and e.byte(port.FLAG)==1,'OK applies visible child and enables its family')
    ck(e.byte(ctrl+0x2a0)==0 and e.word(ctrl+0x2b4)==0,'child returns to mother and commits after refresh')
    ck(bool(setter_hits),'actual native parent refresh re-enters the real film setter')
    ck(e.call(m['adj']['current'],ctrl,rank)==1 and e.word(parent+0x110)&65535==rank,'mother current family and cursor match accepted child')
    arr=e.word(parent+0xf4);rows=e.call(m['enabled']['count'])
    marks=[e.views[e.word(e.word(arr+i*4))].get('mark',0) for i in range(rows)]
    ck(marks==[int(i==rank) for i in range(rows)],'only the accepted mother family has a current marker')
    ck(e.log[-1]==('preview',wanted,1),'last apply sees the accepted child, not prior family')
    e.call(m['adj']['leave'],ctrl)
    ck(e.byte(port.SELECT)==wanted and e.byte(port.FLAG)==1,'leaving without a second mother OK retains the accepted child')
    # An unconfirmed later preview must now return to the newly accepted child.
    e.call(m['adj']['enter'],ctrl);e.call(m['adj']['set'],ctrl,1);e.call(m['adj']['leave'],ctrl)
    ck(e.byte(port.SELECT)==wanted and e.byte(port.FLAG)==1,'later cancelled parent preview restores accepted child baseline')
    ck(not any(x[0]=='CLOSE' for x in e.log),'child OK never posts a native ADJ close')
report=dict(model='GRIIIx',status='passed',checks=len(checks),rtosSha256=hashlib.sha256(e.image).hexdigest(),hardwareTested=False,
 nativeParentRefreshExecuted=True,nativeParentSetterDispatchExecuted=True,filteredFamilyMasks=True,all13Children=True,
 limitations='Key packets, view allocation, painting, filesystem and ISP application use fixtures; no physical camera input.')
(R/'child-family-accept-checks.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
