# SPDX-License-Identifier: GPL-2.0-only
from pathlib import Path
import importlib.util,json,struct,hashlib
from unicorn.arm_const import *
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r5_native',R/'native-emu.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
e=mod.Emu();u=e.u;m=e.menu;checks=[]
def ck(v,label):
 assert v,label
 checks.append(label)
u.reg_write(UC_ARM_REG_C1_C0_2,0xf00000);u.reg_write(UC_ARM_REG_FPEXC,0x40000000)
for a in [0x533ad7f0,0x53394610,0x53394b38,0x533aba64,0x53395430,0x533ad3c0,0x53394f58,0x53394e8c,0x53394768,0x533958a8,0x533accd8,0x53395260,0x533952c0,0x533ad308,0x533ad2c8,0x53393e00,0x531b3b04,m['count']]:e.stubs.pop(a,None)
def fatal():raise AssertionError(('native fatal',hex(u.reg_read(UC_ARM_REG_LR))))
e.stubs[0x536b9f1c]=fatal;e.stubs[0x53820074]=fatal
def clock():u.mem_write(e.reg(0),bytes(8));return e.reg(0)
e.stubs[0x536afc5c]=clock;e.stubs[0x5320b01c]=lambda:0x70003000;e.stubs[0x5322b468]=lambda:1;e.stubs[0x532465dc]=lambda:1
models={}
for a in [0x5320aefc,0x5320af5c,0x5320afbc,0x5320b19c,0x5320b13c,0x5320b31c,0x5320b1fc,0x5320b07c,0x5320b61c,0x5320b5bc,0x5320b67c]:
 obj=e.alloc(0x4000);e.w32(obj,e.vt);models[a]=obj;e.stubs[a]=lambda obj=obj:obj
data=e.alloc(0x2000);e.w32(models[0x5320b31c]+4,data)
for a in [0x5327b7cc,0x53234ca4,0x5322c4e4,0x5322c360,0x532a0ed0,0x53233e78,0x53233574,0x53233674,0x53391b14,0x53391a30,0x53391c14,0x53391c24,0x533abc5c,0x53238da4,0x5323830c,0x53238b40,0x53238724,0x53238dfc,0x532a44ec,0x5323bd38,0x532750f8]:e.stubs[a]=lambda:0
e.stubs[0x532334d0]=lambda:1
def size():u.mem_write(e.reg(0),struct.pack('<2I',720,480));return e.reg(0)
e.stubs[0x532336c4]=size;e.stubs.pop(0x5316d354,None);e.stubs.pop(0x533a1734,None)
# File operations are captured, not issued to any filesystem.
fs=e.alloc(32);disk=e.alloc(32);e.w32(fs+8,disk);e.w32(disk,e.alloc(32));saved=[]
e.stubs[0x53828014]=lambda:fs;e.stubs[0x53825fa8]=lambda:saved.append(bytes(u.mem_read(e.reg(3),e.reg(2))));e.stubs[0x53825648]=lambda:0
e.call(e.m['preferences']['init'])
c=e.call(0x5316f3b8,e.mgr,0x0200007d);ck(e.word(c)==0x53b3c4c8,'original Select vtable retained')
owner=e.alloc(0x200);e.call(0x5316c8d4,owner);e.w32(owner+0x124,0x0200004a);u.mem_write(models[0x5320afbc]+0x10,b'\x01')
posted=[]
def post():
 if e.reg(1)==0x193:posted.append((e.word(e.reg(2)),e.word(e.reg(2)+4)))
e.stubs[0x532288b0]=post;e.stubs.pop(0x5316c9d8,None)
args=e.alloc(8);event=e.alloc(12);e.w32(event+4,args);packet=e.alloc(16);press=e.alloc(8);e.w32(packet+4,press)
def deliver(old):
 target,parent=posted[-1];ck((target,parent)==(0x0200007d,0x0200004a),'queued event uses stock target and parent')
 u.mem_write(args,struct.pack('<2I',target,parent));
 try:e.call(0x5316cac0,old,event)
 except Exception:
  print('DEBUG',[hex(u.reg_read(x)) for x in [UC_ARM_REG_R0,UC_ARM_REG_R4,UC_ARM_REG_R5,UC_ARM_REG_R6,UC_ARM_REG_R9,UC_ARM_REG_LR]],flush=True);raise
 ck(e.word(c+4)==e.word(c+0x158) and e.byte(c+0x198)==44,'actual transition registers original native page/record44')
def request(cid,old=c):
 previous=e.word(c+0x1d8);e.call(0x5316c9d8,old,cid,0x0200004a)
 ck(e.word(c+0x1d8)==previous,'context unchanged until old page leaves');deliver(old)
request(0x020001a0,owner)
ck(e.word(c+0x1d8)==1 and e.call(m['count'],c)==4,'mother has four rows on stock record44')
ck(e.word(e.word(c+0x160)+0xe8)>>16==841,'native mother title')
def row_at(i):return e.call(0x53394758,e.word(c+0x18c),i)
def icon_id(row):return e.word(e.word(row+0xf0)+0xe8)>>16
def rect(view):return struct.unpack('<4I',u.mem_read(view+0x20,16))
def mother_style(expected):
 for i,value in enumerate(expected):
  row=row_at(i);label=e.word(row+0xfc);icon=e.word(row+0xf0)
  ck(rect(label)[0]==10 and rect(label)[2]==570,'mother label starts at left10 '+str(i))
  ck(rect(icon)[0]+rect(icon)[2]==660,'right status icon shares right anchor '+str(i))
  ck(icon_id(row)==value,'mother live status icon '+str(i))
  ck(e.byte(e.word(row+0xec)+0x9e)==0,'mother radio dot hidden '+str(i))
  ck(e.byte(label+0x9e)==1 and e.byte(icon+0x9e)==1,'mother name/status visible '+str(i))
mother_style([856,732,856,856])
# Execute native hierarchy layout after changing local frames, as the camera's
# UI update does, and verify that final horizontal screen coordinates survive.
root=e.word(c+0x158)
for off in [0x48,0x28,0x34]:e.call(e.word(e.word(root)+off),root)
for i in range(4):
 row=row_at(i);label=e.word(row+0xfc);icon=e.word(row+0xf0)
 ck(e.word(label+0x30)==10,'rendered hierarchy label x remains left10 '+str(i))
 ck(e.word(icon+0x30)+e.word(icon+0x38)==660,'rendered hierarchy status stays on right '+str(i))
# Focus remains native; only its redundant current-value radio dot is suppressed.
for index in [1,2,3,0]:
 e.call(0x53395430,e.word(c+0x18c),index)
 ck(e.word(e.word(c+0x18c)+0x110)&65535==index,'native focus can move without mother dot '+str(index))
# Main menu and ADJ use the same fixed FILM icon.
seen=[];old=e.stubs.get(0x5339df08);e.stubs[0x5339df08]=lambda:seen.append((e.reg(1),e.reg(2)))
e.stubs[0x5339dc70]=lambda:0;e.call(m['top'],c,row_at(0));ck(seen==[(732,0)],'outer main row fixed FILM icon')
ck(e.call(e.m['adj']['icon'],0,20)==732,'outer icon matches independent ADJ FILM')
if old is None:e.stubs.pop(0x5339df08,None)
else:e.stubs[0x5339df08]=old
e.stubs.pop(0x5339dc70,None)

def key(k,raw=False):
 e.w16(packet,k)
 if raw:
  for state in [2,1]:u.mem_write(press,bytes([state]));e.call(0x5316d5dc,c,packet)
 else:e.call(0x5316d5dc,c,packet)
for parent,context,expected in [(0,2,2),(1,3,1),(2,4,4),(3,5,6)]:
 e.call(0x53395430,e.word(c+0x18c),parent);n=len(posted);key(8,True)
 ck(len(posted)==n+1,'raw OK press/release opens child once');deliver(c)
 ck(e.word(c+0x1d8)==context and e.call(m['count'],c)==expected,'child context '+str(context))
 if context==2:ck(icon_id(row_at(0))==856 and icon_id(row_at(1))==857,'switch child uses GR4 OFF and ON glyphs')
 if context in [4,5]:ck(icon_id(row_at(0))==856 and icon_id(row_at(1))==857,'effect child uses GR4 OFF and ON glyphs '+str(context))
 if context==3:
  ck(e.word(c+0x1e4)!=0,'real widget factory creates grid tree')
  before=e.call(e.m['enabled']['enabled'],0);n=len(posted);key(8,True)
  ck(e.call(e.m['enabled']['enabled'],0)!=before and len(posted)==n,'grid OK toggles without closing')
  key(12,True);ck(e.word(c+0x1e8)==1,'physical Right moves grid cursor')
  key(11,True);ck(e.word(c+0x1e8)==0,'physical Left moves grid cursor')
  key(0xda);deliver(c)
 else:
  value={2:1,4:2,5:3}[context];e.call(0x53395430,e.word(c+0x18c),value);key(8,True);deliver(c)
  if context==2:ck(e.call(m['get'])==1,'main switch enables actual film flag')
  if context==4:ck(e.call(e.m['enabled']['grain'])==2,'grain confirm stores medium')
  if context==5:ck(e.call(e.m['enabled']['stamp'])==5,'Date+Time two-line choice maps to mode5')
 ck(e.word(c+0x1d8)==1,'child returns to film mother instead of top menu')
 ck(e.word(e.word(c+0x18c)+0x110)&65535==parent,'mother restores selected row')
mother_style([857,732,857,857])
ck(bool(saved),'settings changes call private preference save')
# Exercise the actual footer closure entry as well as physical OK. It must not
# append the stock close-to-main event after our settings action.
holder=e.alloc(16);closure=e.alloc(16);e.w32(holder,c);e.w32(closure,holder)
e.call(0x53395430,e.word(c+0x18c),2);n=len(posted);e.call(0x531ba284,closure)
ck(len(posted)==n+1,'mother touch OK posts one child request');deliver(c)
ck(e.word(c+0x1d8)==4,'mother touch OK opens grain')
e.call(0x53395430,e.word(c+0x18c),3);n=len(posted);e.call(0x531ba284,closure)
ck(len(posted)==n+1 and e.call(e.m['enabled']['grain'])==3,'child touch OK commits once and posts one mother request');deliver(c)
ck(e.word(c+0x1d8)==1,'child touch OK stays within film menu')
request(0x020001a2);n=len(posted);before=e.call(e.m['enabled']['enabled'],0);e.call(0x531ba284,closure)
ck(len(posted)==n and e.call(e.m['enabled']['enabled'],0)!=before,'grid touch OK toggles without close')
e.call(0x531ba2f4,closure);deliver(c);ck(e.word(c+0x1d8)==1,'grid touch MENU returns to mother')
# Standard BaseOpen refresh of the same page retains context without a new request.
e.call(0x5316cec8,c);e.call(0x5316dfa8,c,0x0200007d,0x0200004a,0)
ck(e.word(c+0x1d8)==1,'reopen without queued request preserves film context')
for i in range(8):
 request(0x020001a3);key(0xda);deliver(c);ck(e.word(c+0x1d8)==1,'repeat child/mother return '+str(i))
# Original Horizon delegates to the original setters/getters and original title.
calls=[];e.stubs[m['originalSet']]=lambda:calls.append((e.reg(0),e.reg(1)));e.stubs[m['originalCurrent']]=lambda:int(e.reg(1)==0)
request(0x0200007d)
ck(e.word(c+0x1d8)==0 and e.word(e.word(c+0x160)+0xe8)>>16==362,'original Horizon context and title restored')
e.call(m['setter'],c,1);ck(calls==[(c,1)],'original Horizon setter delegated unchanged')
ck(e.call(m['current'],c,0)==1,'original Horizon getter delegated unchanged')
ck(rect(e.word(row_at(0)+0xfc))[0]==100 and rect(e.word(row_at(0)+0xfc))[2]==400,'native Horizon label layout restored')
ck(e.byte(e.word(row_at(0)+0xec)+0x9e)==1,'native Horizon current-value dot retained')
report={'status':'passed','model':'GRIIIx','checks':len(checks),'details':checks,'rtosSha256':e.m['sha256'],'hardwareTested':False,'nativeExecuted':'actual original Select constructor, widget/list creation, BaseOpen/Update/Leave, native queued transition handler, scoped physical OK/Left/Right, real grid creation and rendering setup','stubbed':'camera services and ISP refresh, OS clock/timers/event delivery, filesystem, font metrics and unrelated capacity callbacks; no whole-camera/full-pixel display simulation'}
(R/'menu-native-checks.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k not in ['details']},flush=True)
