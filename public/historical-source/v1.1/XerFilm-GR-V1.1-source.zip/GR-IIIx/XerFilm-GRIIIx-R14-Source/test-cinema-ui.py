# SPDX-License-Identifier: GPL-2.0-only
# ARM checks execute native functions. OS/hardware services are fixtures, not hardware proof.
from pathlib import Path
import sys,types,struct,json,hashlib
R=Path(__file__).resolve().parent;ws=R.parents[1]
if (R.parent/'gr3-cinema-native-r1/python').exists():sys.path.insert(0,str(R.parent/'gr3-cinema-native-r1/python'))
import numpy as np
from unicorn import UC_PROT_READ,UC_PROT_EXEC,UC_HOOK_CODE
from unicorn import arm_const as A
BASE=0x53000000
original=(R/'decoded/GRIIIx/RTOS.bin').read_bytes();built=(R/'resource-build/GRIIIx/image.rtos').read_bytes();meta=json.loads((R/'resource-build/GRIIIx/resources.json').read_text());models=json.loads((R/'cinema-data.json').read_text())['models'];checks=[]
native=R/'test-support/cinema'
module=types.ModuleType('emu');module.__dict__.update(R=original,BASE=BASE,SRC=0x5407b540,DST=0x55000000,LEN=0x3a080,romw=None)
source=(native/'emu.py').read_text().replace('from fw import R, BASE, SRC, DST, LEN, w as romw','')
source=source.replace('u.hook_add(UC_HOOK_CODE, self._code)', 'self.service_hooks = set()').replace('u.hook_add(UC_HOOK_MEM_READ, self._read)', '')
source=source.replace('        u = self.u\n        for i in range(13):', '        u = self.u\n        for adr in ({0x536af2a8,0x536af31c,0x536af2e4,0x536af358,0x536b93d0}|STUB_RET0|set(self.extra_stubs))-self.service_hooks:\n            u.hook_add(UC_HOOK_CODE,self._code,begin=adr,end=adr)\n            self.service_hooks.add(adr)\n        for i in range(13):')
exec(compile(source,str(native/'emu.py'),'exec'),module.__dict__);sys.modules['emu']=module
rt=types.ModuleType('tuning');exec(compile((native/'run_tuning.py').read_text(),str(native/'run_tuning.py'),'exec'),rt.__dict__)
def ck(v,msg):
 assert v,msg
 checks.append(msg)
def setup(img,stage=0):
 e,o,i,s=rt.setup(stage,img);e.u.mem_protect(BASE,(len(img)+65535)&~65535,UC_PROT_READ|UC_PROT_EXEC);return e,o,i,s
def fields(out):
 h=np.frombuffer(out,'<u2');mats=[[int(v) for v in h[272+64*(m//5)+10*(m%5):272+64*(m//5)+10*(m%5)+9]&4095]for m in range(60)]
 return h,mats
# Native ImageControlModel lists execute original index and reverse lookup.
def ui(img,bank):
 e=module.Emu(img);e.extra_stubs.update({0x5320ad88:0,0x5320b31c:0,0x5320b7fc:0,0x532bd6d4:lambda ee:bank});return e
def obj(e,mode=0,tone=11,bank=0):
 o=e.alloc(0x100);u=e.alloc(0xc00);e.w32(o+4,u);e.w8(o+0x1b,mode);e.w8(u+0x1c0,bank)
 for off in [0x1c2,0x1c4,0x1c6]:e.w8(u+off,tone)
 return o
for bank in [0,1,2]:
 es,ep=ui(original,bank),ui(built,bank)
 for mode in [0,1,2]:
  op,os=obj(ep,mode),obj(es,mode);n=ep.call(0x532c2a9c,op);ns=es.call(0x532c2a9c,os)
  ck(n==ns+(2 if mode==0 else 0),f'list count bank/mode {bank}/{mode}')
  old=[es.call(0x532c2c80,os,k)for k in range(ns)];new=[ep.call(0x532c2c80,op,k)for k in range(n)]
  ck(new==old+([25,26]if mode==0 else []),f'every original list item retained in order {bank}/{mode}')
  ck([ep.call(0x532c2f08,op,t)for t in new]==list(range(n)),f'index round trip {bank}/{mode}')
 ck(not ep.asserts,f'list has no assertions bank {bank}')
es,ep=module.Emu(original),module.Emu(built)
for f,expected in [(0x532922b4,[889,890]),(0x532935dc,[858,859]),(0x532a985c,[889,890]),(0x532a9988,[858,859])]:
 for tone in range(40):
  ck(ep.call(f,0,tone)==(expected[tone-25]if tone in [25,26]else es.call(f,0,tone)),f'native resolver {f:x} tone {tone}')
for f in [0x532a9b2c,0x532a9ba8]:
 for bank in [0,1,2]:ck(ep.call(f,0,bank,17)==es.call(f,0,bank,17),f'Custom bank remains original {f:x}/{bank}')
for tone in list(range(11,23))+[25,26]:
 o=obj(ep,tone=tone)
 ck(ep.call(0x5326c1cc,o)==tone,f'native display code {tone}')
 # Shooting detail selector calls only native UserData and bank queries.
 ep.extra_stubs.update({0x5320ad88:0,0x5320b31c:0,0x532bd6d4:0})
 ck(ep.call(0x531aca98,o,tone)==es.call(0x531aca98,obj(es),11 if tone>=25 else tone),f'safe shooting detail {tone}')
 ck(ep.call(0x53288d5c,0,tone)==(1 if tone>=25 else es.call(0x53288d5c,0,tone)),f'safe as-shot RAW enum {tone}')
for tone in [25,26]:
 for f in [0x532c34e8,0x532c3b54,0x532c41c0,0x532c494c,0x532c50d8,0x532c5864,0x532c5ff0,0x532c8bd4,0x532c9360]:
  ck(ep.call(f,obj(ep),tone)==4,f'fixed Cinema scalar default {f:x}/{tone}')
 model=obj(ep,tone=tone);ep.extra_stubs[0x532bd6b4]=lambda ee:tone
 for f in [0x532bd784,0x532bdcd8,0x532be22c,0x532be8a0,0x532bef14,0x532bf588,0x532bfbfc,0x532c0da8,0x532c141c]:
  ud=ep.r32(model+4);before=bytes(ep.u.mem_read(ud,0xc00));ep.call(f,model,8)
  ck(bytes(ep.u.mem_read(ud,0xc00))==before,f'Cinema cannot overwrite native recipes {f:x}/{tone}')
print('Native list/custom/defaults checks passed',len(checks),flush=True)
# Actual pending UserData::Apply packet, native Std lock overrides Cinema.
e=module.Emu(built);wrap=e.alloc(0x100);ud=e.alloc(0x1000);packet=e.alloc(0x180);e.w32(wrap+4,ud)
for film in [0,1]:
 for mode in [0,1,2]:
  for tone in list(range(11,23))+[25,26]:
   e.w8(0x5503a095,film);e.w8(ud+0x44,mode)
   seed=bytearray((j*29+tone)&255 for j in range(0x180));seed[0xb8]=tone;e.u.mem_write(packet,bytes(seed))
   values=[0x60001000+j*0x100 for j in range(13)];values[4]=wrap;values[6]=packet
   for j,v in enumerate(values):e.u.reg_write(getattr(A,f'UC_ARM_REG_R{j}'),v)
   sp=0x5effff00;e.u.reg_write(A.UC_ARM_REG_SP,sp);e.u.reg_write(A.UC_ARM_REG_CPSR,0xa0000013)
   e.u.emu_start(0x53279a08,0x53279a0c,count=1000);expected=bytearray(seed)
   if mode==0 and (film or tone>=25):
    expected[0xb8:0xc7]=bytes([11 if film else tone,4,4,4,4,4,4,1,4,0,1,4,0,0,0]);expected[0xcf]=expected[0xd0]=4
   ck(bytes(e.u.mem_read(packet,0x180))==expected,f'Apply film/mode/tone {film}/{mode}/{tone}')
   want=values[:];want[1]=packet
   ck([e.u.reg_read(getattr(A,f'UC_ARM_REG_R{j}'))for j in range(13)]==want and e.u.reg_read(A.UC_ARM_REG_SP)==sp and e.u.reg_read(A.UC_ARM_REG_CPSR)==0xa0000013,'Apply native ABI and flags')
print('Combined Apply packet checks passed',len(checks),flush=True)
# Normal native maker-note constructor and photo-owned readback.
e=module.Emu(built);e.call(0x53599df0);got={};e.extra_stubs[0x535d02c8]=lambda ee:got.__setitem__('code',ee.u.reg_read(A.UC_ARM_REG_R2))or 0
si=e.alloc(0x1000);tag=e.alloc(0x40)
for tone in list(range(11,23))+[25,26,27]:
 got.clear();e.w8(si+0x77c,tone);e.call(0x535c780c,0,tag,si);code=got['code'];tg=e.alloc(0x40);e.w32(tg+0x10,0);e.u.mem_write(tg+0xc,struct.pack('<H',code));dest=e.alloc(0x1000);e.call(0x535bf7a8,0,tg,dest)
 ck((code,e.u.mem_read(dest+0x77c,1)[0])==((0x100+tone-11,tone)if tone<=22 else(0x10c+tone-25,tone)if tone<=26 else(0x100,11)),f'native maker-note round trip {tone}')
ck(not e.asserts,'maker-note static constructor and native roundtrip no assertions')
e=module.Emu(built);state={};destination=e.alloc(0x400);outbuf=e.alloc(8)
e.extra_stubs[0x535d04d4]=lambda ee:state['code']
e.extra_stubs[0x535be068]=lambda ee:state.__setitem__('property',ee.u.reg_read(A.UC_ARM_REG_R2))or 1
e.extra_stubs[0x535be018]=lambda ee:state['property']
for code in [0x10c,0x820a,0x10d,0x820b,0x100,0x10c,0x821a,0x10d]:
 state['code']=code;e.call(0x535c24ec,0,destination,0);e.call(0x532b44bc,destination,outbuf);display=e.u.mem_read(outbuf,1)[0]
 film=0x8200<=code<=0x821a;cinema=code in [0x10c,0x10d]
 if film:ck(display==64+code-0x8200,'XerFilm private INFO identity retained')
 if cinema:ck(display==96+code-0x10c,'native Cinema INFO identity separate')
 for reg,value in [(A.UC_ARM_REG_R3,display),(A.UC_ARM_REG_SP,0x5effff00)]:e.u.reg_write(reg,value)
 e.u.emu_start(0x532b6f34,0x532b6f54,count=300)
 if cinema:ck(e.u.reg_read(A.UC_ARM_REG_R0)==858+code-0x10c,'native Cinema current-photo INFO icon')
 if film:
  want=struct.unpack('<I',built[meta['metadata']['icons']-BASE+(code-0x8200)*4:meta['metadata']['icons']-BASE+(code-0x8200)*4+4])[0]
  ck(e.u.reg_read(A.UC_ARM_REG_R0)==want,'XerFilm current-photo INFO icon retained')
 e.u.reg_write(A.UC_ARM_REG_R2,display);e.u.reg_write(A.UC_ARM_REG_SP,0x5effff00);e.u.emu_start(0x532b7d0c,0x532b7d10,count=300)
 if film or cinema:ck(e.u.reg_read(A.UC_ARM_REG_R2)==3,'supported INFO parameter row layout')
ck(not e.asserts,'combined INFO chain no assertions')
# Original native tone setters persist new selections in the active native
# bank; while independent film is ON the same setters remain blocked.
import importlib.util
spec=importlib.util.spec_from_file_location('port',R/'test-port.py');port=importlib.util.module_from_spec(spec);spec.loader.exec_module(port)
e=port.Emu('GRIIIx');nativeModel=e.alloc(0x100);e.w8(nativeModel+0x1b,0);ud=0x70005000
for film in [0,1]:
 for bank in [0,1,2]:
  for tone in [25,26]:
   e.w8(port.FLAG,film);e.w8(ud+0x44,0);e.w8(ud+0x1c0,bank);off=[0x1c2,0x1c4,0x1c6][bank];e.w8(ud+off,14)
   before=bytes(e.u.mem_read(ud,0xc00));e.call(0x532c26c0,nativeModel,tone)
   expected=bytearray(before)
   if not film:expected[off]=tone
   ck(bytes(e.u.mem_read(ud,0xc00))==expected,f'native selected Cinema persists only intended bank, film lock intact {film}/{bank}/{tone}')
report=dict(status='passed',hardwareTested=False,rtosSha256=hashlib.sha256(built).hexdigest(),checks=len(checks),preservedCustomBanks=True,newNativeTones=[25,26],notes='Native ARM paths execute with hardware/services stubs; camera validation required.')
(R/'cinema-ui-checks.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
