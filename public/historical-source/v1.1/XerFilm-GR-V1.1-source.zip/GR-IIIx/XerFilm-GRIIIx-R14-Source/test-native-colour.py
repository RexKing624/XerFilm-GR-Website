# SPDX-License-Identifier: GPL-2.0-only
# Execute original GR IIIx ImageTuning ARM code against native synthetic fixtures.
from pathlib import Path
import types,struct,json,sys
from unicorn import UC_PROT_READ,UC_PROT_EXEC,UC_HOOK_CODE
R=Path(__file__).resolve().parent;native=R/'test-support/cinema';BASE=0x53000000
original=(R/'decoded/GRIIIx/RTOS.bin').read_bytes()
module=types.ModuleType('emu');module.__dict__.update(R=original,BASE=BASE,SRC=0x5407b540,DST=0x55000000,LEN=0x3a0a0,romw=None)
source=(native/'emu.py').read_text().replace('from fw import R, BASE, SRC, DST, LEN, w as romw','')
source=source.replace('u.hook_add(UC_HOOK_CODE, self._code)', 'self.service_hooks = set()').replace('u.hook_add(UC_HOOK_MEM_READ, self._read)', '')
source=source.replace('        u = self.u\n        for i in range(13):', '        u = self.u\n        for adr in ({0x536af2a8,0x536af31c,0x536af2e4,0x536af358,0x536b93d0}|STUB_RET0|set(self.extra_stubs))-self.service_hooks:\n            u.hook_add(UC_HOOK_CODE,self._code,begin=adr,end=adr)\n            self.service_hooks.add(adr)\n        for i in range(13):')
exec(compile(source,str(native/'emu.py'),'exec'),module.__dict__);sys.modules['emu']=module
rt=types.ModuleType('tuning');exec(compile((native/'run_tuning.py').read_text(),str(native/'run_tuning.py'),'exec'),rt.__dict__)
results=[]
for model in ['GRIIIx']:
 b=(R/'resource-build'/model/'image.rtos').read_bytes();meta=json.loads((R/'resource-build'/model/'resources.json').read_text());checks=[]
 def ck(x,msg):assert x,(model,msg);checks.append(msg)
 e,obj,info,si=rt.setup(0,b);e.u.mem_protect(BASE,(len(b)+65535)&~65535,UC_PROT_READ|UC_PROT_EXEC)
 e.call(meta['preferences']['init'])
 e0,o0,i0,s0=rt.setup(0,(R/'decoded'/model/'RTOS.bin').read_bytes())
 for tone in [11,12,13,14,17,18,21,22]:
  e.w8(0x5503a095,0);a=rt.make(e,obj,info,si,tone,stage=0);o=rt.make(e0,o0,i0,s0,tone,stage=0)
  ck(a[0x120:0x8000]==o[0x120:0x8000],'film OFF native ISP output identical for tone'+str(tone))
 base=rt.make(e0,o0,i0,s0,11,stage=0);outputs=[];gamma_calls=[]
 def used_gamma(u,a,size,data):gamma_calls.append(1)
 e.u.hook_add(UC_HOOK_CODE,used_gamma,begin=meta['runtime']['gamma'],end=meta['runtime']['gamma'])
 for look in range(27):
  gamma_calls.clear()
  e.w8(0x5503a094,look);e.w8(0x5503a095,1);out=rt.make(e,obj,info,si,14,stage=0);ck(out[0x120:0x8000]!=base[0x120:0x8000],'film actually changes native ISP '+str(look));outputs.append(out);ck(bool(gamma_calls),'fitted RGB curve getter executed '+str(look))
  # Eight matrix/level sets route into the original hardware pipeline, not UI labels only.
 ck(len(set(x[0x120:0x8000]for x in outputs))==27,'all27 native processing outputs are distinct')
 # Independence means the same film must produce the same ISP configuration
 # even when the previous native Image Control was Vivid or Soft B&W. Verify
 # real ImageTuning output rather than checking only the displayed Std label.
 for look in [0,6,10,11,12,17,26]:
  e.w8(0x5503a094,look);e.w8(0x5503a095,1)
  reference=rt.make(e,obj,info,si,11,stage=0)
  for tone in [12,13,14,17,18,21,22]:
   actual=rt.make(e,obj,info,si,tone,stage=0)
   ck(actual[0x120:0x8000]==reference[0x120:0x8000],'film '+str(look)+' independent of previous native tone '+str(tone))
 for tone in [11,14,17]:
  e.w8(0x5503a095,0);a=rt.make(e,obj,info,si,tone,stage=0);o=rt.make(e0,o0,i0,s0,tone,stage=0);ck(a[0x120:0x8000]==o[0x120:0x8000],'switching OFF restores native ISP after last film: '+str(tone))
 ck(not e.asserts,'no native assertions while processing film looks: '+str(e.asserts[:8]));ck(set(e.svcs)<=set(e0.svcs),'only supervisor calls also present in native baseline: '+str((len(e.svcs),set(e.svcs),len(e0.svcs),set(e0.svcs))))
 result=dict(model=model,status='passed',checks=len(checks),originalNativeMakeExecuted=True,hardwareTested=False);results.append(result);print(result,flush=True)
(R/'native-colour-checks.json').write_text(json.dumps(results,indent=2))
