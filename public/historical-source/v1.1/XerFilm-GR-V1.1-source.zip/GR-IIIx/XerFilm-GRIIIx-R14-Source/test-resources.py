from pathlib import Path
import json,struct,hashlib
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_ARM,UC_PROT_READ,UC_PROT_EXEC
from unicorn.arm_const import *
ROOT=Path(__file__).resolve().parent;BASE=0x53000000;ICONS=0x540b5600
reports=[]
for model in ['GRIIIx']:
 out=ROOT/'resource-build'/model;image=(out/'image.rtos').read_bytes();meta=json.loads((out/'resources.json').read_text());original=(ROOT/'decoded'/model/'RTOS.bin').read_bytes()
 mu=Uc(UC_ARCH_ARM,UC_MODE_ARM);mu.mem_map(BASE,(len(image)+65535)&~65535);mu.mem_write(BASE,image);mu.mem_protect(BASE,(len(image)+65535)&~65535,UC_PROT_READ|UC_PROT_EXEC)
 mu.mem_map(0x55000000,0x100000);mu.mem_write(0x55000000,image[0x107b540:0x10b55c0]);mu.mem_map(0x70000000,0x10000);mu.mem_map(0x71000000,0x1000)
 def word(a):return struct.unpack('<I',mu.mem_read(a,4))[0]
 def call(a,id):
  mu.reg_write(UC_ARM_REG_SP,0x7000f000);mu.reg_write(UC_ARM_REG_LR,0x71000000);mu.reg_write(UC_ARM_REG_R0,0);mu.reg_write(UC_ARM_REG_R1,id);mu.emu_start(a,0x71000000,count=500);assert mu.reg_read(UC_ARM_REG_PC)==0x71000000;return mu.reg_read(UC_ARM_REG_R0)
 for id in range(0x29f):
  desc=word(0x550020fc+id*4);expected=struct.unpack('<HH',mu.mem_read(desc,4)) if desc else (0,0)
  assert call(0x53209fb8,id)==expected[0],(id,'width');assert call(0x53209fec,id)==expected[1],(id,'height')
 for icon in meta['resources']['icons']:
  id=icon['id'];assert call(0x53209fb8,id)==icon['width'];assert call(0x53209fec,id)==icon['height']
  for native in [False,True]:
   pixel=icon['data'];value=(0x54321 if native else pixel|0x80000000);oldflags=0xa0000013;stack=0x7000f000
   for reg,val in [(UC_ARM_REG_CPSR,oldflags),(UC_ARM_REG_SP,stack),(UC_ARM_REG_R0,0x12345678),(UC_ARM_REG_R6,value),(UC_ARM_REG_LR,0x51600000)]:mu.reg_write(reg,val)
   mu.emu_start(0x5320a834,0x5320a838,count=100)
   expected=0x51600000+value*4 if native else pixel
   assert mu.reg_read(UC_ARM_REG_R12)==expected
   assert mu.reg_read(UC_ARM_REG_R0)==0x12345678 and mu.reg_read(UC_ARM_REG_SP)==stack and mu.reg_read(UC_ARM_REG_CPSR)==oldflags
 edits={e['address']-BASE for e in meta['edits']};diffs={i for i in range(0,len(original),4) if original[i:i+4]!=image[i:i+4]};assert diffs==edits
 assert len(image)+BASE<0x55000000
 reports.append({'model':model,'nativeIconQueries':0x29f*2,'customIconQueries':len(meta['resources']['icons'])*2,'pixelPointerCases':len(meta['resources']['icons'])*2,'nativeEdits':len(edits),'romWriteProtected':True,'hardwareTested':False,'status':'passed'})
(ROOT/'resources-checks.json').write_text(json.dumps(reports,indent=2));print(reports)
