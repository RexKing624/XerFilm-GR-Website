# SPDX-License-Identifier: GPL-2.0-only
# Native ARM routines execute. Hardware widget allocation, device notifications,
# capability queries and stock capacity-count callbacks are test doubles.
from pathlib import Path
import struct,json
from collections import deque
from unicorn import *
from unicorn.arm_const import *
R=Path(__file__).resolve().parent/'resource-build/GRIIIx';BASE=0x53000000;STOP=0x100
REGS=[UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3,UC_ARM_REG_R4,UC_ARM_REG_R5,UC_ARM_REG_R6,UC_ARM_REG_R7,UC_ARM_REG_R8,UC_ARM_REG_R9,UC_ARM_REG_R10,UC_ARM_REG_R11,UC_ARM_REG_R12]
class Emu:
 def __init__(self):
  self.image=(R/'image.rtos').read_bytes();self.m=json.loads((R/'resources.json').read_text());self.menu=self.m['menu'];self.u=Uc(UC_ARCH_ARM,UC_MODE_ARM);u=self.u
  u.mem_map(BASE,0x2000000);u.mem_write(BASE,self.image);u.mem_protect(BASE,0x2000000,UC_PROT_READ|UC_PROT_EXEC)
  u.mem_map(0x55000000,0x1000000);s,d,n=struct.unpack_from('<III',self.image,0x450);u.mem_write(d,self.image[s-BASE:s-BASE+n]);u.mem_map(0x60000000,0x100000);u.mem_map(0x70000000,0x1000000);u.mem_map(0,0x1000)
  self.heap=0x70010000;self.trace=deque(maxlen=2000);self.log=[];self.allocations=[];self.stubs={};self.vt=0x70001000
  for o in range(0,0x80,4):self.w32(self.vt+o,0x70002000)
  self.w32(self.vt+0x18,0x70002004)
  self.mgr=self.alloc(0x200);self.stubs[0x5316f350]=lambda:self.mgr
  self.stubs.update({0x536af2a8:lambda:self.alloc(self.reg(0)),0x536af31c:lambda:self.alloc(self.reg(0)),0x536af2e4:lambda:0,0x536af358:lambda:0,0x533ad7f0:self.widget,0x53394610:self.items,
   0x536c74d4:lambda:0,0x53234d60:lambda:0,0x531b9410:lambda:0,0x5320ad88:lambda:0x70003000,0x5320b73c:lambda:0x70003000,0x532b0f90:lambda:0,0x5320b19c:lambda:0x70003000,0x53237460:lambda:1,
   0x53394b38:lambda:0,0x536e7488:lambda:0,0x533ad308:lambda:0,0x533ad2c8:lambda:0,0x533ad3c0:lambda:0,0x533aba64:lambda:0,0x53393e00:lambda:0,
   0x5316d354:lambda:0,0x5320804c:lambda:0x70003000,0x53208298:lambda:0x70003000,0x5320b1fc:lambda:0x70003000,0x5323c0ac:lambda:0,
   0x53394f58:lambda:0,0x53394e8c:lambda:0,0x53395430:self.setindex,0x533accd8:self.getrect,0x53396a2c:self.fontrect,0x536df484:lambda:0,0x536df55c:lambda:0,0x536b93d0:self.assertion,
   0x53395260:self.step,0x533952c0:self.step,0x5316cde8:lambda:0,0x53394768:lambda:0,0x533958a8:lambda:0,
   0x533a1734:self.adjicon,0x53396f4c:lambda:0,0x5316ca28:self.close,0x5316c9d8:self.transition,
   0x536bbc30:lambda:0x70003000,0x536bbcc0:lambda:0,0x536bbcac:lambda:0})
  # Stock count callbacks are outside the new feature and query camera hardware.
  # The unchanged max-capacity scanner itself still executes all117 records.
  for i in range(117):
   a=self.word(self.menu['lists']+64*i+8)
   if a:self.stubs[a]=lambda:6
  u.hook_add(UC_HOOK_CODE,self.hook)
 def reg(self,i):return self.u.reg_read(REGS[i])
 def word(self,a):return struct.unpack('<I',self.u.mem_read(a,4))[0]
 def byte(self,a):return self.u.mem_read(a,1)[0]
 def w32(self,a,v):self.u.mem_write(a,struct.pack('<I',v&0xffffffff))
 def w16(self,a,v):self.u.mem_write(a,struct.pack('<H',v&65535))
 def alloc(self,n=0x400):
  a=(self.heap+15)&~15;self.heap=a+max(n,16);self.allocations.append((a,n));assert self.heap<0x70e00000;return a
 def view(self):
  a=self.alloc();self.w32(a,self.vt)
  for o in [0xec,0xf0,0xf4,0xf8,0xfc,0x100]:
   c=self.alloc();self.w32(a+o,c);self.w32(c,self.vt)
  return a
 def widget(self):return self.view()
 def items(self):
  obj=self.reg(0);n=self.reg(2);arr=self.alloc(n*4)
  for i in range(n):node=self.alloc(16);self.w32(node,self.view());self.w32(arr+4*i,node)
  self.w32(obj+0xf4,arr);self.w32(obj+0xf8,arr+n*4);return 0
 def setindex(self):self.w16(self.reg(0)+0x110,self.reg(1))
 def step(self):
  l=self.reg(0);delta=self.reg(1);delta=delta if delta<0x80000000 else delta-0x100000000;self.w16(l+0x110,(self.word(l+0x110)+delta)%2)
 def getrect(self):self.u.mem_write(self.reg(0),struct.pack('<4I',0,0,720,360))
 def fontrect(self):self.u.mem_write(self.reg(0),struct.pack('<2I',80,40));return self.reg(0)
 def assertion(self):
  if not self.reg(0):raise AssertionError(('native assert',hex(self.u.reg_read(UC_ARM_REG_LR)),self.reg(3)))
 def rect(self):self.u.mem_write(self.reg(0)+0x30,bytes(self.u.mem_read(self.reg(1),16)))
 def adjicon(self):self.w16(self.reg(0)+0xea,self.reg(1))
 def close(self):self.log.append(('close',self.reg(0)))
 def transition(self):self.log.append(('transition',self.reg(1),self.reg(2)))
 def hook(self,u,a,size,data):
  self.trace.append(hex(a))
  if a==0:raise RuntimeError(('null branch',[x for x in self.trace if x.startswith(('0x531b','0x5339','0x533a'))][-40:]))
  if a==0x70002004:self.rect();u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR));return
  if a==0x70002000:u.reg_write(UC_ARM_REG_R0,0);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR));return
  if a in self.stubs:
   v=self.stubs[a]();u.reg_write(UC_ARM_REG_R0,(v or 0)&0xffffffff);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
 def call(self,a,*args,limit=1000000,until=STOP):
  u=self.u;u.reg_write(UC_ARM_REG_SP,0x600f0000);u.reg_write(UC_ARM_REG_LR,STOP)
  for i,v in enumerate(args):u.reg_write(REGS[i],v)
  try:u.emu_start(a,until,count=limit)
  except Exception as ex:raise RuntimeError((hex(a),[x for x in self.trace if x.startswith(('0x531b','0x5339','0x533a'))][-35:],str(ex))) from ex
  assert u.reg_read(UC_ARM_REG_PC)==until,('did not return',hex(a),hex(u.reg_read(UC_ARM_REG_PC)),list(self.trace))
  assert u.reg_read(UC_ARM_REG_SP)==0x600f0000,('stack changed',hex(a))
  return self.reg(0)
