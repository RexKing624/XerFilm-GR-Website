# XerFilm GR IIIx R14 — Settings Image Control capacity fix

User reports entering native Settings > Image Control freezes with film simulation both ON and OFF. ADJ continues working.

Root cause reproduced by original ARM allocation (531abc3c) and population (531ab7e4), with original item getter (53394758): R13 GetCount returns14 styles, but GetMaxCount capacity table53b5d368 still contains10/10/10/12/12/12. Settings allocates max12+Custom2=14, populates14+Custom2=16 and reads out of bounds on item14. ADJ has a separate allocation path.

Fix only the three still capacity bytes at53b5d36b..d36d from12 to14. Movie counts remain10. No native filter, Custom recipe, ADJ, LUT, image processing, grain, timestamp or INFO code/assets change. Regression:100 focused settings checks including reproducing R13's exact out-of-bounds access, plus all existing native-menu, resources, JPG, isolation, child-selection and Cinema suites. Fixtures replace hardware services/widgets; this is not camera proof.

Outputs: outputs/XerFilm-GRIIIx-R14-MenuFix-2026-10-21. Ordinary stays installation1.60, enhanced stays1.61, including previously tested version/update metadata. Both final containers preserve all original headers and decoded content except three capacity bytes and payload checksum. Compressed stored-frame replacement changes physical BIN size. Independent Python decoder verifies exact final BINs.

Rebuild from workspace root:
- work/gr4-kodak-fw-v23/node_modules/.bin/vite-node work/gr3x-native-menu-r14/build.ts
- work/gr4-kodak-fw-v23/node_modules/.bin/tsc -p work/gr3x-native-menu-r14/tsconfig.json --noEmit
- work/reverse-env/bin/python work/gr3x-native-menu-r14/run-checks.py (Unicorn JIT permission)
- work/gr4-kodak-fw-v23/node_modules/.bin/vite-node work/gr3x-native-menu-r14/package-fix.ts
- work/reverse-env/bin/python work/gr3x-native-menu-r14/verify-delivery.py

No camera/card writes or website publication in these scripts. Prior R13 and R13-H inputs remain unchanged; exact base SHA guards are in package-fix.ts. Physical-camera retest pending. GR III and GR IV unchanged in this task.
