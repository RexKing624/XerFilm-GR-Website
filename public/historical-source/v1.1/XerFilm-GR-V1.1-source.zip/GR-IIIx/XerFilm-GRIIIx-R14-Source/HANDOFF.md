# GR IIIx R14 native Settings Image Control capacity fix — 2026-10-21

User requests applying the preceding GR III Settings Image Control freeze fix to IIIx ordinary and enhanced builds. Isolated clone from IIIx R13 with the same3 capacity bytes53b5d36b/c/d 12->14. Existing R13 source/artifacts and all website files untouched.

IIIx bug reproduced with native settings allocation531abc3c/population531ab7e4/itemlookup53394758:14 allocated items,16 accessed including Custom1/2; baseline fails at index14. Fixed100 focused checks passed for bank0/1/2×mode0/1/2×FILM ON/OFF; all existing ARM suites passed. Feature RTOS SHA163624aa24db2405f82707d1c0c0870f0776c95ea8f9186288bacb402063bb14. Full parity vs GR III R14 preserves all31 original model byte differences and exact shared feature code/assets. Strict TS passed.

package-fix.ts patches exact pinned distributed IIIx R13/R13-H. Ordinary retains1.60/project609; enhanced retains1.61/project609 including update gate. Container header/version bytes and all decoded content unchanged outside3 capacity bytes+payloadchecksum. Independent Python decoder final checks50passed. Final feature image matches ARM-validated candidate. No camera/SD writes; hardware retest pending.

Outputs outputs/XerFilm-GRIIIx-R14-MenuFix-2026-10-21:
- GRIIIx-R14-ordinary-1.60/fwdc243b.bin35542308bytes SHA00770c1b1d9d9b7098c7833df89a8dd293f47629ea58b3576ae5ecd8e511b974
- GRIIIx-R14-enhanced-1.61/fwdc243b.bin35579496bytes SHA0f4d1610471c7a1be66a09508fc15029f89360451960ff5300400a8223fc5cb9
- Model-specific TEST ZIPs, SOURCE ZIP, Chinese instructions and checks.

Website is unchanged R13/R13-H and does not yet carry untested R14 fixes. Earlier GR III R14 outputs remain in outputs/XerFilm-GRIII-R14-MenuFix-2026-10-21. User should use only matching model/version BIN at card root; no JSON installation.
