// SPDX-License-Identifier: GPL-2.0-only
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {Patch,BASE} from './src/build';
import {installResources} from './src/resources';
import {installPreferences} from './src/preferences';
import {installFilmEnabled} from './src/film-enabled';
import {installFilmGrid} from './src/film-grid';
import {installMenu} from './src/menu';
import {installFilmAdj} from './src/film-adj';
import {installRuntime} from './src/film-runtime';
import {installFilmStamp} from './src/film-stamp';
import {installFilmMetadata} from './src/film-metadata';
import {installNativeCinema} from './src/native-cinema';
import {installFilmCapture} from './src/film-capture';
const root='work/gr3x-native-menu-r14',original=new Uint8Array(readFileSync('work/gr3-series-port/decoded/GRIIIx/RTOS.bin'));
if(createHash('sha256').update(original).digest('hex')!=='0f11b0d28bc67932d044c5d01bc0314844a756057c89984278c73a23449a24c6')throw Error('Official GR IIIx RTOS hash mismatch');
const p=new Patch(original),resources=installResources(p),preferences=installPreferences(p),enabled=installFilmEnabled(p),grid=installFilmGrid(p),menu=installMenu(p),adj=installFilmAdj(p),runtime=installRuntime(p),stamp=installFilmStamp(p),metadata=installFilmMetadata(p),capture=installFilmCapture(p),cinema=installNativeCinema(p,runtime);
const image=p.bytes(),sha256=createHash('sha256').update(image).digest('hex');
// No added Select/SubMenu records, mapping hooks, or modified controller vtables.
const untouched:Array<[number,number]>=[[0x531b9640,4],[0x531c5950,4],[0x53b3fb10,1800],[0x53b3c4c0,68],[0x53b3fa70,68],[0x531ba534,4]];
for(const[a,n]of untouched)if(!Buffer.from(image.subarray(a-BASE,a-BASE+n)).equals(Buffer.from(original.subarray(a-BASE,a-BASE+n))))throw Error('Forbidden native table/controller change '+a.toString(16));
mkdirSync(`${root}/resource-build/GRIIIx`,{recursive:true});writeFileSync(`${root}/resource-build/GRIIIx/image.rtos`,image);
writeFileSync(`${root}/resource-build/GRIIIx/resources.json`,JSON.stringify({model:'GRIIIx',stage:'R14 fixes native Settings Image Control maximum capacity; all other feature bytes unchanged from R13',hardwareTested:false,bytes:image.length,sha256,rtosSha256:sha256,resources,cinema,preferences,enabled,grid,menu,adj,runtime,stamp,metadata,capture,edits:p.words,unchangedRegions:untouched},null,2));
console.log('GR IIIx R14',image.length,sha256);
