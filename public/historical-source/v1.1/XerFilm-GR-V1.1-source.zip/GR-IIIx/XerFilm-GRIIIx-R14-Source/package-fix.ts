// SPDX-License-Identifier: GPL-2.0-only
// Minimal, guarded replacement of three capacity bytes in each distributed GR IIIx build.
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {Firmware,build,verifyContainer,sum32,sectionsOf} from './src/container';
const root='work/gr3x-native-menu-r14',out='outputs/XerFilm-GRIIIx-R14-MenuFix-2026-10-21';
const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
const candidate=new Uint8Array(readFileSync(`${root}/resource-build/GRIIIx/image.rtos`));
const verified=JSON.parse(readFileSync(`${root}/verified-images.json`,'utf8'));
if(verified.GRIIIx!==sha(candidate))throw Error('Current regression validation required');
const regression=JSON.parse(readFileSync(`${root}/settings-image-control-checks.json`,'utf8'));
if(regression.status!=='passed'||regression.rtosSha256!==sha(candidate)||regression.checks!==100)throw Error('Settings reproduction and fix validation required');
const targets=[
 {kind:'ordinary',version:'1.60',path:'outputs/XerFilm-GRIIIx-R13-Cinema-2026-10-21/GRIIIx-1.60-XerFilm-R13/fwdc243b.bin',sha:'31ff0cde8ace96eb9d6cfdda86da3a90832e703dd3ddbfb5fd8f36152a6680fd'},
 {kind:'enhanced',version:'1.61',path:'outputs/XerFilm-GRIII-Series-R13-H-2026-10-21/GRIIIx-R13-H-1.61/fwdc243b.bin',sha:'2cfd3e0214e17e785ca0a5d5158869be4b409a1a32756fc2193f433f81a14dda'},
];
const reports=[];
for(const target of targets){
 const input=new Uint8Array(readFileSync(target.path));if(sha(input)!==target.sha)throw Error('Original distributed BIN changed');
 const fw=new Firmware(input);if(fw.project!==609)throw Error('GR IIIx model guard');
 const data=fw.decoded.slice(),sections=sectionsOf(data),rtos=sections.find(s=>s.name==='RTOS')!;
 const edits:Array<{rtosOffset:number,address:string,before:number,after:number}>=[];
 for(const offset of [0xb5d36b,0xb5d36c,0xb5d36d]){
  if(data[rtos.offset+offset]!==12)throw Error('Native count table mismatch');
  data[rtos.offset+offset]=14;edits.push({rtosOffset:offset,address:(0x53000000+offset).toString(16),before:12,after:14});
 }
 const restored=data.slice();for(const e of edits)restored[rtos.offset+e.rtosOffset]=e.before;
 if(!Buffer.from(restored).equals(Buffer.from(fw.decoded)))throw Error('Unexpected firmware change');
 // The ordinary build must match the independently rebuilt and regression-tested
 // source image exactly. Enhanced differs only by previously verified versions/gate.
 const ordinary=new Firmware(new Uint8Array(readFileSync(targets[0].path)));const ordinaryRtos=sectionsOf(ordinary.decoded).find(s=>s.name==='RTOS')!;
 const featureBytes=data.slice(rtos.offset,rtos.offset+candidate.length);
 if(target.kind==='enhanced'){
  const baseline=ordinary.decoded.subarray(ordinaryRtos.offset,ordinaryRtos.offset+candidate.length);
  for(const offset of [0x2038,0x81fe6c,0x81fe7c,0x6285dc])featureBytes.set(baseline.subarray(offset,offset+4),offset);
 }
 if(!Buffer.from(featureBytes).equals(Buffer.from(candidate)))throw Error('Final firmware differs from verified feature image');
 const view=new DataView(data.buffer);view.setUint32(data.length-4,0,true);view.setUint32(data.length-4,(-sum32(data))>>>0,true);
 const result=build(fw,data),validation=verifyContainer(result.out,data);
 if(!Object.values(validation.checks).every(Boolean)||!Buffer.from(build(fw,data).out).equals(Buffer.from(result.out)))throw Error('Final container validation');
 const again=new Firmware(result.out);if(!Buffer.from(again.header).equals(Buffer.from(fw.header))||again.project!==609)throw Error('Version/model header changed');
 const diffs=[];for(let i=0;i<data.length;i++)if(data[i]!==fw.decoded[i])diffs.push(i);
 if(diffs.some(i=>!edits.some(e=>i===rtos.offset+e.rtosOffset)&&i<data.length-4))throw Error('Unexpected final change');
 const folder=`${out}/GRIIIx-R14-${target.kind}-${target.version}`;mkdirSync(folder,{recursive:true});writeFileSync(`${folder}/fwdc243b.bin`,result.out);
 const report={build:target.kind==='enhanced'?'R14-H':'R14',model:'GR IIIx / HDF',installationVersion:target.version,filename:'fwdc243b.bin',size:result.out.length,sha256:sha(result.out),basePath:target.path,baseSha256:target.sha,hardwareTested:false,verifiedRtosSha256:sha(candidate),edits,decodedChangedOffsets:diffs,checks:{...validation.checks,exactFeatureImage:true,onlyThreeCapacityBytesAndPayloadChecksumChanged:true,originalHeaderModelAndDecodedLengthRetained:true,reproducibleBuild:true},regression};
 writeFileSync(`${folder}/validation.json`,JSON.stringify(report,null,2));writeFileSync(`${folder}/SHA256SUMS.txt`,report.sha256+'  fwdc243b.bin\n');reports.push(report);console.log(report.build,target.version,report.size,report.sha256);
}
writeFileSync(`${out}/validation.json`,JSON.stringify({status:'local ARM regression passed; hardware retest pending',reports},null,2));
