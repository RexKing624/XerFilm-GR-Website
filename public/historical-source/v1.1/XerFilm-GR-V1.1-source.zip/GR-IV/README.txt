GPL-2.0-only. Bridge source: Maxwooow/Ricoh-GRMod v0.8.0 (16327db).
No full original Ricoh firmware or user photos in this source archive.
Reproduction needs Node22 with vite-node2 and the original v23 source archive (base-v23-source.zip), plus the exact official GR IV1.11 input and v23 binary identified in build-report.json.
Unpack base-v23-source.zip into work/gr4-kodak-fw-v23 with its original dependencies; it contains the build pipeline for the base v23 firmware.
Provide the matching original v23 binary at outputs/GR4-INFO逐张身份与子菜单确认-v23/fwdc248b.bin.
From workspace root run vite-node work/gr4-v23-high-version-20261019/inspect.ts /path/to/official/fwdc248b.bin, then vite-node work/gr4-v23-high-version-20261019/build.ts NEW_OUTPUT_DIRECTORY.
inspect.ts reconstructs the exact upstream bridge in memory using its publicly supplied delta and verifies SHA256 before mapping section-relative changes.
build.ts copies only guarded section-relative changes into v23, fixes the v23 checksum, repacks and verifies reproducibility and exact feature preservation.
verify.py independently decodes with gr-custom-tool Python codec. test-native.py needs Unicorn/Capstone and permission for local JIT; it executes only the five native version accessors and the reviewed update-rejection branch. No camera is connected or flashed.
Base v23 source includes the existing full v23 code and checks. Source package names may need restoring to the workspace paths shown in the scripts. The new build output requires independent hardware testing.
