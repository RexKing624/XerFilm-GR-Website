#!/usr/bin/env python3
"""Execute GR IV 1.11 native grain preparation and processing-plan functions.

This checks the actual downstream parameter block, not only the injected setter.
It does not run the DSP/capture engine and is not a camera or image-quality test.
Only the firmware assertion/logger is stubbed. A false native assertion fails.

Usage:
  work/reverse-env/bin/python work/gr4-fuji-fw-v2/audit-grain/check_grain.py \
      --stock work/filter-analysis/RTOS.bin --candidate BUILT.bin.rtos \
      --json work/gr4-fuji-fw-v2/audit-grain/report.json
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import struct
from pathlib import Path

from unicorn import Uc, UcError, UC_ARCH_ARM, UC_MODE_ARM, UC_HOOK_CODE, UC_HOOK_INTR
from unicorn import arm_const as A

BASE = 0x53000000
RAM = 0x55000000
RAM_IMAGE = 0x5437B640
RAM_SIZE = 0x57480
FLAGS = 0x55084DD8 + 4 + 0x94B
PREPARE = 0x53701C40
GATE = 0x537150FC
ASSERT = 0x538ED930
STOP = 0x5E000000
STACK = 0x5F0FF000
CONTEXT = 0x60001000
PARAMS = 0x60002000
SI = 0x60010000
STOCK_SHA256 = 'a9a9a51530c35819df47dee1cce9f4f560a17eeed1da258950167d282884fce1'
REGS = [getattr(A, f'UC_ARM_REG_R{i}') for i in range(13)]
PRESERVED = REGS[4:12]


class Emulator:
    def __init__(self, image: bytes):
        self.mu = Uc(UC_ARCH_ARM, UC_MODE_ARM)
        mu = self.mu
        mu.mem_map(BASE, (len(image) + 0xFFFF) & ~0xFFFF)
        mu.mem_write(BASE, image)
        mu.mem_map(RAM, 0x1000000)
        mu.mem_write(RAM, image[RAM_IMAGE-BASE:RAM_IMAGE-BASE+RAM_SIZE])
        mu.mem_map(STOP, 0x1000)
        mu.mem_map(0x5F000000, 0x100000)
        mu.mem_map(0x60000000, 0x100000)
        mu.reg_write(A.UC_ARM_REG_C1_C0_2, 0xF00000)
        mu.reg_write(A.UC_ARM_REG_FPEXC, 0x40000000)
        self.asserts: list[dict] = []
        self.interrupts: list[int] = []
        self.visited: set[int] = set()
        mu.hook_add(UC_HOOK_CODE, self._code)
        mu.hook_add(UC_HOOK_INTR, self._interrupt)

    def _code(self, mu, at, size, user):
        self.visited.add(at)
        if at == ASSERT:
            ok = mu.reg_read(A.UC_ARM_REG_R0)
            if not ok:
                self.asserts.append({'lr': hex(mu.reg_read(A.UC_ARM_REG_LR)),
                                     'line': mu.reg_read(A.UC_ARM_REG_R3)})
            mu.reg_write(A.UC_ARM_REG_R0, 0)
            mu.reg_write(A.UC_ARM_REG_PC, mu.reg_read(A.UC_ARM_REG_LR))

    def _interrupt(self, mu, interrupt, user):
        self.interrupts.append(interrupt)
        mu.emu_stop()

    def configure(self, flags: int, tone: int, enable: int, size: int,
                  strength: int, shading: int = 4, clarity: int = 4):
        mu = self.mu
        mu.mem_write(CONTEXT, bytes([0xA5])*0x100)
        mu.mem_write(PARAMS, bytes([0xA5])*0x100)
        mu.mem_write(CONTEXT+0x10, struct.pack('<I', PARAMS))
        mu.mem_write(SI, bytes(0x1000))
        # Native controls use encoded 4 for neutral. These values also keep the
        # native clarity/shading and HDR preparation paths within valid domains.
        for off in (0x79D, 0x79E, 0x79F, 0x7A0, 0x7A1, 0x7A2, 0x7A4, 0x7B3, 0x7B4):
            mu.mem_write(SI+off, b'\x04')
        for off, val in ((0x79C, tone), (0x7B5, enable), (0x7B6, size),
                         (0x7B7, strength), (0x7B3, shading), (0x7B4, clarity)):
            mu.mem_write(SI+off, bytes([val]))
        mu.mem_write(FLAGS, bytes([flags]))

    def call(self, entry: int) -> dict:
        mu = self.mu
        self.asserts.clear()
        self.interrupts.clear()
        self.visited.clear()
        for i, reg in enumerate(REGS):
            mu.reg_write(reg, 0x12340000 + i*0x111)
        expected = [mu.reg_read(r) for r in PRESERVED]
        mu.reg_write(A.UC_ARM_REG_R0, CONTEXT)
        mu.reg_write(A.UC_ARM_REG_R1, SI)
        mu.reg_write(A.UC_ARM_REG_R2, 1)
        mu.reg_write(A.UC_ARM_REG_SP, STACK)
        mu.reg_write(A.UC_ARM_REG_LR, STOP)
        mu.reg_write(A.UC_ARM_REG_CPSR, 0xA0000013)
        try:
            mu.emu_start(entry, STOP, count=100000)
        except UcError as exc:
            raise RuntimeError(f'{exc}; pc={mu.reg_read(A.UC_ARM_REG_PC):#x}, '
                               f'lr={mu.reg_read(A.UC_ARM_REG_LR):#x}') from exc
        if mu.reg_read(A.UC_ARM_REG_PC) != STOP:
            raise RuntimeError(f'Native function did not return, pc={mu.reg_read(A.UC_ARM_REG_PC):#x}')
        if self.asserts or self.interrupts:
            raise RuntimeError(f'Native assertion/interrupt: {self.asserts}, {self.interrupts}')
        if mu.reg_read(A.UC_ARM_REG_SP) != STACK:
            raise RuntimeError('Stack pointer was not restored')
        if [mu.reg_read(r) for r in PRESERVED] != expected:
            raise RuntimeError('Callee-saved registers were not restored')
        params = bytes(mu.mem_read(PARAMS, 0x100))
        context = bytes(mu.mem_read(CONTEXT, 0x100))
        si = bytes(mu.mem_read(SI, 0x1000))
        return {'p4_enable_type': params[4],
                'p6_strength': struct.unpack_from('<h', params, 6)[0],
                'p8_size': struct.unpack_from('<h', params, 8)[0],
                'plan25': context[0x25],
                'return': mu.reg_read(A.UC_ARM_REG_R0),
                'memory': (params, context, si),
                'visited': sorted(self.visited)}


def public(result: dict) -> dict:
    return {k: v for k, v in result.items() if k not in ('memory', 'visited')}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stock', type=Path, default=Path('work/filter-analysis/RTOS.bin'))
    parser.add_argument('--candidate', type=Path)
    parser.add_argument('--json', type=Path, required=True)
    args = parser.parse_args()
    stock = args.stock.read_bytes()
    stock_sha = hashlib.sha256(stock).hexdigest()
    if stock_sha != STOCK_SHA256:
        raise SystemExit(f'Stock RTOS is not the SHA-locked GR IV 1.11 reference: {stock_sha}')
    candidate = args.candidate.read_bytes() if args.candidate else None
    emulators = {'stock': Emulator(stock)}
    if candidate:
        emulators['candidate'] = Emulator(candidate)
    report = {'scope': 'Actual ARM execution of native effect parameter preparation '
                       'and processing-plan gate. No capture pixel processing or camera test.',
              'stock': str(args.stock.resolve()), 'stock_sha256': stock_sha,
              'candidate': str(args.candidate.resolve()) if args.candidate else None,
              'candidate_sha256': hashlib.sha256(candidate).hexdigest() if candidate else None,
              'addresses': {'prepare': hex(PREPARE), 'gate': hex(GATE), 'flags': hex(FLAGS)},
              'stubs': [{'address': hex(ASSERT), 'behavior': 'assertions recorded; false assertion fails'}],
              'cases': [], 'failures': []}

    def check_case(flags, tone, enable, size, strength, shading=4, clarity=4):
        key = dict(flags=flags, tone=tone, enable=enable, size=size, strength=strength,
                   shading=shading, clarity=clarity)
        case = {'input': key, 'results': {}}
        active = flags in (1, 3, 5)
        outputs = {}
        for label, emulator in emulators.items():
            try:
                emulator.configure(flags, tone, enable, size, strength, shading, clarity)
                prep = emulator.call(PREPARE)
                emulator.configure(flags, tone, enable, size, strength, shading, clarity)
                gate = emulator.call(GATE)
                outputs[label] = (prep, gate)
                case['results'][label] = {'prepare': public(prep), 'gate': public(gate)}
                expected = (enable*(2 if tone == 28 else 1), strength if strength in (0, 1, 2) else 0,
                            size if size in (0, 1, 2) else 0)
                # The candidate's documented active path uses an effective Standard
                # tone, enabled grain, fixed small grain, and ascending strength.
                if label == 'candidate' and active:
                    expected = (1, flags >> 1, 0)
                    if gate['plan25'] != 1:
                        report['failures'].append({'input': key, 'failure': 'Active effect-stage gate not enabled'})
                actual = (prep['p4_enable_type'], prep['p6_strength'], prep['p8_size'])
                if actual != expected:
                    report['failures'].append({'input': key, 'image': label,
                                               'failure': 'Downstream grain parameter mismatch',
                                               'expected': expected, 'actual': actual})
                case['results'][label]['instructions_executed'] = {
                    'prepare': len(prep['visited']), 'gate': len(gate['visited'])}
            except RuntimeError as exc:
                report['failures'].append({'input': key, 'image': label, 'failure': str(exc)})
        if 'candidate' in outputs and not active:
            original, patched = outputs['stock'], outputs['candidate']
            for kind, index in (('prepare', 0), ('gate', 1)):
                if original[index]['memory'] != patched[index]['memory']:
                    report['failures'].append({'input': key, 'failure': f'Off-path {kind} memory differs from stock'})
                if public(original[index]) != public(patched[index]):
                    report['failures'].append({'input': key, 'failure': f'Off-path {kind} outputs differ from stock'})
        report['cases'].append(case)

    # All valid size/strength combinations, native Std and two mono families,
    # every documented flag byte and invalid 255, with Grain enabled and disabled.
    for vals in itertools.product((0, 1, 2, 3, 4, 5, 255), (11, 13, 28), (0, 1), range(3), range(3)):
        check_case(*vals)
    # Native gate branches and invalid native field sanitizer checks.
    for flags, tone, shading, clarity in itertools.product((0, 1, 3, 5, 255), (11, 13, 28), (0, 4, 8), (0, 4, 8)):
        check_case(flags, tone, 1, 0, 0, shading, clarity)
    for flags, tone in itertools.product((0, 1, 3, 5, 255), (11, 13, 28)):
        check_case(flags, tone, 1, 255, 255)
    # The ROM lookup proves that strength rows ascend for a fixed size;
    # it is not a substitute for running the pixel/capture algorithm.
    lut = stock[0x53B4BF3C-BASE:0x53B4BF3C-BASE+24]
    low = [list(lut[i:i+3]) for i in (0, 3, 6)]
    high = [list(lut[i:i+3]) for i in (12, 15, 18)]
    report['native_grain_lut'] = {'address': '0x53b4bf3c', 'low_resolution': low,
                                'other_resolution': high, 'pixel_engine_executed': False}
    report['total_cases'] = len(report['cases'])
    report['passed'] = not report['failures']
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({'passed': report['passed'], 'cases': report['total_cases'],
                      'failures': len(report['failures']), 'report': str(args.json.resolve())}))
    for error in report['failures'][:12]:
        print(json.dumps(error, ensure_ascii=False))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
