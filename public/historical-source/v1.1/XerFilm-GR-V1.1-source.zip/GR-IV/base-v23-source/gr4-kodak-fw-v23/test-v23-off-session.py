# SPDX-License-Identifier: GPL-2.0-only
"""Execute the emitted ARM OFF/preview/accept/rollback paths.
Image Control device commits and physical image processing remain stubs.
"""
from pathlib import Path
import os,json,struct
HERE=Path(__file__).resolve().parent
os.chdir(HERE.parent.parent)
exec((HERE/'emu-v6.py').read_text())
from capstone import Cs,CS_ARCH_ARM,CS_MODE_ARM
BASE=HERE;P=BASE/'build-v23-a/candidate.bin.rtos';N=h.Image(str(P))
M=Cs(CS_ARCH_ARM,CS_MODE_ARM);U=0x55084dd8+4;FLAG=U+0x94b;SESSION=OBJ+0x2b4
CAT=json.loads((BASE/'v23-catalog.json').read_text());ALL=(1<<17)-1
def branch(a):
 w=N.u32(a);n=w&0xffffff;n=n-0x1000000 if n&0x800000 else n;return a+8+n*4
def calls(a):
 out=[]
 for i in M.disasm(N.rd(a,2000),a):
  if int.from_bytes(i.bytes,'little')&0x0f000000==0x0b000000:out.append(int(i.op_str[1:],16))
  if i.mnemonic=='pop' and 'pc' in i.op_str:break
 return out
TABLE=0x53d9f714+10*0x5c
enter,leave,subtitle,draw,current,setter,count=[N.u32(TABLE+k)for k in (0,8,0x10,0x18,0x20,0x28,0x30)]
begin,at,stable=calls(setter);preview=calls(stable)[-1]
rollback=calls(leave)[-1];settings=N.movw_movt(0x531d6868,0x531d6878)
switch=N.u32(settings+125*0x4c+0x24);switch_current=N.u32(settings+125*0x4c+0x2c)

def setup(look=0,on=0,level=3,bits=ALL):
 e,_=make(str(P));mu=e.mu;events=[]
 mu.mem_write(OBJ,struct.pack('<I',0x53d9f6a0))
 mu.mem_write(S,bytes([look]));mu.mem_write(FLAG,bytes([on]))
 mu.mem_write(U+0x49,(0xc80000|(level<<17)|bits).to_bytes(3,'little'))
 # Distinct native values must survive temporary Std, OFF and confirmation.
 native=bytes([14,5,3,4,6,2,5,4,3,0,0,4,3,5,4,6,2,4,0,0,0,4,3,1,2,1,0,1,2])
 mu.mem_write(U+0x79c,native)
 e.stubs[preview]=lambda:events.append((e.byte(FLAG),e.byte(S))) or 0
 return e,events,native
def native_unchanged(e,native):return bytes(e.mu.mem_read(U+0x79c,len(native)))==native
def packed(e):return int.from_bytes(e.mu.mem_read(U+0x49,3),'little')

# Every family subset has OFF first, even with zero enabled families.
for bits in (ALL,0,1,1<<16,0x15555,(1<<10)|(1<<11)|(1<<16)):
 e,events,native=setup(bits=bits)
 families=[i for i in range(17)if bits&(1<<i)]
 ck(e.call(count,())==1+len(families),'OFF adds exactly one row independently of mask')
 ck([e.call(at,(i,))for i in range(len(families)+1)]==[0xffffffff]+families,'Row0 is OFF; filtered family identities retain their order')
 ck([e.call(current,(OBJ,i))for i in range(len(families)+1)]==[1]+[0]*len(families),'OFF is the sole native current marker while disabled')

# OFF bypasses film and grain immediately, updates the exact settings switch,
# preserves all27 children and all4 grain levels, and remains idempotent.
for look in range(27):
 for level in range(4):
  e,events,native=setup(look,1,level);before=packed(e)
  e.call(setter,(OBJ,0))
  ck(e.byte(FLAG)==0 and e.byte(S)==look and packed(e)==before,'ADJ OFF changes only shared switch, retaining child, enabled list and grain preference')
  ck(e.call(switch_current,(OBJ,0))==1 and e.call(switch_current,(OBJ,1))==0,'Settings switch immediately reports OFF after ADJ OFF')
  ck(events==[(0,look)],'ADJ OFF requests one native refresh, with film gate already disabled')
  e.call(setter,(OBJ,0));ck(events==[(0,look)],'Repeated OFF does not reapply or allocate views')
  ck(native_unchanged(e,native),'OFF leaves original Image Control and its own parameters intact')
  e.mu.mem_write(SESSION,b'\0\0\0\0')

# An OFF -> film preview is immediately effective. Both activation and an
# ordinary color/mono or parent/child-family change notify the same apply path.
for look,parent in enumerate(CAT['lookFamilies']):
 e,events,native=setup(look,0,2);before=packed(e)
 e.call(setter,(OBJ,parent+1))
 ck(e.byte(FLAG)==1 and e.byte(S)==look and events==[(1,look)],'Browsing the retained film from native mode previews instantly, preserving child speed')
 ck(e.u32(SESSION)==0xa5000000|look,'First preview captures original OFF state and retained film')
 e.call(setter,(OBJ,parent+1));ck(events==[(1,look)],'Repeated layout callbacks neither resnapshot baseline nor reapply unchanged film')
 # Same flag used by the native virtual style getter: enabled always sees Std.
 ck(e.call(0x533b64e0,(OBJ,))==11,'Temporary film preview uses effective native Std instead of stacking the selected machine filter')
 e.call(rollback,(OBJ,))
 ck(e.byte(FLAG)==0 and e.byte(S)==look and e.u32(SESSION)==0,'Leaving without confirmation restores original OFF state')
 ck(events==[(1,look),(0,look)] and packed(e)==before and native_unchanged(e,native),'Cancel applies native rendering once and retains original style, mask and grain')

# The original accept entry is shared by physical OK and the native touch
# footer. Its event post is the hardware boundary, not a fake commit callback.
for origin in (0,1):
 for family,details in enumerate(CAT['families']):
  e,events,native=setup(0,origin,3);mu=e.mu
  e.call(setter,(OBJ,family+1));selected=e.byte(S)
  posts=[];e.stubs[0x5323ebf8]=lambda:0x707c3000
  e.stubs[0x5325c678]=lambda:posts.append(mu.reg_read(UC_ARM_REG_R1)) or 0
  e.call(0x531bbb10,(OBJ,))
  ck(e.u32(SESSION)==0 and posts==[0x8a],'Native final OK commits exactly before posting the original accept event')
  e.call(rollback,(OBJ,))
  ck(e.byte(FLAG)==1 and e.byte(S)==selected and native_unchanged(e,native),'Confirmed film survives controller exit and keeps original native style for future OFF')
  ck(e.call(switch_current,(OBJ,1))==1,'Confirmed ADJ film is ON in the settings menu')

# Final OFF confirmation also survives rollback/destruction and remains native.
e,events,native=setup(19,1,3);e.call(setter,(OBJ,0))
e.stubs[0x5323ebf8]=lambda:0x707c3000;e.stubs[0x5325c678]=lambda:0
e.call(0x531bbb3c,(OBJ,));e.call(rollback,(OBJ,))
ck(e.byte(FLAG)==0 and e.byte(S)==19 and packed(e)==0xce0000|ALL,'Touch OK accepts OFF without erasing PORTRA800 or strong-grain preference')

# Settings and ADJ share state in both directions.
e,events,native=setup(12,1,1)
e.call(switch,(OBJ,0))
ck(e.call(current,(OBJ,0))==1,'Settings OFF is immediately reflected by the ADJ OFF row')
e.call(switch,(OBJ,1))
ck(e.call(current,(OBJ,11))==1 and e.byte(S)==12,'Settings ON restores retained T-MAX3200 and its shifted ADJ family row')

# Real native getter/setter resume their original functions when OFF; final
# processing resources and neutral controls are independently audited below.
e,events,native=setup(0,0)
e.stubs[0x5372b620]=lambda:0x707a1000;e.mu.mem_write(0x707a1004,struct.pack('<I',0x707a2000))
style=[14];setter_values=[]
e.stubs[0x53757ab0]=lambda:style[0]
e.stubs[0x533b665c]=lambda:0
def native_set():
 setter_values.append(e.mu.reg_read(UC_ARM_REG_R3));style[0]=setter_values[-1];return 0
e.stubs[0x533b62d0]=native_set
ck(e.call(0x533b64e0,(OBJ,))==14,'OFF native getter returns the original Positive Film style')
e.call(0x533b70cc,(OBJ,13));ck(style[0]==13 and setter_values==[13],'OFF restores actual native Image Control selection path')
e.call(setter,(OBJ,1));e.call(0x533b70cc,(OBJ,14))
ck(e.call(0x533b64e0,(OBJ,))==11 and setter_values==[13],'During film preview native setter is ignored and effective style remains Std')
e.call(rollback,(OBJ,))
ck(e.call(0x533b64e0,(OBJ,))==13,'Cancel returns to the exact native style selected before film browsing')

# Traverse complete native application of each still bank on OFF and ON.
for bank,field,cache in [(0,0x153,0xc3f),(1,0x154,0xc40),(2,0x155,0xc41),(3,0x156,0xc42)]:
 e,_,native=setup(12,1,3);mu=e.mu;e.stubs.pop(preview,None)
 model=0x70790000;commits=[];e.stubs[0x5323f018]=lambda:model;e.stubs[0x5329789c]=lambda:bank
 for i in range(4):mu.mem_write(model+0x153+i,bytes([11+i]));mu.mem_write(model+0xc3f+i,bytes([11+i]))
 e.stubs[0x532a90fc]=lambda:commits.append((e.byte(FLAG),e.byte(S))) or 0
 e.call(setter,(OBJ,0));e.call(setter,(OBJ,11))
 ck(commits==[(0,12),(1,12)],f'Still bank{bank}: OFF and same-child ON reach original native apply commit without shutter events')

# Reject invalid/stale rows without changing state, and retain OFF-only list.
for row in (18,20,65535,0xffffffff):
 e,events,native=setup(7,1,2)
 e.call(setter,(OBJ,row))
 ck(e.byte(FLAG)==1 and e.byte(S)==7 and not events,'Stale compact rows cannot accidentally turn simulation OFF')

# Native function-switch hook must restore before the next function scans its
# current selection; switching between slots for the same film function keeps
# the outstanding preview transaction alive.
for target in (0,1):
 e,events,native=setup(7,0,3);mu=e.mu;e.call(setter,(OBJ,11))
 e.stubs[0x531bd580]=lambda:10 if mu.reg_read(UC_ARM_REG_R1)==0 else 15
 stop=mu.hook_add(UC_HOOK_CODE,lambda uc,pc,size,ud:uc.emu_stop() if pc==0x531bf628 else None)
 mu.reg_write(UC_ARM_REG_R0,OBJ);mu.reg_write(UC_ARM_REG_R1,target)
 mu.reg_write(UC_ARM_REG_SP,0x600f0000);mu.reg_write(UC_ARM_REG_LR,0x100)
 mu.emu_start(0x531bf624,0x100,count=50000);mu.hook_del(stop)
 ck(mu.reg_read(UC_ARM_REG_PC)==0x531bf628,'Scoped switch hook returns to the exact original continuation')
 ck((e.byte(FLAG),e.byte(S),bool(e.u32(SESSION)))==((1,10,True)if target==0 else(0,7,False)),
    'Switching to another ADJ item rolls back before native UI; same function retains pending preview')
 ck(native_unchanged(e,native),'Switching ADJ functions never rewrites native image-control settings')

# Actual cached child key path: child OK stays on the mother menu, while a
# second parent OK commits through the original event poster.
for confirm_parent in (False,True):
 e,events,native=setup(7,0,2);mu=e.mu
 d=0x707f0000;mu.mem_write(d,struct.pack('<6I',13,620,60,100,360,0))
 main=e.call(0x53589ee4,(d,));types=0x707e0000;mu.mem_write(types,bytes([25])*18)
 e.call(0x5357094c,(main,types,18,58));mu.mem_write(OBJ+0x1f8,struct.pack('<I',main))
 e.call(0x53571788,(main,11));e.call(setter,(OBJ,11))
 e.stubs[0x531bd580]=lambda:10;e.stubs[0x531bf38c]=lambda:0
 e.stubs[render_fn(N)]=lambda:0
 posts=[];e.stubs[0x5323ebf8]=lambda:0x707c3000
 e.stubs[0x5325c678]=lambda:posts.append(mu.reg_read(UC_ARM_REG_R1)) or 0
 def press(k):
  mu.mem_write(0x707d0000,struct.pack('<H',k));return e.call(0x531bf834,(OBJ,0x707d0000))
 press(0xd4);press(0xd7);press(0xe0)
 ck(e.byte(S)==11 and e.byte(OBJ+0x2a0)==0 and e.u32(SESSION)==0 and not posts,
    'T-MAX Left/Down/child OK accepts400 immediately and returns to mother without closing ADJ')
 if confirm_parent:
  press(0xe0)
  ck(posts==[0x8a] and e.u32(SESSION)==0,'Parent OK passes the actual key hook and commits the pending T-MAX400 selection')
 e.call(leave,(OBJ,))
 ck((e.byte(FLAG),e.byte(S))==(1,11),
    'Leaving after child OK retains selected speed without another parent OK')

# MENU / camera-controller shutdown reaches the real destructor. With an
# unfinished child preview it first cancels the child, then restores the whole
# native-mode baseline, before any cached native views are released.
e,events,native=setup(7,0,3);mu=e.mu;e.call(setter,(OBJ,11))
mu.mem_write(OBJ+0x2a0,b'\1');mu.mem_write(OBJ+0x2a4,b'\x0a');mu.mem_write(S,b'\x0c')
stop=mu.hook_add(UC_HOOK_CODE,lambda uc,pc,size,ud:uc.emu_stop() if pc==0x531ba1c4 else None)
mu.reg_write(UC_ARM_REG_R0,OBJ);mu.reg_write(UC_ARM_REG_SP,0x600f0000);mu.reg_write(UC_ARM_REG_LR,0x100)
mu.emu_start(0x531ba1c0,0x100,count=100000);mu.hook_del(stop)
ck(mu.reg_read(UC_ARM_REG_PC)==0x531ba1c4 and e.byte(FLAG)==0 and e.byte(S)==7 and e.u32(SESSION)==0,
   'Actual ADJ destructor restores original native mode after an unconfirmed child preview')
ck(native_unchanged(e,native),'Native controller shutdown retains all original image-control parameters')

(BASE/'v23-off-session-checks.json').write_text(json.dumps({'passed':True,'count':len(checks),'checks':checks,'hardwareTested':False,'functions':{'begin':begin,'rollback':rollback,'set':setter,'preview':preview},'scope':'Actual emitted ARM ADJ OFF/filter adapters, shared switch reads, preview transactions, original native OK event post, native style getter/setter and still-bank apply. Device commits remain stubs; physical preview timing and camera input require testing.'},ensure_ascii=False,indent=2))
print('PASS',len(checks),'OFF, preview, confirmation and native restore checks')
