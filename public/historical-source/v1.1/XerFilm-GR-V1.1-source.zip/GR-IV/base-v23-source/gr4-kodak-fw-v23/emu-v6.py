from pathlib import Path
import sys,struct,json
sys.path.insert(0,str(Path('outputs/GR4-Menu-Experiment/tools').resolve()))
import upstream_menu_emu as h
exec((Path(__file__).resolve().parent/'runtime-memory.py').read_text())
protect_h(h)
from capstone import Cs,CS_ARCH_ARM,CS_MODE_ARM
from unicorn.arm_const import *
from unicorn import UC_HOOK_CODE
BASE=Path('work/gr4-tmax-fw-v7');S=0x55084dd8+4+0x90f;OBJ=0x70000000
checks=[]
def ck(ok,msg):
 checks.append({'check':msg,'passed':bool(ok)})
 if not ok:raise AssertionError(msg)
def render_fn(img):
 c=Cs(CS_ARCH_ARM,CS_MODE_ARM);out=[]
 sub=img.u32(0x53d9f714+10*0x5c+0x10)
 for i in c.disasm(img.rd(sub,512),sub):
  if i.mnemonic=='bl':out.append(int(i.op_str[1:],16))
  if i.mnemonic=='pop' and 'pc' in i.op_str:break
 return out[-1]
def make(path,language=19):
 img=h.Image(path);e=h.Emu(img);mu=e.mu;draws=[];measured=[]
 # The assert API receives the condition in r0. Passing assertions also call it.
 e.stubs[0x538ed930]=lambda:e.calls.append(('ASSERT',hex(mu.reg_read(UC_ARM_REG_LR)))) or 0 if not mu.reg_read(UC_ARM_REG_R0) else 0
 def alloc():
  n=mu.reg_read(UC_ARM_REG_R0);p=e.heap[0];e.heap[0]+=(n+15)&~15;return p
 for a in [0x538e09b0,0x538dd620,0x538e0a24]:e.stubs[a]=alloc
 for a in [0x538e09ec,0x538e0a60]:e.stubs[a]=lambda:0
 # Execute the real 0x53572cec language accessor, providing its boot singleton.
 e.stubs[0x5323ea84]=lambda:0x707a0000
 e.stubs[0x5324054c]=lambda:0x707a0100
 mu.mem_write(0x707a0100,struct.pack('<I',0x707a0200))
 mu.mem_write(0x707a0208,struct.pack('<I',0x707a0300))
 e.stubs[0x707a0300]=lambda:language
 e.stubs[0x5323bbb8]=lambda:0x707b0000
 e.stubs[0x5323bd68]=lambda:0x707b0100
 e.stubs[0x5323bd30]=lambda:0x707b0200
 def text(packet):
  n=mu.mem_read(packet+0x2e,1)[0];ptr=e.u32(packet+0x30)
  return bytes(mu.mem_read(ptr,max(n-1,0)*2)).decode('utf-16-le')
 def measure():
  out=mu.reg_read(UC_ARM_REG_R0);packet=mu.reg_read(UC_ARM_REG_R2)
  s=text(packet);measured.append(s)
  mu.mem_write(out,struct.pack('<II',len(s)*20,40));return out
 e.stubs[0x5323c8f0]=measure
 def queue():
  p=mu.reg_read(UC_ARM_REG_R1)
  draws.append({'text':text(p),'rect':list(struct.unpack('<4i',mu.mem_read(p+4,16))),
   'clip':list(struct.unpack('<4i',mu.mem_read(p+0x14,16))),
   'foreground':e.byte(p+0x25),'backgroundEnabled':e.byte(p+0x28),'background':e.byte(p+0x29)})
  return 0
 e.stubs[0x5323cc38]=queue
 e.stubs[0x5323c588]=lambda:0

 return e,draws
