# SPDX-License-Identifier: GPL-2.0-only
"""Exercise packed preferences and the compiled GRMod-derived ARM timestamp.
Runs original menu callbacks, actual native grain preparation and JPEG-hook
wrapper; synthetic buffers/clock/cache only. No physical camera is attached.
"""
from pathlib import Path
import os,struct,json,itertools,hashlib,importlib.util
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent.parent
os.chdir(ROOT);exec((HERE/'emu-v6.py').read_text(),globals());BASE=HERE
from unicorn import UC_HOOK_CODE
from unicorn import arm_const as A
M=Cs(CS_ARCH_ARM,CS_MODE_ARM);P=BASE/'build-v23-a/candidate.bin.rtos'
e,_=make(str(P));mu=e.mu;img=h.Image(str(P));checks=[];U=0x55084dd8+4

def ck(ok,s):
 if not ok:raise AssertionError(s)
 checks.append(s)
def branch(at):
 w=img.u32(at);n=w&0xffffff;n=n-0x1000000 if n&0x800000 else n;return at+8+n*4
def calls(at):
 out=[]
 for i in M.disasm(img.rd(at,1800),at):
  if int.from_bytes(i.bytes,'little')&0x0f000000==0x0b000000:out.append(int(i.op_str[1:],16))
  if i.mnemonic=='pop' and 'pc' in i.op_str:break
 return out
T=img.movw_movt(0x531d6868,0x531d6878)
count,draw,setter,current=[img.u32(T+128*0x4c+o)for o in(0xc,0x14,0x24,0x2c)]
gset=img.u32(T+127*0x4c+0x24)
getter=calls(current)[0]
mask_count=img.u32(0x53d9f714+10*0x5c+0x30);mask=calls(mask_count)[0]
key=branch(0x531dacac);family_toggle=calls(calls(key)[1])[0]
preview=calls(gset)[-1];e.stubs[preview]=lambda:0
ck(e.call(count,())==6,'Timestamp has exactly6 native choices')
e.call(0x531d5e8c,(OBJ,0x020001a4));ck(e.byte(OBJ+0x1a4)==128,'Timestamp controller maps to its own native record128')
ck(h.factory_class(img,0x020001a4)==h.factory_class(img,0x02000094),'New timestamp uses the same native list-controller class as Horizon Correction')
# Old versions retain their mask and grain. Timestamp initially defaultsOFF.
for oldtag,level,bits in itertools.product((0xc80000,0xb40000),range(4),(1,0x15555,0x1ffff)):
 packed=oldtag|(level<<17 if oldtag==0xc80000 else 0)|bits
 mu.mem_write(U+0x49,packed.to_bytes(3,'little'));old=bytes(mu.mem_read(U+0x49,3))
 ck(e.call(getter,())==0 and bytes(mu.mem_read(U+0x49,3))==old,'Reading old preferences defaults timestampOFF without any mutation')
 for index,mode in enumerate([0,1,2,5,3,4]):
  mu.mem_write(U+0x49,old);mu.mem_write(U+0x48,b'\x76');mu.mem_write(U+0x4c,b'\x11\x22\x33\x44');mu.mem_write(U+0x94b,b'\0')
  e.call(setter,(OBJ,index));v=int.from_bytes(mu.mem_read(U+0x49,3),'little')
  ck((v&0x1ffff)==bits and (v>>19)&7==mode and v>>22==1 and (v>>17)&3==(level if oldtag==0xc80000 else 0),'Configuring timestamp migrates only its tag/mode and preserves old family/grain preferences')
  ck(e.byte(U+0x48)==0x76 and bytes(mu.mem_read(U+0x4c,4))==b'\x11\x22\x33\x44'and e.byte(U+0x94b)==0,'Timestamp does not activate Film or write adjacent native settings')
  ck([e.call(current,(OBJ,i))for i in range(6)]==[int(i==index)for i in range(6)],'Exactly one timestamp choice is current')
  ck(e.call(mask,())==bits and int.from_bytes(mu.mem_read(U+0x49,3),'little')==v,'Mask reader retains timestamp mode and grain')
  for grain in range(4):
   e.call(gset,(OBJ,grain));v=int.from_bytes(mu.mem_read(U+0x49,3),'little')
   ck(e.call(getter,())==mode and(v&0x1ffff)==bits and(v>>17)&3==grain,f'Changing grain leaves timestamp and enabled mask intact: tag{oldtag:x}, level{level}, bits{bits:x}, mode{mode}, grain{grain}, packed{v:x}, stamp{e.call(getter,())}, gset{gset:x}, preview{preview:x}')
  before=int.from_bytes(mu.mem_read(U+0x49,3),'little');e.call(family_toggle,(16,));after=int.from_bytes(mu.mem_read(U+0x49,3),'little')
  ck(after==before^(1<<16),'Toggling a film family changes exactly one mask bit, retaining stamp and grain')
for value in (6,7,255,0xffffffff):
 before=bytes(mu.mem_read(U,0x1000));e.call(setter,(OBJ,value));ck(bytes(mu.mem_read(U,0x1000))==before,'Invalid timestamp choice is rejected without writes')
start=len(e.calls)
for i in range(6):e.call(draw,(OBJ,0x70008000,i))
ck([x[3]for x in e.calls[start:]if x[0]=='list-item']==[2,884,885,888,886,887],'Native timestamp labels are OFF, YMDtime, DMYtime, Date, Time')
# Extended packed format is also consumed correctly by actual native grain code.
spec=importlib.util.spec_from_file_location('grain_stamp',ROOT/'work/gr4-fuji-fw-v2/audit-grain/check_grain.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
sidecar={};exec((BASE/'sidecar-fixture.py').read_text(),sidecar);sidecar['install'](g)
grain=g.Emulator(P.read_bytes())
for mode,level,sv in itertools.product(range(6),range(4),(5.,7+1/3,8+1/3)):
 grain.configure(0,14,1,2,2);m=grain.mu;m.mem_write(g.SI+0x94b,b'\1');m.mem_write(g.SI+0x49,(0x400000|mode<<19|level<<17|0x1ffff).to_bytes(3,'little'));m.mem_write(g.SI+0xba0,struct.pack('<f',sv))
 p=grain.call(g.PREPARE);q=grain.call(g.GATE);size=0 if sv<=7 else 1 if sv<=8 else 2
 ck((p['p4_enable_type'],p['p6_strength'],p['p8_size'],q['plan25'])==(int(level>0),max(0,level-1),size if level else 0,int(level>0)),'New timestamp preferences retain independent ISO-adaptive grain at every level/size')
# Actual installed compiled C payload and its first-layout glyph stream.
stub=branch(0x537034b4);code=calls(stub)[0]
raw=(BASE/'stamp-research/film-stamp.bin').read_bytes();ck(img.rd(code,len(raw))==raw,'Installed JPEG module exactly matches independently compiled C payload')
layout=code+json.loads((BASE/'stamp-research/module-proof.json').read_text())['symbols']['layout']
e,_=make(str(P));mu=e.mu;glyph_runs=[];cache_ops=[];clock_calls=[]
K=0x70004000;CFG=0x70006000;SHOT=0x70008000;D=0x7000a000
PLATFORM=0x70001000;mu.mem_write(PLATFORM+4,struct.pack('<I',0x70002000))
CLOCK=(2026,10,16,17,34,53)
e.stubs[0x538f0448]=lambda:0x553a09c4
e.stubs[0x538f04d8]=lambda:cache_ops.append(('read',mu.reg_read(A.UC_ARM_REG_R1),mu.reg_read(A.UC_ARM_REG_R2)))or 0
e.stubs[0x538f04c4]=lambda:cache_ops.append(('clean',mu.reg_read(A.UC_ARM_REG_R1),mu.reg_read(A.UC_ARM_REG_R2)))or 0
e.stubs[0x538f21a0]=lambda:PLATFORM
def clock():
 clock_calls.append(1);mu.mem_write(mu.reg_read(A.UC_ARM_REG_R1),struct.pack('<HBBBBB',*CLOCK));return 0
e.stubs[0x538ea9b0]=clock
side_lookup=calls(branch(0x537150fc))[0]
mu.mem_write(K,struct.pack('<6I',0x538f0448,0x538f04d8,0x538f04c4,0x538f21a0,0x538ea9b0,side_lookup))
def capture(uc,at,size,ud):
 if at==layout:glyph_runs.append(bytes(uc.mem_read(uc.reg_read(A.UC_ARM_REG_R0),uc.reg_read(A.UC_ARM_REG_R1))))
mu.hook_add(UC_HOOK_CODE,capture,begin=layout,end=layout)
# Three buffers and a duplicate-main descriptor in a native-sized four-slot job.
W,H=640,426;STRIDE=672;Y=0x70800000;C=0x70900000
PY0,PC=0x70a00000,0x70b00000;TY,TC=0x70c00000,0x70c10000
planes=[(Y,C,W,H,STRIDE),(PY0,PC,360,240,384),(TY,TC,160,120,160)]
def reset(flag=1,mode=1,mono=False,packed=None,duplicate=True,look=0):
 glyph_runs.clear();cache_ops.clear();clock_calls.clear()
 for ya,ca,w,ht,stride in planes:
  mu.mem_write(ya,bytes([70])*(stride*ht));mu.mem_write(ca,(bytes([128,128])if mono else bytes([120,140]))*(stride*ht//2))
  mu.mem_write(ya-64,b'\x5a'*64);mu.mem_write(ya+stride*ht,b'\x5a'*64);mu.mem_write(ca-64,b'\xa5'*64);mu.mem_write(ca+stride*ht,b'\xa5'*64)
 for i,(ya,ca,w,ht,stride)in enumerate(planes):mu.mem_write(D+i*0x20,struct.pack('<B3xIII HHHH HH 4x',1,ya,ca,0,w,ht,stride,ht,0,0))
 mu.mem_write(D+0x60,bytes(mu.mem_read(D,0x20)))
 mu.mem_write(CFG,b'\0'*0x60);mu.mem_write(CFG+0x34,struct.pack('<I',SHOT));mu.mem_write(CFG+0x3c,struct.pack('<4I',D,D+0x20,D+0x40,D+0x60 if duplicate else 0))
 mu.mem_write(SHOT,b'\0'*0x1000);mu.mem_write(SHOT+0x94b,bytes([flag]));mu.mem_write(SHOT+0x49,((0x400000|mode<<19|0x7ffff)if packed is None else packed).to_bytes(3,'little'))
 mu.mem_write(SHOT+0x90f,bytes([look]))
 sidecar['register'](mu,SHOT)
 # Disagree deliberately with the captured job.
 mu.mem_write(U+0x94b,bytes([1-flag if flag in(0,1)else 1]));mu.mem_write(U+0x49,(0x400000|((mode+1)%6)<<19|0x1ffff).to_bytes(3,'little'))
def render():e.call(code,(K,CFG),limit=100_000_000)
def snap():return [bytes(mu.mem_read(ya,stride*ht))+bytes(mu.mem_read(ca,stride*ht))for ya,ca,w,ht,stride in planes]
def chars(g):return ''.join(str(x)if x<10 else{16:"'",17:' ',18:'.',19:':'}.get(x,'?')for x in g)
# Complete pass-through when captured Film OFF/invalid, modeOFF or old settings.
for flag,mode in itertools.product((0,1,2,3,255),range(6)):
 if flag==1 and mode:continue
 reset(flag,mode);before=snap();render();ck(snap()==before and not clock_calls and not cache_ops,'Inactive timestamp leaves every image byte unchanged and calls no clock/cache service')
for high in (0,0x3f,0x70,0x7f,0x80,0xb4,0xc8,0xce,0xff):
 reset(packed=high<<16|0x1ffff);before=snap();render();ck(snap()==before and not clock_calls,'Legacy/invalid packed setting cannot trigger a timestamp')
# Validate real glyph streams and image writes for years on both century edges.
render_cases=[]
for year,mode,mono in itertools.product((1999,2000,2026),range(1,6),(False,True)):
 CLOCK=(year,10,16,17,34,53);reset(mode=mode,mono=mono);before=snap();shot_before=bytes(mu.mem_read(SHOT,0x1000));render()
 yy=f'{year%100:02}';expected={1:f'{yy}.10.16 17:34',2:f'16.10 17:34 {yy}',3:f'{yy}.10.16',4:'17:34',5:f'{yy}.10.16 17:34'}[mode]
 ck(glyph_runs and ([chars(x)for x in glyph_runs]==[expected]*2 if mode!=5 else [chars(x)for x in glyph_runs]==[f'{yy}.10.16']*2+['17:34']*2),'Actual compiled format/year: '+expected+' got '+str([chars(x)for x in glyph_runs])+' pref '+hex(e.call(side_lookup,(SHOT,))))
 ck(len(clock_calls)==1,'One clock read supplies main JPEG, preview and thumbnail consistently')
 ck(bytes(mu.mem_read(SHOT,0x1000))==shot_before,'JPEG rendering never rewrites captured settings')
 after=snap();boxes=[]
 for j,(ya,ca,w,ht,stride)in enumerate(planes):
  data=bytes(mu.mem_read(ya,stride*ht));chroma=bytes(mu.mem_read(ca,stride*ht));xs=[];ys=[]
  for y in range(ht):
   for x in range(w):
    if data[y*stride+x]!=70:xs.append(x);ys.append(y)
  if j>0:
   ck(after[j]==before[j],f'Format{mode} leaves shared RAW/DNG preview buffer{j} completely unchanged');continue
  ck(bool(xs),f'Format{mode} reaches JPEG main picture{j}')
  box=[min(xs),min(ys),max(xs),max(ys)];boxes.append(box)
  ck(box[0]>=0 and box[2]<w and box[1]>ht//2 and box[3]<ht,f'Format{mode} stays inside bottom-right photo area of buffer{j}')
  ck(all(data[y*stride+w:(y+1)*stride]==bytes([70])*(stride-w)for y in range(ht)),'JPEG row padding is never drawn into')
  if mono:ck(chroma==bytes([128])*(stride*ht),'Monochrome film retains neutral chroma, including timestamp')
  else:ck(min(chroma)<120 and max(chroma)>140,'Colour film receives GRMod-style orange imprint')
  ck(bytes(mu.mem_read(ya-64,64))==b'\x5a'*64 and bytes(mu.mem_read(ya+stride*ht,64))==b'\x5a'*64 and bytes(mu.mem_read(ca-64,64))==b'\xa5'*64 and bytes(mu.mem_read(ca+stride*ht,64))==b'\xa5'*64,'All plane guard bytes remain intact')
 ck(all(addr%64==0 and size%64==0 and size>0 for kind,addr,size in cache_ops),'Cache operations retain native64-byte alignment')
 ck(len(glyph_runs)==(4 if mode==5 else 2),'Only JPEG main picture is stamped; shared preview/thumbnail descriptors are ignored')
 render_cases.append({'year':year,'mode':mode,'mono':mono,'printed':expected,'boxes':boxes})
# User photo has a monochrome scene but an orange date. Fitted black-and-white
# looks can leave a small chroma residual; the old all-samples test then fails.
# Deliberately give the buffer residual colour at EVERY sample and verify the
# captured look (not a subsequent current-menu change) forces neutral ink.
for look in range(27):
 for mode in (1,5):
  CLOCK=(2026,10,17,1,23,45);reset(mode=mode,mono=False,look=look)
  mu.mem_write(U+0x90f,bytes([(look+13)%27]));render()
  data=bytes(mu.mem_read(Y,STRIDE*H));chroma=bytes(mu.mem_read(C,STRIDE*H))
  changed=[(y,x) for y in range(H) for x in range(W) if data[y*STRIDE+x]!=70]
  ck(bool(changed),'Captured look timestamp renders despite deliberately non-neutral scene samples')
  full=[(y,x)for y,x in changed if data[y*STRIDE+x]==150]
  ck(bool(full),'Timestamp includes opaque glyph interiors for an exact ink-colour check')
  if look in (7,10,11,12,26):
   ck(all(chroma[y*STRIDE+(x&~1):y*STRIDE+(x&~1)+2]==bytes((128,128)) for y,x in full),'ACROS/T-MAX/DOUBLE-X captured identity forces neutral ink despite residual colour')
   ck(min(chroma[::2])>=120 and max(chroma[::2])<=128 and min(chroma[1::2])>=128 and max(chroma[1::2])<=140,'Monochrome date adds no orange chroma, including antialiased edges')
  else:ck(min(chroma)<120 and max(chroma)>140,'Colour look retains orange ink despite an unrelated live-menu selection')
  ck(bytes(mu.mem_read(PY0,384*240))==bytes([70])*(384*240) and bytes(mu.mem_read(TY,160*120))==bytes([70])*(160*120),'Forced monochrome affects main JPG only; shared previews stay unchanged')
# Missing/invalid pointers, pictures, clock and oversize modes return untouched.
CLOCK=(2026,13,16,17,34,53);reset();before=snap();render();ck(snap()==before,'Invalid clock cannot print a date')
CLOCK=(2026,10,16,24,0,0);reset();before=snap();render();ck(snap()==before,'Invalid time cannot print a time')
CLOCK=(2000,1,1,0,0,0);reset();render();ck(glyph_runs and chars(glyph_runs[0])=='00.01.01 00:00','Year2000 and midnight retain leading zeroes')
for ptr in(0,0x10000,0xc0000000,SHOT+1):
 reset();mu.mem_write(CFG+0x34,struct.pack('<I',ptr));before=snap();render();ck(snap()==before,'Invalid shot pointer is rejected before dereference')
# RAW+JPEG small-size buffers may live above0xA0000000 on this model.
oldplanes=planes
for base in (0xb1000000,0xc0000000):
 mu.mem_map(base,0x200000);planes=[(base+0x1000,base+0x100000,W,H,STRIDE)]+oldplanes[1:]
 reset();before=snap();render()
 if base==0xb1000000:ck(snap()[0]!=before[0] and bool(glyph_runs),'RAW+JPEG high-DDR main buffer receives the timestamp')
 else:ck(snap()==before and not glyph_runs,'Out-of-DDR main picture is rejected; no partial secondary imprint')
planes=oldplanes
# The installed prologue wrapper preserves the original entry ABI and native
# mov ip,sp continuation. C only uses soft-float integer instructions.
CLOCK=(2026,10,16,17,34,53)
for flag,mode in itertools.product((0,1),range(6)):
 reset(flag,mode);container=0x7000c000;mu.mem_write(container+8,struct.pack('<I',CFG))
 regs=[getattr(A,f'UC_ARM_REG_R{i}')for i in range(13)]+[A.UC_ARM_REG_SP,A.UC_ARM_REG_LR,A.UC_ARM_REG_CPSR]
 for i,r in enumerate(regs[:13]):mu.reg_write(r,0x70010000+0x100*i)
 mu.reg_write(A.UC_ARM_REG_R1,container);mu.reg_write(A.UC_ARM_REG_SP,0x600f0000);mu.reg_write(A.UC_ARM_REG_LR,0x100);mu.reg_write(A.UC_ARM_REG_CPSR,0xa8000013)
 before=[mu.reg_read(r)for r in regs];mu.emu_start(0x537034b4,0x537034b8,count=100_000_000);after=[mu.reg_read(r)for r in regs];before[12]=before[13]
 ck(mu.reg_read(A.UC_ARM_REG_PC)==0x537034b8 and before==after,'Installed JPEG wrapper preserves all original registers/flags and resumes exact native prologue')
report={'passed':True,'count':len(checks),'checks':checks,'renderCases':render_cases,'firmwareRtosSha256':hashlib.sha256(P.read_bytes()).hexdigest(),'hardwareTested':False,'scope':'Original native menu dispatch and packed settings; actual ARM native grain preparation; compiled ARM JPEG stamp C, pixel bounds/chroma/cache/glyph checks on synthetic buffers, installed wrapper ABI. Clock/cache/display hardware are stubbed; JPEG encoder/DSP and camera not executed.'}
(BASE/'v23-stamp-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('PASS',len(checks),'timestamp settings, actual ARM imprint, two-digit years, snapshot scope and JPEG wrapper checks')
