// SPDX-License-Identifier: GPL-2.0-only
// ADJ preview transaction. This word belongs to the extended ADJ controller;
// no persistent user-settings bytes or native Image Control values are copied.
import {Patch,expectWord} from './build';
import {assembleWords} from './arm';
import {installFilmPreview} from './film-preview';
import {FILM_LOOK_COUNT} from './film-catalog';
export const FILM_SESSION_WORD=0x2b4;
const SELECT=0x55084dd8+4+0x90f,FLAG=0x55084dd8+4+0x94b;
const addr=(r:string,a:number)=>`movw ${r},#${a&65535};movt ${r},#${a>>>16};`;
const branch=(a:number,b:number)=>{const d=(b-a-8)>>2;if(d< -0x800000||d>0x7fffff)throw Error('film session branch range');return(0xea000000|(d&0xffffff))>>>0;};
const installed=new WeakMap<Patch,ReturnType<typeof create>>();
function create(p:Patch){
 const fn=(s:string)=>p.append(a=>assembleWords(s,a),16),preview=installFilmPreview(p);
 // Repeated entry/layout callbacks may not replace an outstanding baseline.
 const begin=fn(`ldr r2,[r0,#${FILM_SESSION_WORD}];mov r3,r2,lsr #24;cmp r3,#0xa5;bxeq lr;
  ${addr('r2',SELECT)}ldrb r1,[r2];cmp r1,#${FILM_LOOK_COUNT};movhs r1,#0;
  ${addr('r2',FLAG)}ldrb r3,[r2];cmp r3,#1;movne r3,#0;orr r1,r1,r3,lsl #8;orr r1,r1,#0xa5000000;str r1,[r0,#${FILM_SESSION_WORD}];bx lr`);
 const rollback=fn(`push {r4,r5,r6,lr};mov r4,r0;ldr r5,[r4,#${FILM_SESSION_WORD}];mov r1,r5,lsr #24;cmp r1,#0xa5;bne done;
  mov r1,#0;str r1,[r4,#${FILM_SESSION_WORD}];mov r6,#0;
  ${addr('r2',SELECT)}ldrb r1,[r2];uxtb r3,r5;cmp r1,r3;movne r6,#1;strb r3,[r2];
  ${addr('r2',FLAG)}ldrb r1,[r2];mov r3,r5,lsr #8;and r3,r3,#1;cmp r1,r3;movne r6,#1;strb r3,[r2];
  cmp r6,#0;blne #${preview};done:mov r0,r4;pop {r4,r5,r6,pc}`);
 // Parent/touch OK and child OK commit the current look. Child OK calls this
 // after native parent refresh, which may start another preview transaction.
 // It does not post the native close event: the mother menu stays open.
 const commit=fn(`ldr r2,[r0,#${FILM_SESSION_WORD}];mov r3,r2,lsr #24;cmp r3,#0xa5;bxne lr;
  mov r2,#0;str r2,[r0,#${FILM_SESSION_WORD}];strb r2,[r0,#0x2a0];bx lr`);
 // Native keyboard OK and the original touch footer share this accept entry.
 // Check the concrete controller before accessing any extension fields.
 expectWord(p,0x531bbb10,0xe1a0c00d);
 const accept=fn(`push {r0,r1,r2,r3,r4,r5,ip,lr};mrs r5,cpsr;ldr r2,[r0];${addr('r3',0x53d9f6a0)}cmp r2,r3;bleq #${commit};
  msr cpsr_f,r5;pop {r0,r1,r2,r3,r4,r5,ip,lr};mov ip,sp;b #0x531bbb14`);
 p.setWord(0x531bbb10,branch(0x531bbb10,accept),'film session: commit only through scoped native ADJ OK');
 return {begin,rollback,commit,accept};
}
export function installFilmSession(p:Patch){const prior=installed.get(p);if(prior)return prior;const value=create(p);installed.set(p,value);return value;}
