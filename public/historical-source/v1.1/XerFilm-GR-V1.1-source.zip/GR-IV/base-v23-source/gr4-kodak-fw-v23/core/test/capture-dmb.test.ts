// SPDX-License-Identifier: GPL-2.0-only
import {expect,it} from 'vitest';
import {readFileSync} from 'node:fs';
import {assemble} from '../src/fw/aspect/arm';
const ref=JSON.parse(readFileSync(new URL('./fw-helpers/capture-dmb.json',import.meta.url),'utf8'));
it('matches independently compiled ARMv7 DMB ISH encoding',()=>{
 expect(Buffer.from(assemble(ref.source,0x54000000)).toString('hex')).toBe(ref.hex);
});
it('rejects unsupported barrier scopes and conditional forms',()=>{
 for(const s of ['dmb','dmb sy','dmbeq ish','dmb ish,r0'])expect(()=>assemble(s,0x54000000)).toThrow();
});
