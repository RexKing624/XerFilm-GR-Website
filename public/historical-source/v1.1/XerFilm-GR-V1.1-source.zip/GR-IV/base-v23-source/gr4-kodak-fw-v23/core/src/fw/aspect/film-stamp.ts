// SPDX-License-Identifier: GPL-2.0-only
// Film-only JPEG timestamp, adapted from GR Mod's seven-segment date imprint.
// Its mode lives in the Film preferences, never the historical GR Mod switch.
import {Patch,expectWord,u32le} from './build';
import {assembleWords} from './arm';
import {installFilmCapture} from './film-capture';
import {FILM_STAMP_CODE,FILM_STAMP_CODE_LENGTH} from './film-stamp-code';
export const FILM_STAMP_JPEG_EXECUTE=0x537034b4;
export function installFilmStamp(p:Patch):void{
 const site=FILM_STAMP_JPEG_EXECUTE,capture=installFilmCapture(p);
 expectWord(p,site,0xe1a0c00d);expectWord(p,site+4,0xe92ddff0);expectWord(p,site+0x18,0xe5914008);
 // Both JPEG configuration builders: pictures at +3c, captured ShotInfo at +34.
 expectWord(p,0x5370f7d0,0xe5922688);expectWord(p,0x5370f7dc,0xe5842b94);expectWord(p,0x5370f7ec,0xe5841b9c);
 expectWord(p,0x5370f420,0xe5911688);expectWord(p,0x5370f430,0xe5841a4c);expectWord(p,0x5370f448,0xe584ca54);
 for(const [a,w] of [[0x538f0448,0xe30009c4],[0x538f04c4,0xe1a00001],[0x538f04d8,0xe1a0c00d],[0x538ea9b0,0xe5d03014]] as const)expectWord(p,a,w);
 const ctx=p.append(u32le([0x538f0448,0x538f04d8,0x538f04c4,0x538f21a0,0x538ea9b0,capture.lookup]),16);
 const raw=Uint8Array.from(atob(FILM_STAMP_CODE),c=>c.charCodeAt(0));
 if(raw.length!==FILM_STAMP_CODE_LENGTH||raw.length%4)throw Error('Film timestamp module length');
 const code=p.append(raw,16);
 const stub=p.append(at=>assembleWords(`push {r0,r1,r2,r3,ip,lr};mrs ip,cpsr;push {r4,ip};
  ldr r1,[r1,#8];movw r0,#${ctx&65535};movt r0,#${ctx>>>16};bl #${code};
  pop {r4,ip};msr cpsr_f,ip;pop {r0,r1,r2,r3,ip,lr};mov ip,sp;b #${site+4}`,at),16);
 const n=(stub-site-8)>>2;if(n< -0x800000||n>0x7fffff)throw Error('film timestamp branch range');
 p.setWord(site,(0xea000000|(n&0xffffff))>>>0,'film timestamp: snapshot-gated JPEG encode imprint');
}
