// SPDX-License-Identifier: GPL-2.0-only
// Request the same still-image-control apply path as the camera's own ADJ setter.
import {Patch,expectWord,u32le} from './build';
import {assembleWords} from './arm';
const installed=new WeakMap<Patch,number>();
export function installFilmPreview(p:Patch):number {
 const prior=installed.get(p);if(prior)return prior;
 // Native still banks: normal, custom 1, custom 2, custom 3. The second member
 // is the applied-value cache, NOT the user's saved Image Control selection.
 const banks=[
  [0x153,0xc3f,0x532b6f80], [0x154,0xc40,0x532b7110],
  [0x155,0xc41,0x532b72a0], [0x156,0xc42,0x532b7430],
 ];
 expectWord(p,0x532b6f68,0xe5d52c3f);
 expectWord(p,0x532b70f8,0xe5d52c40);
 const table=p.append(u32le(banks.flat()),4);
 // Force the selected bank through its native dirty-cache check while keeping
 // the actual style value unchanged. Its ordinary setter builds the original
 // callback vector and commits with 532AA14C -> 532A90FC, which applies the
 // processing configuration. A raw write to our film byte never did this.
 const fn=p.append(a=>assembleWords(`push {r4,r5,r6,lr};bl #0x5323ea84;bl #0x5323f018;mov r4,r0;
  bl #0x5329789c;cmp r0,#3;bhi done;mov r1,#12;mul r0,r1,r0;
  movw r5,#${table&65535};movt r5,#${table>>>16};add r5,r5,r0;
  ldr r2,[r5];ldrb r1,[r4,r2];ldr r2,[r5,#4];eor r3,r1,#255;strb r3,[r4,r2];
  mov r0,r4;ldr r3,[r5,#8];mov lr,pc;bx r3;
  done:pop {r4,r5,r6,pc}`,a),16);
 installed.set(p,fn);return fn;
}
