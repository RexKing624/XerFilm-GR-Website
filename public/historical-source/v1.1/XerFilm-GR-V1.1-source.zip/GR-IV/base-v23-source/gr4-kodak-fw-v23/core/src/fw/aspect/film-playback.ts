// SPDX-License-Identifier: GPL-2.0-only
// An independently owned 40x40 film icon in the blank INFO area below Std.
import {Patch,expectWord,u32le} from './build';
import {assembleWords,movWord} from './arm';
import {FILM_LOOK_COUNT,FILM_HUD_ICONS} from './film-catalog';
const PTR=0x334;
const addr=(r:string,a:number)=>`movw ${r},#${a&65535};movt ${r},#${a>>>16};`;
const branch=(a:number,b:number,link=false)=>{const d=(b-a-8)>>2;if(d< -0x800000||d>0x7fffff)throw Error('INFO branch range');return((link?0xeb000000:0xea000000)|(d&0xffffff))>>>0;};
export function installFilmPlayback(p:Patch){
 const fn=(s:string)=>p.append(a=>assembleWords(s,a),16);
 expectWord(p,0x53186e08,0xe3a00fcd);
 p.setWord(0x53186e08,movWord(0,0x338),'film: extend playback controller for independent INFO icon');
 expectWord(p,0x53190098,0xe5c4531c);
 const zero=fn(`str r5,[r4,#${PTR}];strb r5,[r4,#0x31c];b #0x5319009c`);
 p.setWord(0x53190098,branch(0x53190098,zero),'film: initialize INFO icon owner');
 const desc=p.append(u32le([10,240,320,40,40,0]),4);
 if(FILM_HUD_ICONS.length!==FILM_LOOK_COUNT)throw Error('Every film needs a playback icon');
 const icons=p.append(u32le(FILM_HUD_ICONS),4);
 const layout=`ldr r0,[r4,#0x15c];ldr r3,[r0];ldr r3,[r3,#0x48];mov lr,pc;bx r3;
  ldr r0,[r4,#0x15c];ldr r3,[r0];ldr r3,[r3,#0x28];mov lr,pc;bx r3;
  ldr r0,[r4,#0x15c];ldr r3,[r0];ldr r3,[r3,#0x34];mov lr,pc;bx r3;
  ldr r0,[r4,#0x15c];bl #0x535899bc;`;
 const update=fn(`push {r4,r5,r6,lr};mov r4,r0;bl #0x53191670;
  mov r0,r4;bl #0x53183e14;cmp r0,#0x4000001;bne hide;
  add r0,r4,#0x300;ldrh r0,[r0,#28];cmp r0,#2;bne hide;
  bl #0x5323ea84;bl #0x5323f67c;add r0,r0,#0x194;mov r1,#0x25;bl #0x537d3f30;
  sub r5,r0,#128;cmp r5,#${FILM_LOOK_COUNT-1};bhi hide;
  ldr r6,[r4,#${PTR}];cmp r6,#0;bne ready;
  ${addr('r0',desc)}bl #0x53589ee4;mov r6,r0;str r0,[r4,#${PTR}];
  ldr r0,[r4,#0x15c];mov r1,r6;bl #0x53588158;
  ready:${addr('r1',icons)}ldr r1,[r1,r5,lsl #2];
  mov r0,r6;bl #0x53576e38;mov r0,r6;mov r1,#1;bl #0x53589ab4;${layout}b done;
  hide:ldr r0,[r4,#${PTR}];cmp r0,#0;beq done;mov r1,#0;bl #0x53589ab4;
  done:mov r0,r4;pop {r4,r5,r6,pc}`);
 expectWord(p,0x53194604,0xebfff419);
 p.setWord(0x53194604,branch(0x53194604,update,true),'film: update photo-owned INFO icon alongside native Std');
 expectWord(p,0x5318f80c,0xe1a0c00d);
 const destroy=fn(`push {r0,r1,r2,r3,r4,r5,ip,lr};mov r4,r0;add r1,r0,#${PTR};mov r2,#1;bl #0x531832a8;
  mov r2,#0;str r2,[r4,#${PTR}];pop {r0,r1,r2,r3,r4,r5,ip,lr};mov ip,sp;b #0x5318f810`);
 p.setWord(0x5318f80c,branch(0x5318f80c,destroy),'film: free INFO icon before native playback root');
}
