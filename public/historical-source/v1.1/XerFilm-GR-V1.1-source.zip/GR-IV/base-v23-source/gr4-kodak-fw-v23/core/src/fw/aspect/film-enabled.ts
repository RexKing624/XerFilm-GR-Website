// SPDX-License-Identifier: GPL-2.0-only
// A filtered ADJ index is never a persistent film identity.
import {Patch,u32le} from './build';
import {assembleWords} from './arm';
import {FILM_COUNT,FILM_LOOK_COUNT,FILM_LOOK_FAMILIES,FILM_FAMILIES} from './film-catalog';
import {installFilmPreview} from './film-preview';
// Three alignment bytes after native u8 +0x48 and before native u32 +0x4c.
// Native default initialization leaves them untouched; old builds have no tag.
// Whole-user-record save/load includes them; persistence still needs a camera test.
export const FILM_MASK_BYTES=[0x49,0x4a,0x4b] as const;
export const FILM_MASK_BASE=0x55084dd8+4;
const SELECT=FILM_MASK_BASE+0x90f,FLAG=FILM_MASK_BASE+0x94b;
const MAGIC=0xc80000,ALL=(1<<FILM_COUNT)-1;
const addr=(r:string,a:number)=>`movw ${r},#${a&65535};movt ${r},#${a>>>16};`;
const installed=new WeakMap<Patch,ReturnType<typeof create>>();
function create(p:Patch){
 const fn=(s:string)=>p.append(a=>assembleWords(s,a),16),preview=installFilmPreview(p);
 const parents=p.append(Uint8Array.from(FILM_LOOK_FAMILIES),4),defaults=p.append(Uint8Array.from(FILM_FAMILIES.map(f=>f.first)),4);
 // Existing 0xC8 tag remains byte-for-byte stable until timestamp is configured.
 // New high byte 0x40..0x6f: tag01 (bits22..23), stamp0..5 (bits19..21),
 // grain0..3 (bits17..18), family17th bit. No additional native fields are used.
 // Both formats preserve all orthogonal preferences on mask/grain changes.
 const store=fn(`${addr('r2',FILM_MASK_BASE)}ldrb r1,[r2,#0x4b];sub r3,r1,#0x40;cmp r3,#0x30;blo stamped;and r3,r1,#0xf8;cmp r3,#0xc8;and r1,r1,#6;movne r1,#0;
  mov r1,r1,lsl #16;orr r1,r0,r1;${addr('r3',MAGIC)}orr r1,r1,r3;strb r1,[r2,#0x49];mov r1,r1,lsr #8;strb r1,[r2,#0x4a];mov r1,r1,lsr #8;strb r1,[r2,#0x4b];bx lr;stamped:and r1,r1,#0xfe;mov r1,r1,lsl #16;orr r1,r0,r1;strb r1,[r2,#0x49];mov r1,r1,lsr #8;strb r1,[r2,#0x4a];mov r1,r1,lsr #8;strb r1,[r2,#0x4b];bx lr`);
 const mask=fn(`${addr('r2',FILM_MASK_BASE)}ldrb r0,[r2,#0x49];ldrb r1,[r2,#0x4a];orr r0,r0,r1,lsl #8;ldrb r1,[r2,#0x4b];orr r0,r0,r1,lsl #16;
  mov r1,r0,lsr #16;sub r1,r1,#0x40;cmp r1,#0x30;${addr('r3',ALL)}andlo r0,r0,r3;bxlo lr;mov r1,r0,lsr #19;cmp r1,#0x19;${addr('r3',ALL)}andeq r0,r0,r3;bxeq lr;
  mov r1,r0,lsr #17;cmp r1,#0x5a;andeq r0,r0,r3;movne r0,r3;b #${store}`);
 const grain=fn(`${addr('r2',FILM_MASK_BASE)}ldrb r0,[r2,#0x4b];sub r1,r0,#0x40;cmp r1,#0x30;blo valid;and r1,r0,#0xf8;cmp r1,#0xc8;movne r0,#0;bxne lr;valid:mov r0,r0,lsr #1;and r0,r0,#3;bx lr`);
 const setGrain=fn(`cmp r0,#3;bxhi lr;push {r4,lr};mov r4,r0;bl #${mask};${addr('r2',FILM_MASK_BASE)}ldrb r1,[r2,#0x4b];sub r3,r1,#0x40;cmp r3,#0x30;andlo r1,r1,#0xf9;andhs r1,r1,#1;orrhs r1,r1,#0xc8;orr r1,r1,r4,lsl #1;strb r1,[r2,#0x4b];pop {r4,pc}`);
 const stamp=fn(`${addr('r2',FILM_MASK_BASE)}ldrb r0,[r2,#0x4b];sub r1,r0,#0x40;cmp r1,#0x30;movhs r0,#0;bxhs lr;mov r0,r0,lsr #3;and r0,r0,#7;bx lr`);
 const setStamp=fn(`cmp r0,#5;bxhi lr;push {r4,lr};mov r4,r0;bl #${mask};${addr('r2',FILM_MASK_BASE)}ldrb r1,[r2,#0x4b];and r1,r1,#7;orr r1,r1,#0x40;orr r1,r1,r4,lsl #3;strb r1,[r2,#0x4b];pop {r4,pc}`);
 const enabled=fn(`cmp r0,#${FILM_COUNT};movhs r0,#0;bxhs lr;push {r4,lr};mov r4,r0;bl #${mask};mov r1,#1;tst r0,r1,lsl r4;movne r0,#1;moveq r0,#0;pop {r4,pc}`);
 // OFF always owns compact row zero, independently of the enabled-family mask.
 const count=fn(`push {r4,lr};bl #${mask};mov r1,#1;loop:cmp r0,#0;beq done;sub r2,r0,#1;and r0,r0,r2;add r1,r1,#1;b loop;done:mov r0,r1;pop {r4,pc}`);
 // at(visible row) -> stable family; -1 denotes OFF or an invalid row.
 const at=fn(`cmp r0,#0;mvneq r0,#0;bxeq lr;push {r4,lr};sub r4,r0,#1;bl #${mask};mov r1,#0;loop:cmp r1,#${FILM_COUNT};mvnhs r0,#0;pophs {r4,pc};tst r0,#1;beq next;cmp r4,#0;moveq r0,r1;popeq {r4,pc};sub r4,r4,#1;next:mov r0,r0,lsr #1;add r1,r1,#1;b loop`);
 const rank=fn(`push {r4,lr};mov r4,r0;bl #${mask};mov r1,#1;mov r2,#0;loop:cmp r2,r4;beq done;tst r0,#1;addne r1,r1,#1;mov r0,r0,lsr #1;add r2,r2,#1;cmp r2,#${FILM_COUNT};blo loop;done:mov r0,r1;pop {r4,pc}`);
 const rawFamily=fn(`${addr('r2',SELECT)}ldrb r0,[r2];cmp r0,#${FILM_LOOK_COUNT};movhs r0,#0;${addr('r3',parents)}ldrb r0,[r3,r0];bx lr`);
 const ensureOne=fn(`push {r4,lr};bl #${mask};cmp r0,#0;popne {r4,pc};bl #${rawFamily};mov r1,#1;mov r0,r1,lsl r0;bl #${store};pop {r4,pc}`);
 const toggle=fn(`cmp r0,#${FILM_COUNT};movhs r0,#0;bxhs lr;push {r4,r5,r6,lr};mov r4,r0;bl #${mask};mov r1,#1;eor r5,r0,r1,lsl r4;mov r0,r5;bl #${store};cmp r5,#0;beq empty;
  bl #${rawFamily};mov r1,#1;tst r5,r1,lsl r0;bne done;
  mov r1,#0;mov r2,r5;first:tst r2,#1;bne found;mov r2,r2,lsr #1;add r1,r1,#1;b first;
  found:${addr('r2',defaults)}ldrb r1,[r2,r1];${addr('r2',SELECT)}strb r1,[r2];${addr('r2',FLAG)}ldrb r0,[r2];cmp r0,#1;bleq #${preview};b done;
  empty:${addr('r2',FLAG)}ldrb r0,[r2];cmp r0,#1;mov r1,#0;strb r1,[r2];bleq #${preview};
  done:mov r0,r5;pop {r4,r5,r6,pc}`);
 return{store,mask,enabled,count,at,rank,toggle,ensureOne,rawFamily,grain,setGrain,stamp,setStamp};
}
export function installFilmEnabled(p:Patch){const old=installed.get(p);if(old)return old;const value=create(p);installed.set(p,value);return value;}
