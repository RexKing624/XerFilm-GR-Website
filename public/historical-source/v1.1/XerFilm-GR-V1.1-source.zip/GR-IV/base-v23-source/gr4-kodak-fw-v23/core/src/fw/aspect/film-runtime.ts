// SPDX-License-Identifier: GPL-2.0-only
// GR IV 1.11 only. Preserve native execution byte-for-byte when the film switch is off.
import {Patch,expectWord,u32le} from './build';
import {assembleWords} from './arm';
import {FILM_LOOK_COUNT,FILM_HUD_ICONS} from './film-catalog';
import {FILM_SELECTION_BYTE} from './film-adj';
import {FILM_VIRTUAL_READS} from './film-virtual-reads';
import {FILM_MODELS} from './film-models';
import {installFilmGrain} from './film-grain';
import {installFilmMetadata} from './film-metadata';
const mappedWord=(p:Patch,a:number)=>new DataView(p.readMapped(a,4).buffer).getUint32(0,true);
const FLAGS=0x55084dd8+4+0x94b;
const lo=(n:number)=>n&65535,hi=(n:number)=>n>>>16;
const address=(r:string,n:number)=>`movw ${r},#${lo(n)};movt ${r},#${hi(n)}`;
function branch(at:number,to:number){const d=(to-at-8)>>2;if(d< -0x800000||d>0x7fffff)throw Error('film branch range');return (0xea000000|(d&0xffffff))>>>0;}
const active=(r:string)=>`${address(r,FLAGS)};ldrb ${r},[${r}];cmp ${r},#1;movhi ${r},#0;tst ${r},#1`;
/** Read flags without disturbing caller registers or condition flags. */
function conditional(p:Patch,site:number,expected:number,original:string,enabled:string,scratch='ip'){
 expectWord(p,site,expected);
 const fn=p.append(at=>assembleWords(`push {r0,r1,r2,ip};mrs r0,cpsr;${active(scratch)};beq original;${enabled};b finish;original:${original};finish:msr cpsr_f,r0;str r2,[sp,#8];pop {r0,r1,r2,ip};b #${site+4}`,at),16);
 p.setWord(site,branch(site,fn),'film: gated '+site.toString(16));
}
export function installFilmRuntime(p:Patch):void {
 if(FILM_MODELS.length!==FILM_LOOK_COUNT)throw Error('Every film needs actual fitted resources');
 // Two trailing padding bytes of the native 0x210-byte processor are unused
 // by all three derived classes. Each processor tracks its own applied film
 // identity. Only a change forces the native full-parameter update decision; no
 // per-frame forced reload, settings rewrite or artificial shutter event.
 expectWord(p,0x53910d1c,0xe5c4520d);
 const init=p.append(at=>assembleWords(`push {r2,r3};movw r3,#65535;add r2,r4,#0x200;strh r3,[r2,#14];pop {r2,r3};strb r5,[r4,#0x20d];b #0x53910d20`,at),16);
 p.setWord(0x53910d1c,branch(0x53910d1c,init),'film: initialize per-processor look identity');
 // Consume the identity exactly where the native routine decides its update
 // flags. Earlier scalar setup is followed by a write to +20D and cannot be
 // used to force this decision reliably.
 expectWord(p,0x5391268c,0xe5d4120d);
 const refresh=p.append(at=>assembleWords(`push {r0,r2,r3,ip};mrs r0,cpsr;${active('r3')};beq off;
  ${address('r3',FILM_SELECTION_BYTE)};ldrb r2,[r3];cmp r2,#${FILM_LOOK_COUNT-1};movhi r2,#0;orr r2,r2,#256;b compare;
  off:mov r2,#0;compare:add ip,r4,#0x200;ldrh r3,[ip,#14];cmp r3,r2;
  ldrb r1,[r4,#0x20d];strhne r2,[ip,#14];orrne r1,r1,#1;
  msr cpsr_f,r0;pop {r0,r2,r3,ip};b #0x53912690`,at),16);
 p.setWord(0x5391268c,branch(0x5391268c,refresh),'film: look identity participates in native full-update decision');
 // Effective native style remains Standard while enabled; original stored selection is untouched.
 const getter=0x533b64e0;expectWord(p,getter,0xe1a0c00d);
 const get=p.append(at=>assembleWords(`push {r2,r3};mrs r2,cpsr;${active('r3')};beq native;msr cpsr_f,r2;pop {r2,r3};mov r0,#11;bx lr;native:msr cpsr_f,r2;pop {r2,r3};mov ip,sp;b #${getter+4}`,at),16);
 p.setWord(getter,branch(getter,get),'film: effective Standard style getter');
 // Ignore changes through the native image-control setter while the film switch is active.
 const setter=0x533b70cc;const first=p.word(setter);
 if(first!==0xe1a0c00d)throw Error('image-control setter prologue differs');
 const set=p.append(at=>assembleWords(`push {r2,r3};mrs r2,cpsr;${active('r3')};beq native;msr cpsr_f,r2;pop {r2,r3};bx lr;native:msr cpsr_f,r2;pop {r2,r3};mov ip,sp;b #${setter+4}`,at),16);
 p.setWord(setter,branch(setter,set),'film: native image-control changes blocked while enabled');
 // Capture parameter setup: route to the actual Standard case, not a GR III address.
 conditional(p,0x539113f8,0xe5d3279c,'ldrb r2,[r3,#0x79c]','mov r2,#11');
 // The Standard case neutral controls. 4 is the stock encoded zero for these -4..+4 controls.
 for(const [site,word,reg,off] of [[0x53911614,0xe5d3a79d,'sl',0x79d],[0x5391161c,0xe5d3879e,'r8',0x79e],[0x53911624,0xe5d3679f,'r6',0x79f],[0x5391162c,0xe5d347a0,'r4',0x7a0],[0x53911634,0xe5d3c7a1,'ip',0x7a1],[0x5391163c,0xe5d327a2,'r2',0x7a2],[0x53911648,0xe5d3a7a4,'sl',0x7a4],[0x5391166c,0xe5d3a7b3,'sl',0x7b3],[0x53911684,0xe5d347b4,'r4',0x7b4]] as const){
  // ip/r2 are saved by conditional's frame; their output needs a different wrapper below.
  const scratch=reg==='ip'?'r1':'ip';
  expectWord(p,site,word);
  const fn=p.append(at=>assembleWords(`push {r0,r1,r2,ip};mrs r0,cpsr;${active(scratch)};beq native;mov ${reg},#4;b finish;native:ldrb ${reg},[r3,#${off}];finish:msr cpsr_f,r0;${reg==='r2'?'str r2,[sp,#8]':reg==='ip'?'str ip,[sp,#12]':''};pop {r0,r1,r2,ip};b #${site+4}`,at),16);
  p.setWord(site,branch(site,fn),'film: neutral Standard control');
 }
 // Every processing consumer sees the same effective Standard style and grain level.
 // These guarded read substitutions never overwrite the saved style; turning off restores the
 // exact original load and caller registers/flags. Scope and each site are recorded for audit.
 const reads={'0x79c':FILM_VIRTUAL_READS['0x79c']};
 for(const [field,entries] of Object.entries(reads)) for(const load of entries){
  if(load.address===0x539113f8 || load.address===0x537150fc || load.address===0x53701c8c || load.address===0x53701e20)continue;
  // Photo metadata must use the capture snapshot, never the live camera switch.
  if(load.address>=0x537da000 && load.address<0x537df000)continue;
  const scratch=[0,1,2,3,12].filter(r=>r!==load.rn&&r!==load.rd).slice(0,2);
  const flag=`r${scratch[0]}`,tmp=`r${scratch[1]}`,dest=`r${load.rd}`,base=`r${load.rn}`;
  const body=field==='0x79c'?`mov ${dest},#11`:field==='0x7b5'?`mov ${dest},#1`:field==='0x7b6'?`mov ${dest},#0`:
   `mov ${tmp},${tmp},lsr #1;and ${tmp},${tmp},#3;cmp ${tmp},#2;movhi ${tmp},#0;mov ${dest},${tmp}`;
  expectWord(p,load.address,load.word);
  const fn=p.append(at=>assembleWords(`push {${flag},${tmp}};mrs ${flag},cpsr;${active(tmp)};beq native;${body};b finish;native:ldrb ${dest},[${base},#${load.offset}];finish:msr cpsr_f,${flag};pop {${flag},${tmp}};b #${load.address+4}`,at),16);
  p.setWord(load.address,branch(load.address,fn),'film: virtual '+field+' read');
 }
 // Scope the selected-look icon to the shooting HUD wrapper, leaving the shared style
 // resolver and native ADJ Image Control icon completely untouched.
 if(FILM_HUD_ICONS.length!==FILM_LOOK_COUNT)throw Error('Every film needs an explicit shooting icon');
 const hudIcons=p.append(u32le(FILM_HUD_ICONS),4);
 expectWord(p,0x53397450,0xe2800004);
 const icon=p.append(at=>assembleWords(`push {r1,r3,ip,lr};mrs ip,cpsr;${active('r3')};beq native;
 ${address('r3',FILM_SELECTION_BYTE)};ldrb r0,[r3];cmp r0,#${FILM_LOOK_COUNT-1};movhi r0,#0;
 ${address('r3',hudIcons)};ldr r0,[r3,r0,lsl #2];
 msr cpsr_f,ip;pop {r1,r3,ip,lr};bx lr;
 native:msr cpsr_f,ip;pop {r1,r3,ip,lr};add r0,r0,#4;b #0x53397454`,at),16);
 p.setWord(0x53397450,branch(0x53397450,icon),'film: selected look icon only on shooting HUD');
 // 0x533971cc also dispatches unrelated overlay icons 31..33. Do not replace it globally.
 // Clone Standard records, retaining its camera basis and auxiliary/region controls.
 const pointers:Fitted[]=[];
 for(const model of FILM_MODELS){
  const matrix=p.append(model.matrix,4),gammaChannels=[0,1,2].map(c=>p.append(model.gamma.slice(c*512,c*512+512),4));
  const matrixRecord=p.readMapped(mappedWord(p,0x55053780+11*4),128);new DataView(matrixRecord.buffer).setUint32(4,matrix,true);
  const gammaRecord=p.readMapped(mappedWord(p,0x55053138+11*4),128);gammaRecord[4]=1;gammaRecord[5]=0;
  const gv=new DataView(gammaRecord.buffer);gammaChannels.forEach((v,c)=>gv.setUint32(8+c*4,v,true));
  const multiRecord=p.readMapped(mappedWord(p,0x55053504+11*4),128);const block=p.append(model.multi,4);new DataView(multiRecord.buffer).setUint32(8,p.append(u32le(Array(8).fill(block)),4),true);
  pointers.push({matrix:p.append(matrixRecord,16),multi:p.append(multiRecord,16),gamma:p.append(gammaRecord,16)});
 }
 for(const [site,kind] of [[0x53925fa8,'matrix'],[0x53925fd4,'multi'],[0x5392602c,'gamma']] as const){
  const table=p.append(u32le(pointers.map(r=>r[kind])),16);expectWord(p,site,0xe7930100);
  const fn=p.append(at=>assembleWords(`push {r1,r2,ip,lr};mrs r2,cpsr;${active('ip')};beq native;${address('r1',FILM_SELECTION_BYTE)};ldrb r1,[r1];cmp r1,#${FILM_LOOK_COUNT-1};movhi r1,#0;${address('ip',table)};ldr r0,[ip,r1,lsl #2];b finish;native:ldr r0,[r3,r0,lsl #2];finish:msr cpsr_f,r2;pop {r1,r2,ip,lr};b #${site+4}`,at),16);
  p.setWord(site,branch(site,fn),'film: selected resource bank '+kind);
 }
 installFilmMetadata(p);
 installFilmGrain(p);
}
type Fitted={matrix:number;multi:number;gamma:number};
