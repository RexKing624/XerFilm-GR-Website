// SPDX-License-Identifier: GPL-2.0-only
import {expect,it} from 'vitest';
import {readFileSync} from 'node:fs';
import {assemble} from '../src/fw/aspect/arm';
const reference=JSON.parse(readFileSync(new URL('./fw-helpers/iso-grain-vfp.json',import.meta.url),'utf8'));
it('matches independently compiled Clang VFP save/restore and FPSCR instructions',()=>{
 expect(Buffer.from(assemble(reference.source,0x54000000)).toString('hex')).toBe(reference.hex);
});
it('rejects unsupported FP register and FPSCR forms',()=>{
 for(const source of ['vpush {d32}','vpop {d7-d6}','vpush {s0}','vmov s32,r0','vmov r0,s0','vmrs pc,fpscr','vmsr fpscr,pc','vmrs r0,cpsr']){
  expect(()=>assemble(source,0x54000000),source).toThrow();
 }
});
