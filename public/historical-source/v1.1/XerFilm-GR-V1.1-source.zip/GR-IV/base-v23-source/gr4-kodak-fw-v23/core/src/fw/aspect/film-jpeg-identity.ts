// SPDX-License-Identifier: GPL-2.0-only
// A film identity belongs to the saved JPEG, never the current playback UI.
// PentaxMakernoteEntryDataSetter is shared by JPEG, DNG and other writers.
// Give ONLY the ordinary ExifJpegMetaDataWriter member a private vtable.
// v21 incorrectly covered the auxiliary AppMarker writer, not normal photos.
// Its tag 0x4f handler uses the immutable capture sidecar, not guessed fields
// in ShotInfo. The original DNG/shared writer and original vtable stay intact.
import {Patch,expectWord,u32le} from './build';
import {assembleWords} from './arm';
import {installFilmCapture} from './film-capture';
import {FILM_LOOK_COUNT} from './film-catalog';
const addr=(r:string,a:number)=>`movw ${r},#${a&65535};movt ${r},#${a>>>16};`;
const branch=(a:number,b:number)=>{const d=(b-a-8)>>2;if(d< -0x800000||d>0x7fffff)throw Error('JPEG identity branch range');return(0xea000000|(d&0xffffff))>>>0;};
export function installFilmJpegIdentity(p:Patch){
 const {lookup}=installFilmCapture(p);
 const fn=(s:string)=>p.append(a=>assembleWords(s,a),16);
 // This is a dispatch override, not a hook on the shared ImageTone writer.
 expectWord(p,0x53fa7664,0x5380eeb0);
 const dispatch=fn(`push {r0,r1,r2,r3,ip,lr};mrs ip,cpsr;push {r4,ip};
  ldrh r3,[r1,#4];cmp r3,#0x4f;bne native;
  ldr r0,[r0,#0x18];bl #${lookup};tst r0,#0x80000000;beq native;
  mov r4,r0,lsr #24;and r4,r4,#31;cmp r4,#${FILM_LOOK_COUNT-1};bhi native;
  ldr r0,[sp,#12];bl #0x537e7174;
  ldr r0,[sp,#12];mov r1,#0;movw r2,#0x8200;add r2,r2,r4;bl #0x537e7148;
  pop {r4,ip};msr cpsr_f,ip;pop {r0,r1,r2,r3,ip,lr};mov r0,#1;bx lr;
  native:pop {r4,ip};msr cpsr_f,ip;pop {r0,r1,r2,r3,ip,lr};b #0x5380eeb0`);
 // Preserve offset-to-top and RTTI as well as every other native virtual slot.
 const words=Array.from({length:11},(_,i)=>p.word(0x53fa7648+i*4));
 words[2+0x14/4]=dispatch;
 const vtable=p.append(u32le(words),4)+8;
 // Ordinary still JPEG owner RTTI: ExifJpegMetaDataWriter, vtable53fa7328.
 // Constructor53809564 has just constructed its setter at owner+0x240.
 // Auxiliary AppMarker, movie, DNG and the shared setter are left native.
 expectWord(p,0x53809638,0x53fa7328);
 expectWord(p,0x53809600,0xe2840d09);
 expectWord(p,0x53809604,0xeb000c32);
 expectWord(p,0x53809608,0xe5845268);
 const own=fn(`${addr('r3',vtable)}str r3,[r4,#0x240];str r5,[r4,#0x268];b #0x5380960c`);
 p.setWord(0x53809608,branch(0x53809608,own),'film: ordinary still-JPEG owned MakerNote setter; auxiliary/movie/DNG remain native');
}
