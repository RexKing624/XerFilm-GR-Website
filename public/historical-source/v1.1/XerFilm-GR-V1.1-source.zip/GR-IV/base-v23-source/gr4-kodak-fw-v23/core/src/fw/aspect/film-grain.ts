// SPDX-License-Identifier: GPL-2.0-only
// GR IV 1.11. Use the native granulation parameter preparation and stage gate.
// Inspired by GRLife gr3-film-mods FINDINGS §§47–48; GR III addresses are not reused.
// Decisions use the immutable render-job sidecar and captured Sv, never live UI settings at rendering.
import {Patch,expectWord} from './build';
import {assembleWords} from './arm';
import {installFilmCapture} from './film-capture';
const branch=(a:number,b:number)=>{const n=(b-a-8)>>2;if(n< -0x800000||n>0x7fffff)throw Error('grain branch range');return(0xea000000|(n&0xffffff))>>>0;};
export function installFilmGrain(p:Patch){
 const fn=(s:string)=>p.append(a=>assembleWords(s,a),16),capture=installFilmCapture(p);
 // The native EXIF ISO getter and processing setup both read captured APEX
 // Sv from ShotInfo+0xBA0. Use its original conversion and ISO table so the
 // boundaries follow the reported ISO, including nominal third-stop rounding.
 expectWord(p,0x537fe338,0xe2833eba);
 expectWord(p,0x537fe33c,0xed938a00);
 expectWord(p,0x5370484c,0xe2863eba);
 expectWord(p,0x538f5568,0xeef77a00);
 expectWord(p,0x538f5588,0xebe1d015);
 // All native grain reads below return r3. Preserve every other register and NZCV.
 for(const [site,word,off,kind] of [
  [0x53701c8c,0xe5d4379c,0x79c,'standard'],
  [0x53701e20,0xe5d4379c,0x79c,'standard'],
  [0x53701cfc,0xe5d437b3,0x7b3,'neutral'],
  [0x53701d4c,0xe5d437b4,0x7b4,'neutral'],
  [0x53701dec,0xe5d437b8,0x7b8,'zero'],
  [0x53701e14,0xe5d437b5,0x7b5,'enable'],
  [0x53701e34,0xe5d437b7,0x7b7,'strength'],
  [0x53701e58,0xe5d437b6,0x7b6,'iso-size'],
 ] as const){
  expectWord(p,site,word);
  if(kind==='iso-size'){
   // This is an inline substitution: preserve every input register except r3,
   // NZCV, the exact FPSCR and both caller-clobbered VFP registers used by
   // SvToIso/roundf (d0 and d7). No allocation, persistent write or live lookup.
   const code=fn(`push {r0,r1,r2,r4,ip,lr};mrs ip,cpsr;
    mov r0,r4;bl #${capture.lookup};mov r3,r0;tst r3,#0x80000000;beq native;
    mov r3,r3,lsr #16;and r3,r3,#255;sub r0,r3,#0x40;cmp r0,#0x30;blo tagged;and r0,r3,#0xf8;cmp r0,#0xc8;bne small;tagged:
    mov r3,r3,lsr #1;and r3,r3,#3;cmp r3,#0;beq small;
    ldr r3,[r4,#0xba0];tst r3,#0x80000000;bne small;
    movw r0,#0;movt r0,#0x7f80;cmp r3,r0;bhs small;
    vmrs r1,fpscr;push {r1,ip};vpush {d0};vpush {d7};
    vmov s0,r3;mov r1,#1;bl #0x538f5568;
    mov r3,#0;cmp r0,#400;movhi r3,#1;cmp r0,#800;movhi r3,#2;
    vpop {d7};vpop {d0};pop {r1,ip};vmsr fpscr,r1;b done;
    small:mov r3,#0;b done;
    native:ldrb r3,[r4,#${off}];
    done:msr cpsr_f,ip;pop {r0,r1,r2,r4,ip,lr};b #${site+4}`);
   p.setWord(site,branch(site,code),'film grain: snapshot ISO-adaptive native size');
   continue;
  }
  const value=kind==='standard'?'mov r3,#11':kind==='neutral'?'mov r3,#4':kind==='zero'?'mov r3,#0':`mov r3,r3,lsr #16;and r3,r3,#255;sub r0,r3,#0x40;cmp r0,#0x30;blo tagged;and r0,r3,#0xf8;cmp r0,#0xc8;movne r3,#0;bne parsed;tagged:mov r3,r3,lsr #1;and r3,r3,#3;parsed:cmp r3,#0;${kind==='enable'?'movne r3,#1':'subne r3,r3,#1'}`;
  const code=fn(`push {r0,r1,r2,r4,ip,lr};mrs ip,cpsr;mov r0,r4;bl #${capture.lookup};mov r3,r0;tst r3,#0x80000000;beq native;${value};b done;
   native:ldrb r3,[r4,#${off}];done:msr cpsr_f,ip;pop {r0,r1,r2,r4,ip,lr};b #${site+4}`);
  p.setWord(site,branch(site,code),'film grain: snapshot '+kind+' parameter');
 }
 // Standard skips grain in the stock processing plan. Enable that actual stage
 // for a tagged film snapshot with nonzero grain; OFF follows neutral Standard.
 expectWord(p,0x537150fc,0xe5d1379c);
 const gate=fn(`push {r0,r1,r2,r4,ip,lr};mrs ip,cpsr;mov r4,r0;mov r0,r1;bl #${capture.lookup};mov r3,r0;tst r3,#0x80000000;beq native;
  mov r3,r3,lsr #16;and r3,r3,#255;sub r2,r3,#0x40;cmp r2,#0x30;blo tagged;and r2,r3,#0xf8;cmp r2,#0xc8;movne r3,#0;bne parsed;tagged:mov r3,r3,lsr #1;and r3,r3,#3;parsed:
  cmp r3,#0;movne r3,#1;strb r3,[r4,#0x25];msr cpsr_f,ip;pop {r0,r1,r2,r4,ip,lr};bx lr;
  native:msr cpsr_f,ip;pop {r0,r1,r2,r4,ip,lr};ldrb r3,[r1,#0x79c];b #0x53715100`);
 p.setWord(0x537150fc,branch(0x537150fc,gate),'film grain: snapshot-gated native effect processing stage');
}
