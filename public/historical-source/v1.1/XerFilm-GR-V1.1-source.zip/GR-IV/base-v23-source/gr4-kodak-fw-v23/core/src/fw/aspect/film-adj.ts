// SPDX-License-Identifier: GPL-2.0-only
// Menu-only experiment, based on GR Mod softfocus.ts. Reuses hidden flash ID 0x0A.
import { Patch, expectWord, u32le, utf16z, concat, TEXT_CATALOG } from './build';
import { FILM_COUNT, FILM_NAMES, FILM_FIRST_TEXT, FILM_FIRST_ICON,FILM_ENTRY_ICON,FILM_FAMILY_ICONS,FILM_CHILD_LABELS } from './film-catalog';
import {installFilmMini,MINI_TEXT} from './film-mini';
import {installFilmState} from './film-state';
import {installFilmEnabled} from './film-enabled';
import {installFilmSession} from './film-session';
import { assembleWords, movWord, movImmediate } from './arm';
const TABLE=0x53d9f714, RECORD=0x5c, ID=0x0a;
export const FILM_SELECTION_BYTE=0x55084dd8+4+0x90f;
const lo=(n:number)=>n&65535, hi=(n:number)=>n>>>16;
function branch(at:number,to:number,cond=14){ const d=(to-at-8)>>2; if(d< -0x800000||d>0x7fffff)throw Error('branch range'); return ((cond<<28)|0x0a000000|(d&0xffffff))>>>0; }
export function installFilmAdj(patch:Patch,icons:Uint8Array,name:number):Uint8Array {
 for(const [off,v] of [[0x10,0x531ba124],[0x18,0x531be434],[0x20,0x531bb454],[0x28,0x531bb014],[0x30,0x531ba180]]) expectWord(patch,TABLE+ID*RECORD+off,v);
 const official=[0,1,2,3,4,5,19,6,7,8,9,11,12,13,14,15,16,20,17];
 if(patch.read(0x53dba8c0,19).some((v,i)=>v!==official[i]))throw Error('ADJ menu mismatch');
 const B=FILM_SELECTION_BYTE;
 const state=installFilmState(patch),enabled=installFilmEnabled(patch);
 const mini=installFilmMini(patch);
 const session=installFilmSession(patch);
 const enter=patch.append(at=>assembleWords(`push {r4,lr};bl #${mini.hide};bl #${session.begin};pop {r4,pc}`,at),16);
 const leave=patch.append(at=>assembleWords(`push {r4,lr};bl #${mini.hide};bl #${session.rollback};pop {r4,pc}`,at),16);
 const familyIcons=patch.append(u32le([...FILM_FAMILY_ICONS]),4);
 // Each numeric item gets its own text descriptor in all 21 language catalogs.
 for(let value=0;value<FILM_COUNT;value++){
  const tid=846+value;
  const address=patch.append(utf16z(FILM_NAMES[value]),4);
  const descriptor=patch.append(concat([Uint8Array.from([FILM_NAMES[value].length+1,1,0,0]),u32le([address])]),4);
  for(let lang=0;lang<21;lang++){
   const row=patch.word(TEXT_CATALOG+lang*4);
   if(patch.word(row+tid*4)!==0)throw Error('text collision');
   patch.write(row+tid*4,u32le([descriptor]));
  }
 }
 for(const [i,s] of FILM_CHILD_LABELS.entries()){
  const str=patch.append(utf16z(s),4),descriptor=patch.append(concat([Uint8Array.from([s.length+1,1,0,0]),u32le([str])]),4);
  for(let lang=0;lang<21;lang++){
   const row=patch.word(TEXT_CATALOG+lang*4);if(patch.word(row+(MINI_TEXT+i)*4)!==0)throw Error('speed text collision');
   patch.write(row+(MINI_TEXT+i)*4,u32le([descriptor]));
  }
 }
 for(const site of patch.textBoundSites)patch.setWord(site,movWord(3,Math.max(MINI_TEXT+FILM_CHILD_LABELS.length-1,movImmediate(patch.word(site)))),'film menu: numeric texts');
 // The native icon setter hides the item's other children, including any reused label.
 // Names belong to the header subtitle; the right strip contains icons only.
 const draw=patch.append(at=>assembleWords(`push {r4,r5,r6,lr}
 mov r5,r0;mov r4,r1;mov r0,r1;bl #${enabled.at};mov r6,r0;
 ldr r0,[r5,#0x1f8];uxtb r1,r4;bl #0x53570a9c
 cmp r6,#${FILM_COUNT};movwhs r1,#310;bhs off;movw r2,#${lo(familyIcons)};movt r2,#${hi(familyIcons)};ldr r1,[r2,r6,lsl #2];off:bl #0x5357dd98
 done: pop {r4,r5,r6,pc}`,at),16);
 const current=patch.append(at=>assembleWords(`push {r4,r5,r6,lr};mov r4,r0;mov r5,r1;mov r0,r1;bl #${enabled.at};cmp r0,#${FILM_COUNT};bhs off;mov r1,r0;mov r0,r4;bl #${state.current};pop {r4,r5,r6,pc};
  off:mov r0,#0;cmp r5,#0;popne {r4,r5,r6,pc};movw r2,#${lo(0x55084dd8+4+0x94b)};movt r2,#${hi(0x55084dd8+4+0x94b)};ldrb r1,[r2];cmp r1,#1;movne r0,#1;pop {r4,r5,r6,pc}`,at),16);
 const set=patch.append(at=>assembleWords(`push {r4,r5,r6,lr};mov r4,r0;mov r5,r1;bl #${session.begin};mov r0,r5;bl #${enabled.at};cmp r0,#${FILM_COUNT};blo apply;cmp r5,#0;popne {r4,r5,r6,pc};
  apply:mov r1,r0;mov r0,r4;bl #${state.set};pop {r4,r5,r6,pc}`,at),16);
 const count=enabled.count;
 // +0x164 is the native second-line TextView. Keep the working v4 family-name
 // presentation. 0x53573358 sets a language override (20), not a font size;
 // the English family strings are identical in all 21 language catalogs.
 const subtitle=patch.append(at=>assembleWords(`push {r4,r5,r6,lr};mov r4,r0
 mov r0,r1;bl #${enabled.at};mov r6,r0;cmp r6,#${FILM_COUNT};movhs r1,#2;bhs title;movw r2,#${FILM_FIRST_TEXT};add r1,r6,r2;title:ldr r5,[r4,#0x164]
 mov r0,r5;mov r2,#0;bl #0x5357338c
 mov r0,r5;mov r1,#20;bl #0x53573358
 mov r0,r4;mov r1,r6;bl #${mini.render}
 pop {r4,r5,r6,pc}`,at),16);
 const record=patch.read(TABLE+19*RECORD,RECORD); const view=new DataView(record.buffer);
 for(const [off,value] of [[0,enter],[8,leave],[0x10,subtitle],[0x18,draw],[0x20,current],[0x28,set],[0x30,count]]){view.setUint32(off,value,true);view.setUint32(off+4,0,true);}
 for(let off=0;off<RECORD;off+=4){const value=view.getUint32(off,true);if(patch.word(TABLE+ID*RECORD+off)!==value)patch.setWord(TABLE+ID*RECORD+off,value,'film menu: ADJ record');}
 const list=patch.append(Uint8Array.from([...official.slice(0,16),ID,...official.slice(16)]),16);
 expectWord(patch,0x531dae30,movWord(4,0xa8c0));expectWord(patch,0x531dae40,movWord(4,0x53db,true));expectWord(patch,0x531dae5c,0xe2846013);
 patch.setWord(0x531dae30,movWord(4,lo(list)),'film menu: ADJ list');patch.setWord(0x531dae40,movWord(4,hi(list),true),'film menu: ADJ list');patch.setWord(0x531dae5c,0xe2846014,'film menu: ADJ count');
 expectWord(patch,0x5337ff98,0xe3a00087);patch.setWord(0x5337ff98,movWord(0,name),'film menu: ADJ name');
 // Reuse native Image Control icon. Preserve the adjacent 0x0B branch.
 expectWord(patch,0x53381858,0x9a000035);
 const icon=patch.append(at=>assembleWords(`cmp r3,#0;bne #0x53381934
 cmp r2,#0;movw r0,#${FILM_ENTRY_ICON};movne r0,#0;bx lr`,at),16);
 patch.setWord(0x53381858,branch(0x53381858,icon,9),'film menu: ADJ icon');
 // Reject out-of-range stored function IDs without expanding the native table.
 for(let i=0;i<5;i++){
  const site=0x5329c240+i*8;expectWord(patch,site,0xe5d00920+i);
  const fn=patch.append(at=>assembleWords(`ldrb r0,[r0,#${0x920+i}];cmp r0,#20;movhi r0,#0;bx lr`,at),16);
  patch.setWord(site,branch(site,fn),'film menu: ADJ slot guard');
 }
 return icons;
}
