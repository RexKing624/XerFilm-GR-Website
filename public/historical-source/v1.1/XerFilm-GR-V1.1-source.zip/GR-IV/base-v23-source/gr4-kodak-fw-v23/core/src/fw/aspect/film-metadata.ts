// SPDX-License-Identifier: GPL-2.0-only
// GR IV 1.11 capture-snapshot identity; old pictures retain native metadata.
// Writer/reader exits are based on gr-custom-tool's GPL identity registry.
import {Patch,expectWord} from './build';
import {assembleWords} from './arm';
import {FILM_NEUTRAL_READS} from './film-neutral-reads';
import {installFilmPlayback} from './film-playback';
import {FILM_LOOK_COUNT} from './film-catalog';
import {installFilmJpegIdentity} from './film-jpeg-identity';
const FLAGS=0x55084dd8+4+0x94b;
const addr=(r:string,a:number)=>`movw ${r},#${a&65535};movt ${r},#${a>>>16};`;
const branch=(a:number,b:number)=>{const d=(b-a-8)>>2;if(d< -0x800000||d>0x7fffff)throw Error('metadata branch range');return(0xea000000|(d&0xffffff))>>>0;};
export function installFilmMetadata(p:Patch){
 const fn=(s:string)=>p.append(a=>assembleWords(s,a),16);
 for(const load of FILM_NEUTRAL_READS){
  if(load.snapshot)continue; // no new RAW/DNG control/tag rewriting
  const regs=[0,1,2,3,12].filter(r=>r!==load.rn&&r!==load.rd);
  const flag=`r${regs[0]}`,temp=`r${regs[1]}`,dest=`r${load.rd}`,base=`r${load.rn}`;
  expectWord(p,load.address,load.word);
  const gate=`${addr(temp,FLAGS)}ldrb ${temp},[${temp}];`;
  const code=fn(`push {${flag},${temp}};mrs ${flag},cpsr;${gate}cmp ${temp},#1;bne native;
   mov ${dest},#4;b done;
   native:ldrb ${dest},[${base},#${load.offset}];done:msr cpsr_f,${flag};pop {${flag},${temp}};b #${load.address+4}`);
  p.setWord(load.address,branch(load.address,code),'film: neutral live controls');
 }
 expectWord(p,0x537de474,0xe30f3198);
 // Shared ImageTone writer serves both JPEG and DNG: keep it original.
 // Only the JPEG-owned member writes captured film identity; DNG stays native.
 installFilmJpegIdentity(p);
 for(const [site,word,reg,add,success,resume] of [
  [0x537d575c,0xe300310a,'r3',11,0x537d57ac,0x537d5760],
  [0x537d89b0,0xe3003109,'r2',128,0x537d8a00,0x537d89b4],
 ] as const){
  expectWord(p,site,word);
  const body=reg==='r3'?'mov r3,#11':`add r2,r3,#${add}`;
  const code=fn(`movw r3,#0x8200;sub r3,r0,r3;cmp r3,#${FILM_LOOK_COUNT-1};bhi native;${body};b #${success};
   native:movw r3,#${site===0x537d575c?0x10a:0x109};b #${resume}`);
  p.setWord(site,branch(site,code),'film: decode photo identity '+reg);
 }
 expectWord(p,0x533a3820,0xe2400001);
 const property=fn(`sub r3,r0,#128;cmp r3,#${FILM_LOOK_COUNT-1};bhi native;add r3,r3,#64;cmp r4,#0;b #0x533a383c;
  native:sub r0,r0,#1;b #0x533a3824`);
 p.setWord(0x533a3820,branch(0x533a3820,property),`film: isolated playback identities 64..${64+FILM_LOOK_COUNT-1}`);
 // Keep the stock Std summary and parameter layout. The separate film icon
 // below it is supplied by its own INFO view, not the shared image-control icon.
 for(const site of [0x533a6878,0x533a7624]){
  expectWord(p,site,0xe2433008);
  const code=fn(`push {r2};sub r2,r3,#64;cmp r2,#${FILM_LOOK_COUNT-1};movls r3,#11;pop {r2};sub r3,r3,#8;b #${site+4}`);
  p.setWord(site,branch(site,code),'film: playback Std summary retained');
 }
 installFilmPlayback(p);
}
