# SPDX-License-Identifier: GPL-2.0-only
"""Child OK commits in the mother menu, including the real parent setter refresh.
Native views, keyboard dispatcher, parent setter and transaction code execute;
window painting, device apply and persistent hardware services are stubbed.
"""
from pathlib import Path
HERE=Path(__file__).resolve().parent
src=(HERE/'test-v23-off-session.py').read_text();exec(compile(src[:src.index('# Every family subset')],str(HERE/'test-v23-off-session.py'),'exec'))
for origin in (0,1):
 for family in (10,11,16):
  details=CAT['families'][family]
  for child in range(details['count']):
   e,events,native=setup(7,origin,2);mu=e.mu
   d=0x707f0000;mu.mem_write(d,struct.pack('<6I',13,620,60,100,360,0));main=e.call(0x53589ee4,(d,))
   types=0x707e0000;mu.mem_write(types,bytes([25])*18);e.call(0x5357094c,(main,types,18,58));mu.mem_write(OBJ+0x1f8,struct.pack('<I',main))
   e.call(0x53571788,(main,family+1));e.call(setter,(OBJ,family+1))
   e.stubs[0x531bd580]=lambda:10;e.stubs[0x531bcd00]=lambda:0
   e.stubs[0x5323f018]=lambda:0x70740000;e.stubs[0x5333a114]=lambda:0;e.stubs[0x5333a2a4]=lambda:0
   for a in (0x531becf0,0x531bdf18,0x531bdaac,0x531bf360,render_fn(N)):e.stubs[a]=lambda:0
   # Do not stub 531bf38c or 531beed4: they re-enter the real film setter,
   # which calls session.begin again. Commit must occur after this refresh.
   posts=[];e.stubs[0x5323ebf8]=lambda:0x707c3000;e.stubs[0x5325c678]=lambda:posts.append(mu.reg_read(UC_ARM_REG_R1)) or 0
   setter_hits=[];hook=mu.hook_add(UC_HOOK_CODE,lambda uc,pc,size,ud:setter_hits.append(pc)if pc==setter else None)
   def press(k):
    mu.mem_write(0x707d0000,struct.pack('<H',k));return e.call(0x531bf834,(OBJ,0x707d0000))
   press(0xd4)
   for n in range(child):press(0xd7)
   want=details['first']+child;press(0xe0)
   ck(e.byte(S)==want and e.byte(FLAG)==1 and e.byte(OBJ+0x2a0)==0,'Child OK applies chosen speed and returns focus to mother')
   ck(bool(setter_hits) and e.u32(SESSION)==0 and not posts,'Real mother refresh ran; child acceptance survives its begin call without posting an ADJ-close event')
   ck(e.call(current,(OBJ,family+1))==1,'Mother current marker matches the accepted child family')
   e.call(leave,(OBJ,))
   ck(e.byte(S)==want and e.byte(FLAG)==1 and e.u32(SESSION)==0,'Leaving ADJ after child OK retains selection without a second parent OK')
   # Re-enter a child and cancel without accepting: restore accepted baseline.
   press(0xd4);press(0xd6 if child else 0xd7);press(0xd5);e.call(leave,(OBJ,))
   ck(e.byte(S)==want and e.byte(FLAG)==1 and e.u32(SESSION)==0,'Cancelling a second child visit restores the already accepted speed')
   e.call(0x53571788,(main,1));e.call(setter,(OBJ,1));e.call(leave,(OBJ,))
   ck(e.byte(S)==want and e.byte(FLAG)==1,'Cancelling a later mother-menu preview restores the newly accepted child')
   ck(native_unchanged(e,native),'Child acceptance never rewrites native Image Control parameters')
   ck(not[c for c in e.calls if c[0]in('ASSERT','NULL-JUMP')],'Native child acceptance completes without failed assertions')
   mu.hook_del(hook)
(HERE/'v23-child-accept-checks.json').write_text(json.dumps({'passed':True,'count':len(checks),'checks':checks,'hardwareTested':False,'scope':'All 13 child variants across 3 families, both Film OFF and ON entry; emitted key handler, native parent refresh/setter, current marker, leave/cancel; device apply, draw and physical input not emulated.'},ensure_ascii=False,indent=2))
print('PASS',len(checks),'child acceptance and true native parent-refresh checks')
