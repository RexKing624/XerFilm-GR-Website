.syntax unified
.arm
.text
.global reference
reference:
 dmb ish
 bx lr
