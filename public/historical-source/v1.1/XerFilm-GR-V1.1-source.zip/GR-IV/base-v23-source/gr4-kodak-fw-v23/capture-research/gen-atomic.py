# SPDX-License-Identifier: GPL-2.0-only
from pathlib import Path
import struct,json,hashlib,subprocess
B=Path(__file__).resolve().parent
subprocess.run(['/usr/bin/clang','-target','armv7-none-eabi','-c',str(B/'atomic-reference.s'),'-o',str(B/'atomic-reference.o')],check=True)
b=(B/'atomic-reference.o').read_bytes();assert b[:6]==b'\x7fELF\x01\x01'
shoff=struct.unpack_from('<I',b,32)[0];size,count,strings=struct.unpack_from('<3H',b,46)
s=[struct.unpack_from('<10I',b,shoff+i*size)for i in range(count)];names=b[s[strings][4]:s[strings][4]+s[strings][5]]
secs={names[x[0]:].split(b'\0')[0].decode():x for x in s};text=secs['.text'];code=b[text[4]:text[4]+text[5]]
assert not any(x[1]in(4,9)and x[5]for x in s),'Atomics must have no relocations'
publish=code[:48];increment=code[48:];assert len(publish)==48 and len(increment)==32
words=lambda x:list(struct.unpack('<'+'I'*(len(x)//4),x))
out=B.parent/'core/src/fw/aspect/film-capture-atomic.ts'
out.write_text('// SPDX-License-Identifier: GPL-2.0-only\n// Clang ARMv7 reference assembly; leaf, position-independent, no literal/global relocations.\n'+''.join('export const '+n+' = ['+','.join('0x%08x'%w for w in words(x))+'] as const;\n'for n,x in [('CAPTURE_PUBLISH',publish),('CAPTURE_INCREMENT',increment)]))
(B/'atomic-proof.json').write_text(json.dumps({'passed':True,'bytes':len(code),'sha256':hashlib.sha256(code).hexdigest(),'publish':words(publish),'increment':words(increment),'relocations':0},indent=2));print(len(code),'atomic reference bytes generated')
