.syntax unified
.arm
.text
.global publish
publish:
 mov r2,r0
1:
 ldrex r0,[r2]
 cmp r0,#0
 bne 2f
 dmb ish
 strex r3,r1,[r2]
 cmp r3,#0
 bne 1b
 mov r0,r1
2:
 clrex
 dmb ish
 bx lr
.global increment
increment:
 mov r2,r0
3:
 ldrex r0,[r2]
 add r1,r0,#1
 strex r3,r1,[r2]
 cmp r3,#0
 bne 3b
 dmb ish
 bx lr
