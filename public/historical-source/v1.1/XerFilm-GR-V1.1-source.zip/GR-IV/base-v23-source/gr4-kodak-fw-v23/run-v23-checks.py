from pathlib import Path
import runpy,sys
base=Path(__file__).resolve().parent
for name in ['test-v23-exposure-order.py','test-v23-child-accept.py','test-v23-jpeg-info.py','test-v23-boot-memory.py','test-v23-grid.py','test-v23-parent-layout.py','test-v23-popup.py','test-v23.py','test-v23-grain.py','test-v23-off-session.py','test-v23-iso-grain.py','test-v23-stamp.py','test-v23-capture.py','iso-research/check-source.py']:
 print('Checking',name,flush=True)
 runpy.run_path(str(base/name),run_name='__main__')
sys.argv=[str(base/'audit-color/audit-no-grain.py'),str(base/'build-v23-a/candidate.bin.rtos')]
runpy.run_path(sys.argv[0],run_name='__main__')
