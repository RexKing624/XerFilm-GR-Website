# SPDX-License-Identifier: GPL-2.0-only
"""Real native page permissions + real boot .data loop + capture allocator lifecycle.
Only allocator services are substituted; no whole-camera boot claim.
"""
from pathlib import Path
import os,struct,json
HERE=Path(__file__).resolve().parent;os.chdir(HERE.parent.parent)
exec((HERE/'emu-v6.py').read_text(),globals());BASE=HERE
from unicorn import UC_HOOK_MEM_WRITE,UC_HOOK_MEM_WRITE_PROT,UcError
exec((HERE/'capture-event-fixture.py').read_text(),globals())
from unicorn import arm_const as A
N=h.Image(str(BASE/'build-v23-a/candidate.bin.rtos'));O=h.Image('work/filter-analysis/RTOS.bin')
ROOT=0x55057480;U=0x55084dd8+4;SI=0x60010000;JOB=0x70010000;HEAP=0x70600000
checks=[]
def ck(ok,s):
 if not ok:raise AssertionError(s)
 checks.append(s)
def word(e,a,v):e.mu.mem_write(a,struct.pack('<I',v))
def branch(a):
 w=N.u32(a);n=w&0xffffff;n=n-0x1000000 if n&0x800000 else n;return a+8+n*4
def calls(a):
 out=[]
 for i in Cs(CS_ARCH_ARM,CS_MODE_ARM).disasm(N.rd(a,1600),a):
  if int.from_bytes(i.bytes,'little')&0x0f000000==0x0b000000:out.append(int(i.op_str[1:],16))
  if i.mnemonic=='pop'and'pc'in i.op_str:break
 return out
lookup=calls(branch(0x537150fc))[0];attach=calls(branch(0x536651e4))[0];ensure=calls(attach)[0]
# Boot uses this L1 table and domain1 client permissions. Do not change them.
ck(N.rd(0x53004000,0x4000)==O.rd(0x53004000,0x4000),'Original entire MMU page table remains byte-identical')
ck(N.u32(0x53809608)!=O.u32(0x53809608) and N.u32(0x53806c68)==O.u32(0x53806c68),'INFO changes only ordinary still-JPEG member dispatch; auxiliary writer remains native')
for va,expected in((0x54400000,(2,1)),(ROOT,(3,0)),(HEAP,(3,0))):
 d=N.u32(0x53004000+(va>>20)*4);ck(((d>>10)&3,(d>>15)&1)==expected,f'Native access permissions verified for {va:#x}')
ck(N.u32(0x5300045c)==0x55057500 and N.u32(0x53000458)==0x574a0,'Initialised RAM extends only32 bytes into128-byte gap; BSS boundary unchanged')
e=h.Emu(N);m=e.mu;m.mem_write(ROOT,b'\xa5'*160)
# Execute actual original boot load/multiple-copy instructions with new count.
m.emu_start(0x5300038c,0x530003a8,count=100000)
ck(bytes(m.mem_read(ROOT,32))==bytes(32),'Actual native boot .data copy zeroes all reserved root bytes')
ck(bytes(m.mem_read(ROOT+32,128))==b'\xa5'*128,'Native boot copy does not overwrite remaining padding or first BSS bytes')
# Historical v18/v19 failure must be reproduced by this strict test gate.
for rev,folder in((17,'build-v17-a'),(18,'build-v18-b'),(19,'build-v19-a')):
 x=h.Emu(h.Image(str(BASE.parent/f'gr4-kodak-fw-v{rev}'/folder/'candidate.bin.rtos')));fault=None
 try:x.call(0x537119a0,(JOB,7,SI))
 except UcError as exc:fault=str(exc)
 ck((fault is None)if rev==17 else('WRITE_PROT'in(fault or'')),f'Strict image permissions: v{rev} '+('native succeeds'if rev==17 else'old illegal write is caught'))
class Allocator(h.Emu):
 def __init__(self,img,fail=False,race=False):
  self.fail=fail;self.race=race;self.allocations=[];self.frees=[];self.writes=[];super().__init__(img)
  self.mu.hook_add(UC_HOOK_MEM_WRITE,lambda uc,access,a,n,v,user:self.writes.append((a,n,v)))
 def _hook(self,uc,at,size,user):
  if at==0x538e09b0:
   n=uc.reg_read(A.UC_ARM_REG_R0);self.allocations.append(n)
   p=0 if self.fail else HEAP+(len(self.allocations)-1)*0x1000
   if self.race:
    self.mu.mem_write(HEAP+0x8000,bytes(2064));word(self,ROOT,HEAP+0x8000)
   uc.reg_write(A.UC_ARM_REG_R0,p);uc.reg_write(A.UC_ARM_REG_PC,uc.reg_read(A.UC_ARM_REG_LR));return
  if at==0x538e09ec:
   self.frees.append(uc.reg_read(A.UC_ARM_REG_R0));uc.reg_write(A.UC_ARM_REG_PC,uc.reg_read(A.UC_ARM_REG_LR));return
  return super()._hook(uc,at,size,user)
def prefs(e,on,look=12):
 e.mu.mem_write(U+0x94b,bytes([on]));e.mu.mem_write(U+0x90f,bytes([look]));e.mu.mem_write(U+0x49,(0x400000|5<<19|3<<17|0x1ffff).to_bytes(3,'little'))
def native_bind(e,key=SI):
 before=bytes(e.mu.mem_read(key,0x1000));latch(e,key);e.call(0x537119a0,(JOB,7,key))
 ck(e.u32(JOB+0x4688)==key and e.u32(JOB+0x60)==7,'Original native bind fields still assigned')
 ck(bytes(e.mu.mem_read(key,0x1000))==before,'Native ShotInfo and RAW metadata remain untouched')
 ck(not[a for a,n,v in e.writes if 0x53000000<=a<0x55000000],'No CPU write enters read-only image')
# OFF cold boot does not even request memory or write the new root.
e=Allocator(N);prefs(e,0);native_bind(e)
ck(not e.allocations and e.u32(ROOT)==0 and e.call(lookup,(SI,))==0,'Film OFF cold boot follows native path without allocation')
# Heap service not yet ready: defer until actual later bind, no bad vcall.
e=Allocator(N);prefs(e,1);word(e,0x5539ff00,0);native_bind(e)
ck(not e.allocations and e.u32(ROOT)==0 and e.call(lookup,(SI,))==0,'Early boot without allocator safely bypasses additional effects')
word(e,0x5539ff00,1);native_bind(e)
ck(e.allocations==[2064] and e.u32(ROOT)==HEAP,'First later valid capture allocates one bounded registry in writable RAM')
ck(e.call(lookup,(SI,))==0x8c6fffff,'Captured enabled look12/strength3/date-mode5 reaches RAM registry')
# Many captures wrap the ring without new allocations, image/shot writes or growth.
for i in range(400):
 key=0x60010000+(i%200)*0x1000;native_bind(e,key)
 ck(bool(e.call(lookup,(key,))&0x80000000),'Most recent capture identity remains readable')
ck(e.allocations==[2064]and not e.frees,'400 capture registrations reuse one block; no per-frame allocation')
prefs(e,0);native_bind(e);ck(not(e.call(lookup,(SI,))&0x80000000),'Turning Film OFF replaces a previous active record')
# Allocation failure cannot interfere with original still processing; retry later.
e=Allocator(N,fail=True);prefs(e,1);native_bind(e)
ck(e.allocations==[2064]and e.u32(ROOT)==0 and e.call(lookup,(SI,))==0,'Allocation failure returns to original native bind and disables extra effects')
e.fail=False;native_bind(e);ck(len(e.allocations)==2 and e.u32(ROOT)!=0,'Later successful allocation recovers without restarting the camera')
# Simulate a second initializer publishing during native allocation callback.
e=Allocator(N,race=True);prefs(e,1);native_bind(e)
ck(e.u32(ROOT)==HEAP+0x8000 and e.frees==[HEAP],'Exclusive publication keeps the winning registry and frees only the unpublished loser')
ck(e.call(lookup,(SI,))&0x80000000,'Racing initialization preserves active capture preference')
# Null keys never cause allocation; lookup has no allocator calls.
e=Allocator(N);prefs(e,1);e.call(0x537119a0,(JOB,7,0));ck(e.u32(ROOT)==0 and not e.allocations,'Null native key remains a no-allocation path')
ck(e.call(lookup,(0,))==0 and e.call(lookup,(SI,))==0,'Null/unknown lookup with no registry fails closed')
# Independently compiled CAS instructions exactly match published generated data.
proof=json.loads((BASE/'capture-research/atomic-proof.json').read_text());ck(proof['passed']and proof['relocations']==0,'Native exclusive ARM atomics independently assembled without relocations')
report={'passed':True,'count':len(checks),'checks':checks,'hardwareTested':False,'scope':'Real boot data-copy loop, original MMU descriptors, native processing bind/constructor-entry gates, allocation lifecycle including cold OFF/early boot/failure/race and400 captures. Allocator callbacks and OS boot are simulated; no complete physical boot or DSP execution.'}
(BASE/'v23-boot-memory-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('PASS',len(checks),'strict ROM, native boot RAM initialization and allocator lifecycle checks')
