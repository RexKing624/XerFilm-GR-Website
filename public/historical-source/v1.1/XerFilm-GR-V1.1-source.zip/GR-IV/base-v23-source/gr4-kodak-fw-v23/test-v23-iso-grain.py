# SPDX-License-Identifier: GPL-2.0-only
"""Execute ISO-adaptive grain and the original captured-ISO conversion.
Native parameter preparation runs; sensor/AE and DSP pixel output do not.
"""
from pathlib import Path
import importlib.util,struct,json,itertools,math,hashlib
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent.parent
spec=importlib.util.spec_from_file_location('grain_iso',ROOT/'work/gr4-fuji-fw-v2/audit-grain/check_grain.py')
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
sidecar={};exec((BASE/'sidecar-fixture.py').read_text(),sidecar);sidecar['install'](g)
from unicorn import UC_HOOK_CODE,UC_HOOK_MEM_READ
from unicorn import arm_const as A
stock=(ROOT/'work/filter-analysis/RTOS.bin').read_bytes();new=(BASE/'build-v23-a/candidate.bin.rtos').read_bytes()
metadata=g.Emulator(stock);candidate=g.Emulator(new);native=g.Emulator(stock)
U=0x55084dd8+4;checks=[];observed=[]
def ck(ok,message):
 if not ok:raise AssertionError(message)
 checks.append(message)
def f32(v):return struct.pack('<f',v)
def captured_iso(v):
 metadata.configure(0,11,1,0,0);mu=metadata.mu
 mu.mem_write(g.CONTEXT+4,struct.pack('<I',0x60030000));mu.mem_write(0x60030004,struct.pack('<I',0x60031000))
 mu.mem_write(0x60031144,struct.pack('<I',0));mu.mem_write(g.CONTEXT+8,struct.pack('<I',g.SI))
 mu.mem_write(g.SI+0xba0,f32(v));mu.mem_write(0x553a0a6c,struct.pack('<I',1))
 return metadata.call(0x537fe310)['return']
def prepare(sv,level,look=0,live=0,tag=0xc80000,flag=1):
 candidate.configure(live,14,1,2,2)
 mu=candidate.mu;mu.mem_write(g.SI+0x94b,bytes([flag]));mu.mem_write(g.SI+0x90f,bytes([look]))
 mu.mem_write(g.SI+0x49,(tag|(level<<17)|0x1ffff).to_bytes(3,'little'))
 mu.mem_write(g.SI+0xba0,f32(sv))
 # Deliberately disagree with the shot on live ISO, live film and live grain.
 mu.mem_write(U+0xba0,f32(5 if sv>7 else 12));mu.mem_write(U+0x90f,bytes([(look+4)%27]))
 mu.mem_write(U+0x49,(0xc80000|(((level+1)%4)<<17)|0x1ffff).to_bytes(3,'little'))
 before=bytes(mu.mem_read(g.SI,0x1000));p=candidate.call(g.PREPARE);gate=candidate.call(g.GATE)
 ck(bytes(mu.mem_read(g.SI,0x1000))==before,'Captured ISO, film identity and grain preference remain immutable')
 return p,gate

# All nominal ISO values and sub-step values close to400/500 and800/1000
# boundaries use the camera's own EXIF rounding, rather than an invented Sv cutoff.
values=[1,4]+[5+i/3 for i in range(34)]+[7.01,7.15,7.16665,7.1666667,7.16668,7.2,
 8.01,8.15,8.16665,8.1666667,8.16668,8.2,0]
for sv in values:
 iso=captured_iso(sv);size=0 if iso<=400 else 1 if iso<=800 else 2
 observed.append({'capturedSv':struct.unpack('<f',f32(sv))[0],'nativeExifIso':iso,'expectedSize':size})
 for level,live in itertools.product(range(4),(0,1)):
  p,gate=prepare(sv,level,live=live)
  ck((p['p4_enable_type'],p['p6_strength'],p['p8_size'],gate['plan25'])==
    (int(level>0),max(0,level-1),size if level else 0,int(level>0)),
    f'Native ISO{iso}, strength{level}, live{live}: independent ISO size and configured strength')

# Film family / child identity is unrelated to camera ISO. Include every
# installed processing look, notably T-MAX100/400/3200 and all PORTRA variants.
for look,level,sv,live in itertools.product(range(27),range(4),(5,7,7+1/3,8,8+1/3,13),(0,1)):
 iso=captured_iso(sv);size=0 if iso<=400 else 1 if iso<=800 else 2
 p,gate=prepare(sv,level,look,live)
 ck(p['p8_size']==(size if level else 0) and p['p6_strength']==max(0,level-1),
    f'Look{look}/ISO{iso}/level{level}/live{live}: size follows exposure, not film label or live camera state')

# Native processing receives exactly the same3x3 size/strength combinations it
# already supports. This checks downstream parameters, not just the branch.
for size,sv in enumerate((5,7+1/3,8+1/3)):
 for strength in range(3):
  p,_=prepare(sv,strength+1)
  native.configure(0,11,1,size,strength);q=native.call(g.PREPARE)
  ck((p['p4_enable_type'],p['p6_strength'],p['p8_size'])==
     (q['p4_enable_type'],q['p6_strength'],q['p8_size']),
     'Adaptive result matches original native grain preparation for the intended size/strength')

# Missing/invalid exposure values and old/untagged preferences fall back to
# small grain or completely OFF, never a speculative raw-bit interpretation.
for sv,level in itertools.product((float('nan'),float('inf'),-float('inf'),-1.,-0.),range(4)):
 p,gate=prepare(sv,level)
 ck(p['p8_size']==0 and p['p6_strength']==max(0,level-1),'Invalid captured Sv safely uses fine grain and retains requested strength')
for tag,sv in itertools.product((0,0xb40000,0xf80000),(5,9,13)):
 p,gate=prepare(sv,0,tag=tag)
 ck((p['p4_enable_type'],p['p8_size'],gate['plan25'])==(0,0,0),'Legacy untagged settings keep all extra grain OFF')

# OFF remains byte-for-byte native even if strong grain was retained, including
# native image-control styles that intentionally have their own grain effect.
for tone,size,strength,sv in itertools.product((11,13,28),range(3),range(3),(5,9,13)):
 results=[]
 for em in (native,candidate):
  em.configure(0,tone,1,size,strength);em.mu.mem_write(g.SI+0x94b,b'\0')
  em.mu.mem_write(g.SI+0xba0,f32(sv));em.mu.mem_write(g.SI+0x49,(0xce0000|0x1ffff).to_bytes(3,'little'))
  results.append((em.call(g.PREPARE),em.call(g.GATE)))
 ck(all(g.public(results[0][i])==g.public(results[1][i])and results[0][i]['memory']==results[1][i]['memory']for i in(0,1)),
    'Simulation OFF retains original native effect preparation and stage gate for any ISO')

# Prove the inline hook's ABI. Native SvToIso temporarily uses d0,d7 and FPSCR;
# every general/FP register and floating-point status must be restored exactly.
generals=[getattr(A,f'UC_ARM_REG_R{i}')for i in range(13)]+[A.UC_ARM_REG_SP,A.UC_ARM_REG_LR,A.UC_ARM_REG_CPSR]
floating=[getattr(A,f'UC_ARM_REG_D{i}')for i in range(32)]
# Install the memory hook before the first translation in a fresh engine;
# Unicorn can otherwise retain earlier translated memory-access blocks.
candidate=g.Emulator(new);mu=candidate.mu;reads=[]
readhook=mu.hook_add(UC_HOOK_MEM_READ,lambda uc,access,address,size,value,user:reads.append(address))
stop=mu.hook_add(UC_HOOK_CODE,lambda uc,pc,size,user:uc.emu_stop()if pc==0x53701e5c else None)
for sv,level,flags,fpscr in itertools.product((5.,7+1/3,9.,float('nan')),range(4),(0,1),(0,0x01000000,0x00400001,0x00c00000)):
 candidate.configure(1-flags,14,1,2,2);mu=candidate.mu
 mu.mem_write(g.SI+0x94b,bytes([flags]));mu.mem_write(g.SI+0x49,(0xc80000|(level<<17)|0x1ffff).to_bytes(3,'little'))
 mu.mem_write(g.SI+0xba0,f32(sv))
 sidecar['register'](mu,g.SI)
 for i,r in enumerate(generals[:13]):mu.reg_write(r,0x60040000+i*0x100)
 mu.reg_write(A.UC_ARM_REG_R4,g.SI);mu.reg_write(A.UC_ARM_REG_SP,g.STACK);mu.reg_write(A.UC_ARM_REG_LR,g.STOP)
 mu.reg_write(A.UC_ARM_REG_CPSR,0xa8000013)
 for i,r in enumerate(floating):mu.reg_write(r,0x3ff0000000000000+i)
 mu.reg_write(A.UC_ARM_REG_FPSCR,fpscr)
 before=[mu.reg_read(r)for r in generals+floating+[A.UC_ARM_REG_FPSCR]]
 reads.clear();mu.emu_start(0x53701e58,g.STOP,count=10000)
 after=[mu.reg_read(r)for r in generals+floating+[A.UC_ARM_REG_FPSCR]]
 ck(mu.reg_read(A.UC_ARM_REG_PC)==0x53701e5c,'ISO wrapper returns to exact native continuation')
 before[3]=after[3]
 ck(before==after,'ISO wrapper preserves all other ARM/VFP registers, SP, LR, NZCVQ and exact FPSCR')
 ck((g.SI+0xba0 in reads)==bool(flags and level),f'Captured ISO is read only when film grain is active: sv={sv}, level={level}, flags={flags}, fpscr={fpscr:#x}, reads={[hex(a)for a in reads if g.SI<=a<g.SI+0x1000]}')

report={'passed':True,'count':len(checks),'checks':checks,'isoCases':observed,
 'firmwareRtosSha256':hashlib.sha256(new).hexdigest(),'scope':'Actual ARM native EXIF ISO conversion, native grain preparation and stage gate, all27 looks, shot/live disagreement, native OFF equivalence, invalid/legacy fallback, full integer/FP inline ABI. Sensor AE, hardware texture generation and final JPEG appearance are not executed.',
 'hardwareTested':False,'actualAutoAeExecuted':False}
(BASE/'v23-iso-grain-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False))
print('PASS',len(checks),'ISO-adaptive grain, native ISO rounding and ARM/VFP ABI checks')
