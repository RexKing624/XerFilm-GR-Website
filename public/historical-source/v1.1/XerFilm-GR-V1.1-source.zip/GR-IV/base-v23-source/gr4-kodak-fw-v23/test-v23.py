# SPDX-License-Identifier: GPL-2.0-only
"""v10 actual ARM family mapping, icon separation, preview and photo identity.
Native image processing device, texture upload and IFD entry I/O are mocked.
"""
from pathlib import Path
import json,struct,re
BASE8=Path('work/gr4-kodak-fw-v23')
CAT=json.loads((BASE8/'v23-catalog.json').read_text())
# Keep the already verified v7 snapshot/neutral/cache/widget assertions while
# extending every captured look to the new 27-item catalog.
src=(BASE8/'test-v7-refresh-info.py').read_text()
src=src.replace("N=h.Image(str(BASE/'build-v7-c/candidate.bin.rtos'))", "BASE=BASE8\nN=h.Image(str(BASE/'build-v23-a/candidate.bin.rtos'))")
src=src.replace("build-v7-c/candidate.bin.rtos", "build-v23-a/candidate.bin.rtos")
src=src.replace('range(13)', 'range(27)').replace('%13','%27')
src=src.replace('(721+film if film<10 else 733+film-10)', 'CAT["hudIcons"][film]')
exec(compile(src,str(BASE8/'test-v7-refresh-info.py'),'exec'))

from capstone import Cs,CS_ARCH_ARM,CS_MODE_ARM
M=Cs(CS_ARCH_ARM,CS_MODE_ARM)
def bls(a):
 result=[]
 for i in M.disasm(N.rd(a,700),a):
  if int.from_bytes(i.bytes,'little')&0x0f000000==0x0b000000:result.append(int(i.op_str[1:],16))
  if i.mnemonic=='pop' and 'pc' in i.op_str:break
 return result
TABLE=0x53d9f714+10*0x5c
adj_set=N.u32(TABLE+0x28);current=N.u32(TABLE+0x20);count=N.u32(TABLE+0x30)
settings_for_preview=N.u32(N.movw_movt(0x531d6868,0x531d6878)+126*0x4c+0x24)
preview=bls(settings_for_preview)[-1]
menu=N.movw_movt(0x531d6868,0x531d6878)
settings_set=N.u32(menu+126*0x4c+0x24);switch=N.u32(menu+125*0x4c+0x24)
mini=render_fn(N);subtitle=N.u32(TABLE+0x10);draw=N.u32(TABLE+0x18)
assert bls(adj_set)[-1]==settings_set,'Filtered ADJ adapter must call the unchanged stable family adapter'
for look,parent in enumerate(CAT['lookFamilies']):
 e,_=make(str(BASE/'build-v23-a/candidate.bin.rtos'));mu=e.mu;events=[]
 e.stubs[preview]=lambda:events.append(e.byte(S)) or 0
 mu.mem_write(S,bytes([look]));mu.mem_write(FLAG,b'\1')
 ck(e.call(count,(OBJ,))==18,'All seventeen parent families available')
 ck([e.call(current,(OBJ,k)) for k in range(18)]==[int(k==parent+1) for k in range(18)],f'Look {look}: one correct parent')
 e.call(adj_set,(OBJ,parent+1));ck(e.byte(S)==look and not events,f'Look {look}: redraw of same family preserves speed and emits no apply')
 for flag in [0,1,2,255]:
  mu.mem_write(FLAG,bytes([flag]))
  ck(e.call(0x533817f0,(OBJ,10,0))==732,f'Look {look}/{flag}: horizontal FILM icon fixed')
  ck(e.call(0x533817f0,(OBJ,15,0))==233,f'Look {look}/{flag}: native Image Control horizontal icon separate')
 mu.mem_write(FLAG,b'\1');ck(e.call(0x53397450,(OBJ,11))==CAT['hudIcons'][look],f'Look {look}: shooting HUD uses precise speed icon')
 mu.mem_write(FLAG,b'\0');ck(e.call(0x53397450,(OBJ,11))==366,f'Look {look}: OFF restores native Std HUD')
 ck(e.call(0x53380fac,(OBJ,11,0))==366,f'Look {look}: native shared style icon untouched')
 for family,details in enumerate(CAT['families']):
  mu.mem_write(S,bytes([look]));mu.mem_write(FLAG,b'\1');events.clear();e.call(adj_set,(OBJ,family+1))
  expected=look if family==parent else details['first']
  ck(e.byte(S)==expected,f'Look {look} to family {family}: preserve same family or default first child')
  ck(events==([expected] if expected!=look else []),f'Look {look} to family {family}: preview notified exactly on change')
for family,details in enumerate(CAT['families']):
 e,_=make(str(BASE/'build-v23-a/candidate.bin.rtos'));mu=e.mu;events=[]
 mu.mem_write(OBJ+0x164,struct.pack('<I',0x70700000));mu.mem_write(OBJ+0x1f8,struct.pack('<I',0x70710000))
 e.stubs[mini]=lambda:0;e.stubs[0x5357338c]=lambda:events.append(('subtitle',mu.reg_read(UC_ARM_REG_R1))) or 0;e.stubs[0x535899fc]=lambda:0
 e.call(subtitle,(OBJ,family+1));ck(events==[('subtitle',846+family)],f'Family {family}: one English-only header label')
 ck(h.text(N,2,846+family)==details['name'],f'Family {family}: subtitle catalog has expected exact English name')
 events.clear();e.stubs[0x53570a9c]=lambda:0x70720000;e.stubs[0x5357dd98]=lambda:events.append(('icon',mu.reg_read(UC_ARM_REG_R1))) or 0;e.stubs[0x5357de6c]=lambda:events.append(('label',mu.reg_read(UC_ARM_REG_R1))) or 0
 e.call(draw,(OBJ,family+1));ck(events==[('icon',details['icon'])],f'Family {family}: parent strip uses only packaging family icon')
for i,label in enumerate(CAT['childLabels']):
 for lang in [0,2,19,20]:ck(h.text(N,lang,863+i)==label,f'Child label {i}/{lang} exactly {label}')
for code in range(721,752):
 p=N.u32(h.ICON_CATALOG+code*4);ck(struct.unpack('<4H',N.rd(p,8))==(1,40,40,0),f'40x40 native icon resource {code}')
# Every new selection participates in each processor's native full-dirty gate.
e,_=make(str(BASE/'build-v23-a/candidate.bin.rtos'));mu=e.mu
for look in range(27):
 mu.mem_write(S,bytes([look]));mu.mem_write(FLAG,b'\1');mu.mem_write(OBJ+0x20e,b'\xff\xff');mu.mem_write(OBJ+0x20d,b'\0')
 mu.reg_write(UC_ARM_REG_R4,OBJ);mu.reg_write(UC_ARM_REG_R0,0x70050000);mu.reg_write(UC_ARM_REG_SP,0x600f0000);step(e,0x5391268c)
 ck(mu.reg_read(UC_ARM_REG_R1)==1 and struct.unpack('<H',mu.mem_read(OBJ+0x20e,2))[0]==0x100+look,f'New look {look}: processor identity invalidates native parameter cache')
assert N.rd(0x53380fac,0x548)==O.rd(0x53380fac,0x548),'Shared native Image Control resolver must remain byte-for-byte original'
(BASE/'v23-checks.json').write_text(json.dumps({'status':'passed','checks':checks,'functions':{'preview':preview,'miniRender':mini},'hardwareTested':False,'scope':'Actual ARM family adapters, 27-look processing invalidation, photo snapshot metadata round trip, native INFO widget, fixed ADJ versus shooting HUD icons. Physical ISP, IFD entry I/O and texture hardware remain stubs.'},ensure_ascii=False,indent=2))
print('PASS',len(checks),'v10 catalog, state, metadata and native INFO assertions')
