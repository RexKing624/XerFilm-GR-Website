.syntax unified
.arm
.fpu neon-vfpv4
.text
vmrs r1, fpscr
vmsr fpscr, r1
vpush {d0}
vpush {d7}
vmov s0, r3
vpop {d7}
vpop {d0}
vpush {d16-d31}
vpop {d16-d31}
vmov s31, r12
vmrsne r10, fpscr
