"""Read-only proof of GR IV captured Sv -> EXIF ISO, including its lookup.
No sensor, AE algorithm, or pixel engine is emulated.
"""
from pathlib import Path
import importlib.util,struct,json,hashlib
ROOT=Path(__file__).resolve().parents[3]
spec=importlib.util.spec_from_file_location('grain_probe',ROOT/'work/gr4-fuji-fw-v2/audit-grain/check_grain.py')
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
data=(ROOT/'work/filter-analysis/RTOS.bin').read_bytes();em=g.Emulator(data);mu=em.mu
rows=[]
lookup=struct.unpack_from('<52I',data,0x53fe607c-0x53000000)
assert lookup[12]==100 and lookup[18]==400 and lookup[21]==800
for sv in [1,4,5,5+1/3,5+2/3,6,6+1/3,6+2/3,7,7+1/3,7+2/3,8,8+1/3,9,10,11,12,13,14,15,16]:
 em.configure(0,11,1,0,0)
 # Native EXIF object's capture context and ordinary-still mode.
 mu.mem_write(g.CONTEXT+4,struct.pack('<I',0x60030000))
 mu.mem_write(0x60030004,struct.pack('<I',0x60031000))
 mu.mem_write(0x60031144,struct.pack('<I',0))
 mu.mem_write(g.CONTEXT+8,struct.pack('<I',g.SI))
 mu.mem_write(g.SI+0xba0,struct.pack('<f',sv))
 # Mark the standard conversion singleton as already boot-initialized.
 mu.mem_write(0x553a0a6c,struct.pack('<I',1))
 result=em.call(0x537fe310)['return']
 expected=lookup[min(51,max(0,int((sv-1)*3+.5)))]
 assert result==expected,(sv,result,expected)
 rows.append({'capturedSv':sv,'nativeExifIso':result,'expectedIso':expected})
assert data[0x537fe338-0x53000000:0x537fe33c-0x53000000]==struct.pack('<I',0xe2833eba)
report={'passed':True,'rtosSha256':hashlib.sha256(data).hexdigest(),'source':'capture snapshot +0xba0 float32 APEX Sv',
 'nativeExifGetter':'0x537fe310','sourceLoad':'0x537fe338/0x537fe33c',
 'nativeSvToIso':'0x538f5568','isoLookup':'0x53fe607c',
 'independentProcessingConsumer':'0x5370484c..0x53704868 copies same captured Sv to processing parameters',
 'autoIsoBoundary':'Uses resolved shot Sv, without reading an Auto/manual ISO selection field. Real AE/sensor operation not executed.',
 'cases':rows,'hardwareTested':False}
(Path(__file__).parent/'source-proof.json').write_text(json.dumps(report,indent=2))
print('PASS',len(rows),'native capture-Sv to EXIF-ISO cases')
