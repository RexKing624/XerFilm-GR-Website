# SPDX-License-Identifier: GPL-2.0-only
# Native popup views execute in ARM emulation; display/camera hardware is stubbed.
from pathlib import Path
import os
TASK_BASE=Path(__file__).resolve().parent
os.chdir(TASK_BASE.parent.parent)
exec((TASK_BASE/'emu-v6.py').read_text())
BASE=TASK_BASE
path=os.environ.get('GR10_RTOS',str(BASE/'build-v23-a/candidate.bin.rtos'));e,draws=make(path);mu=e.mu;img=h.Image(path);frees=[]
for a in [0x538e09ec,0x538e0a60]:e.stubs[a]=lambda:frees.append(mu.reg_read(UC_ARM_REG_R0)) or 0
e.stubs[0x538ee49c]=lambda:e.calls.append(('ASSERT',hex(mu.reg_read(UC_ARM_REG_LR)))) or 0 if not mu.reg_read(UC_ARM_REG_R0) else 0
e.stubs[0x5323bddc]=lambda:0x707b0400;e.stubs[0x5323dbf0]=lambda:40;e.stubs[0x5323dc10]=lambda:40
desc=0x707f0000

def create(kind,x,y,w,ht):
 mu.mem_write(desc,struct.pack('<6I',kind,x,y,w,ht,0));return e.call(0x53589ee4,(desc,))
root=create(1,0,0,720,480);mu.mem_write(OBJ+0x15c,struct.pack('<I',root))
main=create(13,620,60,100,360);mu.mem_write(OBJ+0x1f8,struct.pack('<I',main));types=0x707e0000;mu.mem_write(types,bytes([25])*18)
e.call(0x5357094c,(main,types,18,58));e.call(0x53588158,(root,main));render=render_fn(img)

def family(n,look):
 e.call(0x53571788,(main,n+1));mu.mem_write(S,bytes([look]));e.call(render,(OBJ,n));return e.u32(OBJ+0x294)
def panel_items(panel,n):return [e.call(0x53570a9c,(panel,i)) for i in range(n)]
def labels(items):return [struct.unpack('<H',mu.mem_read(e.u32(i+0xf4)+0xea,2))[0] for i in items]
p=family(11,13);items=panel_items(p,7)
ck(e.byte(p+0x108)==7 and (e.u32(p+0xf8)-e.u32(p+0xf4))==28,'PORTRA has exactly seven native rows without duplicates')
ck(labels(items)==list(range(866,873)),'All seven PORTRA numeric/NC/VC strings assigned in order')
ck(struct.unpack('<4i',mu.mem_read(p+0x20,16))==(472,60,140,360),'PORTRA native viewport clamps at six visible rows')
mu.mem_write(OBJ+0x2a0,b'\1');mu.mem_write(OBJ+0x2a4,b'\x0d');mu.mem_write(S,b'\x13');e.call(render,(OBJ,11))
ck(e.u32(p+0x114)>=60,'Native list scrolls to seventh PORTRA row')
ck(e.call(0x535894c0,(items[6],))==1,'PORTRA800 seventh native row is visible after scroll')
ck([e.byte(i+0x101) for i in items]==[0,0,0,0,0,0,1],'Seventh row receives native selection highlight')
ck([e.call(0x535894c0,(e.u32(i+0xec),)) if e.u32(i+0xec) else 0 for i in items]==[1,0,0,0,0,0,0],'Preview cursor independent of one committed mark')
q=family(16,20);qitems=panel_items(q,3)
ck(q!=p and p not in frees and not any(i in frees for i in items),'Changing family retains old popup and all rows until controller close')
ck(e.byte(q+0x108)==3 and e.u32(q+0xf8)-e.u32(q+0xf4)==12,'VISION3 creates exactly three rows')
ck(labels(qitems)==[873,874,875],'VISION3 50D/250D/500T strings assigned')
ck(e.byte(OBJ+0x2a0)==0 and e.byte(S)==20,'Mother family change clears focus without restoring old PORTRA selection')
r=family(10,10);ck(r!=q and labels(panel_items(r,3))==[863,864,865] and labels(qitems)==[873,874,875],'TMAX and VISION3 retain independent label objects')
mu.mem_write(OBJ+0x2a0,b'\1');mu.mem_write(OBJ+0x2a4,b'\x0a');family(0,0)
ck(e.byte(S)==0 and all(e.call(0x535894c0,(x,))==0 for x in [p,q,r]),'Leaving child family preserves new mother film and hides popup')
# Exercise real scoped key hook with native cursor and independent popup; camera commit is stubbed.
def branch(a):
 w=img.u32(a);n=w&0xffffff;n=n-0x1000000 if n&0x800000 else n;return a+8+n*4
key=branch(0x531bf834);event=0x707d0000;e.stubs[0x531bd580]=lambda:10;e.stubs[0x531bf38c]=lambda:0
e.stubs[0x5323f018]=lambda:0x70740000;e.stubs[0x5329789c]=lambda:0
e.stubs[0x532b6f80]=lambda:0
family(11,13)
def press(k):
 mu.mem_write(event,struct.pack('<H',k));return e.call(key,(OBJ,event))
press(0xd4);ck(e.byte(OBJ+0x2a0)==1 and e.byte(OBJ+0x2a4)==13,'PORTRA Left snapshots current variant and focuses child')
for i in range(8):press(0xd7)
ck(e.byte(S)==19,'PORTRA Down reaches and clamps at800')
press(0xd5);ck(e.byte(S)==13 and e.byte(OBJ+0x2a0)==0,'FirstRight cancels child and restores entry look')
press(0xd4)
for i in range(6):press(0xd7)
press(0xe0);ck(e.byte(S)==19 and e.byte(OBJ+0x2a0)==0,'ChildOK commits800 and returns to parent without closing ADJ')
family(16,20);press(0xd4);press(0xd7);press(0xd7);press(0xd7)
ck(e.byte(S)==22,'VISION3 reaches and clamps at500T')
press(0xd6);ck(e.byte(S)==21,'VISION3 Up previews250D');press(0xd5);ck(e.byte(S)==20,'VISION3 Right rolls back50D')
ck(not [c for c in e.calls if c[0] in ('ASSERT','NULL-JUMP')],'Native popup paths complete without failed assertions or null jumps')
# Repeated fast traversal never replaces a native popup or its rows.
cache={10:r,11:p,16:q};look_first={10:10,11:13,16:20}
for n in [10,11,16]:
 for look in range(look_first[n],look_first[n]+(7 if n==11 else 3)):
  family(n,look)
# Warm native dirty/layout state once; constructors and text labels are now stable.
family(0,0);heap_after_warm=e.heap[0];frees_after_warm=len(frees)
sequence=[(10,10),(11,13),(12,24),(16,20),(15,26),(11,19),(10,12),(0,0),(16,22),(9,9)]
transitions=0
for cycle in range(30):
 for n,look in sequence:
  active=family(n,look);transitions+=1
  if n in cache:
   assert active==cache[n],f'Popup identity changed at {cycle}/{n}'
   assert e.call(0x535894c0,(active,))==1
   assert all(e.call(0x535894c0,(other,))==0 for f,other in cache.items() if f!=n)
  else:assert all(e.call(0x535894c0,(other,))==0 for other in cache.values())
ck(len(frees)==frees_after_warm,'300 rapid parent traversals cause no native view frees')
ck(e.heap[0]==heap_after_warm,'300 rapid parent traversals cause no additional heap allocation after warmup')
ck(all(family(n,look_first[n])==ptr for n,ptr in cache.items()),'Every family keeps the identical popup through rapid traversals')
ck([e.u32(OBJ+0x2a8+4*k) for k in range(3)]==[r,p,q],'Controller owns three distinct cached panels')
ck(e.byte(p+0x108)==7 and e.byte(q+0x108)==3 and e.byte(r+0x108)==3,'Fast traversal never appends or duplicates child rows')
# Filtered ADJ positions must be converted back to stable family identities.
mu.mem_write(0x55084dd8+4+0x49,(0xb40000|(1<<10)|(1<<11)|(1<<16)).to_bytes(3,'little'))
queried=[]
query_hook=mu.hook_add(UC_HOOK_CODE,lambda uc,pc,size,ud:queried.append(uc.reg_read(UC_ARM_REG_R1)) if pc==0x53570a9c and uc.reg_read(UC_ARM_REG_R0)==main else None)
e.call(0x53571788,(main,3));mu.mem_write(S,b'\x14');e.call(render,(OBJ,16))
mu.hook_del(query_hook)
ck(e.u32(OBJ+0x294)==q,'Filtered ADJ row2 reuses stable VISION3 popup, not ASTIA')
ck(queried and queried[-1]==3,'Child popup resolves geometry from compact ADJ row2, not stable family16')
press(0xd4);press(0xd7);ck(e.byte(S)==21,'Filtered row2 Left/Down changes VISION3 speed rather than another family')
press(0xd5);ck(e.byte(S)==20,'Filtered VISION3 cancel returns to the captured child speed')
e.call(0x53571788,(main,2));mu.mem_write(S,b'\x0d');e.call(render,(OBJ,11));press(0xd4)
for i in range(6):press(0xd7)
press(0xe0);ck(e.byte(S)==19,'Filtered row1 keeps all seven PORTRA variants and confirms800')
# Stop only the original destructor continuation: run our own real cleanup first.
def stop_original():
 mu.reg_write(UC_ARM_REG_PC,0x100);mu.emu_stop();return 0
stop_hook=mu.hook_add(UC_HOOK_CODE,lambda uc,pc,size,ud:stop_original() if pc==0x531ba1c4 else None)
freed_before=len(frees);e.call(branch(0x531ba1c0),(OBJ,));mu.hook_del(stop_hook)
new_frees=frees[freed_before:]
ck(all(new_frees.count(ptr)==1 for ptr in cache.values()),'ADJ teardown destroys each owned popup exactly once')
ck(all(e.u32(OBJ+off)==0 for off in [0x294,0x298,0x29c,0x2a0,0x2a8,0x2ac,0x2b0]),'Teardown clears active alias and all cached ownership slots')
ck(not [c for c in e.calls if c[0] in ('ASSERT','NULL-JUMP')],'Fast traversal and controller teardown complete without native assertion or null jump')
(BASE/'v23-popup-checks.json').write_text(json.dumps({'status':'passed','passed':len(checks),'transitions':transitions,'heapGrowthAfterWarmup':e.heap[0]-heap_after_warm,'checks':checks,'hardwareTested':False,'scope':'Actual native three-popup lifetime, row visibility and scrolling, 300 rapid family transitions without view frees or heap allocation, key transactions, and exactly-once cleanup. Display device and concurrent draw queue timing remain unmodelled.'},ensure_ascii=False,indent=2))
print('PASS',len(checks),'popup checks;',transitions,'rapid transitions; no heap growth or premature frees')
