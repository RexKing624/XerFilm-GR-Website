# SPDX-License-Identifier: GPL-2.0-only
"""Compile a freestanding ARM object with Clang; resolve only local ARM CALLs.
No runtime/library dependencies, writable globals, rodata or other relocations
are permitted. The minimal ELF32 resolver is intentionally restricted to this
module. Linked at two origins and compared before emitting the TS payload.
"""
from pathlib import Path
import base64,hashlib,json,struct,subprocess
HERE=Path(__file__).resolve().parent
SRC=HERE/'film-stamp.c'
OUT=HERE.parent/'core/src/fw/aspect/film-stamp-code.ts'
FLAGS=['-target','armv7-none-eabi','-mcpu=cortex-a9','-marm','-mfloat-abi=soft','-Os','-ffreestanding','-fno-builtin','-fno-unwind-tables','-fno-asynchronous-unwind-tables','-nostdlib','-fropi','-frwpi','-fno-jump-tables','-Wall','-Wextra','-Werror']
def resolve(blob,origin):
 assert blob[:7]==b'\x7fELF\x01\x01\x01'
 assert struct.unpack_from('<H',blob,18)[0]==40
 off=struct.unpack_from('<I',blob,32)[0];num,strings=struct.unpack_from('<HH',blob,48)
 sections=[struct.unpack_from('<10I',blob,off+40*i) for i in range(num)]
 h=sections[strings];names=blob[h[4]:h[4]+h[5]]
 name=lambda h:names[h[0]:].split(b'\0',1)[0].decode()
 sec={name(h):(i,h) for i,h in enumerate(sections)}
 for n,(i,h) in sec.items():
  if n.startswith(('.rodata','.data','.bss','.got')):assert h[5]==0,n
 ti,t=sec['.text'];code=bytearray(blob[t[4]:t[4]+t[5]])
 _,sy=sec['.symtab'];st=sections[sy[6]];sn=blob[st[4]:st[4]+st[5]]
 syms=[struct.unpack_from('<IIIBBH',blob,sy[4]+i) for i in range(0,sy[5],16)]
 entries=[x for x in syms if sn[x[0]:].split(b'\0',1)[0]==b'datestamp']
 assert len(entries)==1 and entries[0][1]==0 and entries[0][-1]==ti
 relocs=[]
 for i,h in enumerate(sections):
  if h[1]!=9 or h[7]!=ti:continue
  for j in range(0,h[5],8):
   at,info=struct.unpack_from('<II',blob,h[4]+j);typ=info&255;sym=syms[info>>8]
   assert typ in (28,29) and sym[-1]==ti,('unsupported/extern relocation',typ,sym)
   old=struct.unpack_from('<I',code,at)[0];imm=old&0xffffff;imm=imm-0x1000000 if imm&0x800000 else imm
   # S + A - P. ARM branch PC bias is already in the compiler's A (-8).
   delta=(origin+sym[1])+(imm<<2)-(origin+at)
   assert delta%4==0 and -(1<<25)<=delta<(1<<25)
   struct.pack_into('<I',code,at,(old&0xff000000)|((delta>>2)&0xffffff));relocs.append({'offset':at,'target':sym[1],'type':typ})
 while len(code)%4:code+=b'\0'
 symbols={sn[v[0]:].split(b'\0',1)[0].decode():v[1]for v in syms if v[-1]==ti and v[0]}
 return bytes(code),relocs,symbols
obj=HERE/'film-stamp.o'
subprocess.run(['clang',*FLAGS,'-c',str(SRC),'-o',str(obj)],check=True)
a,rels,symbols=resolve(obj.read_bytes(),0x10000);b,_,_=resolve(obj.read_bytes(),0x543f0000)
assert a==b
source=hashlib.sha256(SRC.read_bytes()).hexdigest()
OUT.write_text('// SPDX-License-Identifier: GPL-2.0-only\n// Generated from stamp-research/film-stamp.c by stamp-research/gen.py.\n'+f"export const FILM_STAMP_SOURCE_SHA256='{source}';\nexport const FILM_STAMP_CODE_LENGTH={len(a)};\nexport const FILM_STAMP_CODE='{base64.b64encode(a).decode()}';\n")
(HERE/'module-proof.json').write_text(json.dumps({'passed':True,'compiler':subprocess.check_output(['clang','--version'],text=True).splitlines()[0],'bytes':len(a),'sourceSha256':source,'codeSha256':hashlib.sha256(a).hexdigest(),'origins':[0x10000,0x543f0000],'positionIndependent':True,'localRelocations':rels,'symbols':symbols},indent=2))
(HERE/'film-stamp.bin').write_bytes(a)
print('Generated',len(a),'bytes; position independent at two origins;',len(rels),'local relocations')
