# SPDX-License-Identifier: GPL-2.0-only
"""Execute the actual native processing-job handoff and configuration builder.
No private bytes are planted into ShotInfo. RAW/native record memory is guarded.
"""
from pathlib import Path
import os,struct,json,itertools,re
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent.parent
os.chdir(ROOT);exec((HERE/'emu-v6.py').read_text(),globals());BASE=HERE;checks=[]
exec((HERE/'capture-event-fixture.py').read_text(),globals())
from unicorn import arm_const as A
from unicorn import UC_HOOK_CODE
N=h.Image(str(BASE/'build-v23-a/candidate.bin.rtos'));O=h.Image('work/filter-analysis/RTOS.bin');V=h.Image(str(BASE.parent/'gr4-kodak-fw-v17/build-v17-a/candidate.bin.rtos'))
new,_=make(str(BASE/'build-v23-a/candidate.bin.rtos'));v17=h.Emu(V)
U=0x55084dd8+4;SI=0x60010000;CTX=0x60001000;PAR=0x60002000;JOB=0x70010000;BIND=0x537119a0
M=Cs(CS_ARCH_ARM,CS_MODE_ARM)
def ck(ok,s):
 if not ok:raise AssertionError(s)
 checks.append(s)
def branch(a):
 w=N.u32(a);n=w&0xffffff;n=n-0x1000000 if n&0x800000 else n;return a+8+n*4
def calls(a):
 out=[]
 for i in M.disasm(N.rd(a,1500),a):
  if int.from_bytes(i.bytes,'little')&0x0f000000==0x0b000000:out.append(int(i.op_str[1:],16))
  if i.mnemonic=='pop'and'pc'in i.op_str:break
 return out
lookup=calls(branch(0x537150fc))[0]
def bind(e,flag,mode,level,look,si=SI):
 m=e.mu;m.mem_write(si,b'\0'*0x1000);m.mem_write(si+0x79c,b'\x0b')
 for off in(0x79d,0x79e,0x79f,0x7a0,0x7a1,0x7a2,0x7a4,0x7b3,0x7b4):m.mem_write(si+off,b'\x04')
 # Only live settings have private film flags; ShotInfo has no such data.
 m.mem_write(U+0x94b,bytes([flag]));m.mem_write(U+0x90f,bytes([look]));m.mem_write(U+0x49,(0x400000|mode<<19|level<<17|0x15555).to_bytes(3,'little'))
 native=bytes(m.mem_read(si,0x1000));source=bytes(m.mem_read(U,0x1000));latch(e,si);e.call(BIND,(JOB,0x1234,si))
 ck(e.u32(JOB+0x4688)==si and e.u32(JOB+0x60)==0x1234,'Actual native BindShotInfo retains original job fields')
 ck(bytes(m.mem_read(si,0x1000))==native and bytes(m.mem_read(U,0x1000))==source,'Native handoff never writes ShotInfo, camera settings or RAW/native metadata')
 return native
# Reproduce the reported failure usingv17's real handoff: live preferences are
# ON but the native immutable shot record never inherited the user's padding.
for e in(v17,new):
 bind(e,1,1,3,12);m=e.mu;m.mem_write(CTX,b'\0'*0x100);m.mem_write(PAR,b'\0'*0x100);m.mem_write(CTX+0x10,struct.pack('<I',PAR))
 e.call(0x53701c40,(CTX,SI,1));e.call(0x537150fc,(CTX,SI))
 got=(e.byte(PAR+4),e.byte(CTX+0x25))
 ck(got==((0,0)if e is v17 else(1,1)),f'Real native handoff: {"v17 reproduces missing grain"if e is v17 else"v18 enables native grain"}, {got}')
# Strength/ISO matrix after genuine native handoff, with no privateSI fields.
for flag,mode,level,look in itertools.product((0,1),range(6),range(4),(0,12,19,22,26)):
 before=bind(new,flag,mode,level,look);m=new.mu
 expected=(0x400000|mode<<19|level<<17|0x15555)|(look<<24)|(0x80000000 if flag else 0)
 ck(new.call(lookup,(SI,))==expected,'Render-job sidecar contains exactly captured Film state, format and grain')
 # Live UI can change after handoff; captured job remains immutable.
 m.mem_write(U+0x94b,bytes([1-flag]));m.mem_write(U+0x49,(0x400000|((mode+1)%6)<<19|((level+1)%4)<<17|1).to_bytes(3,'little'))
 for sv,size in((5.,0),(7+1/3,1),(8+1/3,2)):
  m.mem_write(SI+0xba0,struct.pack('<f',sv));shot=bytes(m.mem_read(SI,0x1000));m.mem_write(CTX,b'\0'*0x100);m.mem_write(PAR,b'\0'*0x100);m.mem_write(CTX+0x10,struct.pack('<I',PAR))
  new.call(0x53701c40,(CTX,SI,1));new.call(0x537150fc,(CTX,SI))
  got=(new.byte(PAR+4),struct.unpack('<H',m.mem_read(PAR+6,2))[0],struct.unpack('<H',m.mem_read(PAR+8,2))[0],new.byte(CTX+0x25))
  want=(int(level>0),max(0,level-1),size if level else 0,int(level>0))if flag else(0,0,0,0)
  ck(got==want,f'Actual captured job reaches native grain: flag{flag},mode{mode},level{level},Sv{sv},got{got}')
  ck(bytes(m.mem_read(SI,0x1000))==shot,'Effect preparation never rewrites native shot/RAW metadata fields')
# Native constructor-entry wrapper independently freezes its ShotInfo argument,
# while exactly preserving native prologue ABI. The rest of ctor services are
# outside this bounded test and are not represented as emulated here.
m=new.mu
bind(new,1,1,1,0);native=bytes(m.mem_read(SI,0x1000));m.mem_write(U+0x49,(0x400000|5<<19|3<<17|7).to_bytes(3,'little'))
regs=[getattr(A,f'UC_ARM_REG_R{i}')for i in range(13)]+[A.UC_ARM_REG_SP,A.UC_ARM_REG_LR,A.UC_ARM_REG_CPSR]
for i,r in enumerate(regs[:13]):m.reg_write(r,0x70010000+i*0x100)
m.reg_write(A.UC_ARM_REG_R1,SI);m.reg_write(A.UC_ARM_REG_SP,0x600f0000);m.reg_write(A.UC_ARM_REG_LR,0x100);m.reg_write(A.UC_ARM_REG_CPSR,0xa8000013)
a=[m.reg_read(r)for r in regs];m.emu_start(0x5370fecc,0x5370fed0,count=10000);b=[m.reg_read(r)for r in regs];a[12]=a[13]
ck(a==b and bytes(m.mem_read(SI,0x1000))==native,'Constructor wrapper restores all ARM registers/NZCV and never modifies shot memory')
ck((new.call(lookup,(SI,))>>19)&7==1,'Preallocated constructor cannot replace captured date mode with later UI settings')
# Produce JPEG configuration with actual native instructions, then render using
# its actual capturedShotInfo pointer. Shared RAW/preview buffers are sentinels.
new,_=make(str(BASE/'build-v23-a/candidate.bin.rtos'));m=new.mu
CODE=calls(branch(0x537034b4))[0];K=0x70004000;Y=0x70800000;C=0x70900000;W,H,STRIDE=640,426,672;CFG=JOB+0xb60
proof=json.loads((BASE/'stamp-research/module-proof.json').read_text());layout=CODE+proof['symbols']['layout'];glyphs=[];clock_calls=[]
new.stubs[0x538f0448]=lambda:0x553a09c4;new.stubs[0x538f04d8]=lambda:0;new.stubs[0x538f04c4]=lambda:0;new.stubs[0x538f21a0]=lambda:0x70001000
m.mem_write(0x70001004,struct.pack('<I',0x70002000));CLOCK=(2000,1,2,3,4,0)
def clock():clock_calls.append(1);m.mem_write(m.reg_read(A.UC_ARM_REG_R1),struct.pack('<HBBBBB',*CLOCK));return 0
new.stubs[0x538ea9b0]=clock
m.mem_write(K,struct.pack('<6I',0x538f0448,0x538f04d8,0x538f04c4,0x538f21a0,0x538ea9b0,lookup))
m.hook_add(UC_HOOK_CODE,lambda uc,at,size,ud:glyphs.append(bytes(uc.mem_read(uc.reg_read(A.UC_ARM_REG_R0),uc.reg_read(A.UC_ARM_REG_R1)))),begin=layout,end=layout)
for flag,mode in itertools.product((0,1),range(6)):
 before=bind(new,flag,mode,3,12);glyphs.clear();clock_calls.clear();m.mem_write(Y,bytes([70])*(STRIDE*H));m.mem_write(C,bytes([120,140])*(STRIDE*H//2))
 main=struct.pack('<B3xIII HHHH HH 4x',1,Y,C,0,W,H,STRIDE,H,0,0);m.mem_write(JOB+0xb0,main)
 # Native0x5370F7C0..818 fills the process configuration from this job.
 m.reg_write(A.UC_ARM_REG_R4,JOB);m.emu_start(0x5370f7c0,0x5370f818,count=50)
 ck(new.u32(CFG+0x34)==SI and new.u32(CFG+0x3c)==JOB+0xb0,'Original JPEG config builder references the actual native job and main picture')
 m.mem_write(U+0x94b,bytes([1-flag]));m.mem_write(U+0x49,(0x400000).to_bytes(3,'little'))
 photo=bytes(m.mem_read(Y,STRIDE*H));new.call(CODE,(K,CFG),limit=100_000_000)
 ck(bool(glyphs)==bool(flag and mode),'Actual handoff→native JPEG config→compiled stamp honours captured preferences despite changed live UI')
 ck((bytes(m.mem_read(Y,STRIDE*H))!=photo)==bool(flag and mode),'Actual JPEG main pixels change only when captured Film/timestamp enabled')
 ck(bytes(m.mem_read(SI,0x1000))==before,'JPEG stamping never writes the native shot/RAW metadata record')
 if flag and mode==5:
  text=lambda g:''.join(str(x)if x<10 else{17:' ',18:'.',19:':'}.get(x,'?')for x in g)
  ck([text(g)for g in glyphs]==['00.01.02']*2+['03:04']*2,'Two-line actual capture prints date then time; year2000 is00')
# Bounded storage: many sequential/reused jobs and unknown keys fail closed.
for i in range(260):
 key=0x60020000+i*0x1000;latch(new,key);new.call(BIND,(JOB,0,key));ck(new.call(lookup,(key,))!=0,'Sidecar ring handles sequential captures without allocation')
ck(new.call(lookup,(0,))==0 and new.call(lookup,(0x601ff000,))==0,'Null and unknown jobs cannot receive another shot\'s settings')
# Shared metadata writer stays exact original. Native capture metadata reads
# remain native too; old film-tagged photos retain backwards-compatible reads.
ck(N.rd(0x537de474,0x150)==O.rd(0x537de474,0x150),'Shared JPEG/DNG ImageTone writer is byte-for-byte original, no new private8200 tag')
rows=json.loads(re.search(r'=(\[.*\]) as const',(BASE/'core/src/fw/aspect/film-neutral-reads.ts').read_text()).group(1))
for r in rows:
 if r['snapshot']:ck(N.u32(r['address'])==O.u32(r['address']),f'Capture/RAW metadata read{r["address"]:#x} remains native')
report={'passed':True,'count':len(checks),'checks':checks,'hardwareTested':False,'rootCause':'User-record padding is not part of native ShotInfo. v17 read an invented copy. Actual v17 native BindShotInfo reproduces missing grain;v23 freezes preferences at per-exposure date/identity entry; native preallocation and bind never resnapshot.','scope':'Real native BindShotInfo, native JPEG configuration instruction sequence, native grain preparation and stage gate, actual compiled timestamp pixels. Constructor ENTRY ABI only; full constructor services, JPEG codec and sensor/DSP not executed.','rawBoundary':'No native ShotInfo/user record writes at registration or effects; shared DNG metadata writer/read sites remain original. Timestamp ignores shared previews; physical RAW+JPEG files require camera verification.'}
(BASE/'v23-capture-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('PASS',len(checks),'native job handoff, reproducedv17 failure, grain/stamp chain and RAW metadata boundaries')
