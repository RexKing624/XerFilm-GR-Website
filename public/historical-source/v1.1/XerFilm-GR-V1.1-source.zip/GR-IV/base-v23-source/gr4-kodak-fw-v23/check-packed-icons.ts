import{readFileSync,writeFileSync}from'node:fs';import{createHash}from'node:crypto';import{Firmware,sectionsOf}from'./core/src/fw/container';
import{gridIcon,FILM_GRID_ICON_FIRST}from'./core/src/fw/aspect/film-grid';
import{FILM_ICONS,FILM_FIRST_ICON,FILM_ENTRY_ICON}from'./core/src/fw/aspect/film-catalog';
const raw=new Uint8Array(readFileSync('build-v23-a/candidate.bin'));const d=new Firmware(raw).decoded;const sections=sectionsOf(d);const r=sections.find(s=>s.name==='RTOS')!,icons=sections.find(s=>s.name==='ICONBIN')!;
const word=(va:number)=>new DataView(d.buffer).getUint32(r.offset+va-0x53000000,true);
const equal=(a:Uint8Array,b:Uint8Array)=>a.length===b.length&&a.every((v,i)=>v===b[i]);
const checks=[];
for(let k=0;k<FILM_ICONS.length;k++){
 const desc=word(0x543d3ac0+(FILM_FIRST_ICON+k)*4);const start=icons.offset+word(desc+8)*4;const actual=d.slice(start,start+6400);
 if(!equal(actual,FILM_ICONS[k]))throw Error('Packed icon mismatch '+k);checks.push({id:FILM_FIRST_ICON+k,bytes:6400,sha256:createHash('sha256').update(actual).digest('hex')});
}
for(let f=0;f<17;f++)for(const focused of [false,true])for(const on of [false,true]){
 const id=FILM_GRID_ICON_FIRST+f*4+Number(focused)*2+Number(on),desc=word(0x543d3ac0+id*4),start=icons.offset+word(desc+8)*4;
 const actual=d.slice(start,start+164*92*4),expected=gridIcon(f,on,focused);
 const shape=new DataView(d.buffer).getUint32(r.offset+desc-0x53000000,true);
 if(shape!==0x00a40001||new DataView(d.buffer).getUint16(r.offset+desc-0x53000000+4,true)!==92)throw Error('Bad164x92descriptor '+id);
 if(!equal(actual,expected))throw Error('Grid icon mismatch '+id);
 if(!actual.every((v,i)=>i%4!==3||v===255))throw Error('Tile panel has transparent pixels '+id);
 const px=(x:number,y:number)=>Array.from(actual.slice((y*164+x)*4,(y*164+x)*4+4)).join(',');
 if(px(2,2)!==(focused?'255,240,0,255':'46,49,49,255'))throw Error('Missing panel or cursor '+id);
 if(px(0,0)!==(focused?'255,240,0,255':'105,108,108,255'))throw Error('Missing panel edge '+id);
 checks.push({id,bytes:60352,sha256:createHash('sha256').update(actual).digest('hex')});
}
const source=new Uint8Array(readFileSync('../../outputs/SP3000-FILM图标/FILM-40x40.rgba'));
if(!equal(source,FILM_ICONS[FILM_ENTRY_ICON-FILM_FIRST_ICON]))throw Error('FILM icon differs from extracted source');
writeFileSync('packed-icons-check.json',JSON.stringify({status:'passed',checks,fixedFilmEntryExactSource:true},null,2));console.log(`${checks.length} packed icons match; fixed FILM icon matches extracted source byte for byte.`);
