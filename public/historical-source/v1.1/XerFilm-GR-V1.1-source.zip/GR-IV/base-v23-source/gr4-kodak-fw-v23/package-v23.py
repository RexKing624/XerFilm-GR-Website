# SPDX-License-Identifier: GPL-2.0-only
from pathlib import Path
import hashlib,json,shutil,difflib,zipfile
B=Path(__file__).resolve().parent;ROOT=B.parent.parent;OLD=B.parent/'gr4-kodak-fw-v22';OUT=ROOT/'outputs/GR4-INFO逐张身份与子菜单确认-v23'
a=(B/'build-v23-a/candidate.bin').read_bytes();assert a==(B/'build-v23-repro/candidate.bin').read_bytes()
assert (B/'build-v23-a/candidate.bin.rtos').read_bytes()==(B/'build-v23-repro/candidate.bin.rtos').read_bytes()
sha=hashlib.sha256(a).hexdigest();meta=json.loads((B/'build-v23-a/candidate.bin.json').read_text());assert meta['sha256']==sha and meta['features']['revision']==23 and all(meta['checks'].values())
reports={};files=[]
expected_reports={'boot-memory','capture','grain','grid','iso-grain','jpeg-info','off-session','parent-layout','popup','stamp','exposure-order','child-accept'}
expected_files={'v23-checks.json'}|{f'v23-{name}-checks.json' for name in expected_reports}
assert expected_files.issubset({p.name for p in B.glob('v23*checks.json')})
for name in sorted(expected_files):
 p=B/name;q=json.loads(p.read_text());assert q.get('passed')is True or q.get('status')=='passed',p
 reports[name]={'passed':True,'count':q.get('count',len(q.get('checks',[])))};files.append((p,name))
for rel,name in [('audit-color/report.json','颜色资源验证.json'),('packed-icons-check.json','图标封装验证.json'),('iso-research/source-proof.json','ISO来源验证.json')]:
 p=B/rel;q=json.loads(p.read_text());assert not q.get('failures')
 if rel=='audit-color/report.json':assert all(c['pass']for c in q['checks'])
 else:assert q.get('passed')is True or q.get('status')=='passed'
 files.append((p,name))
expected={'core/src/fw/aspect/film-capture.ts','core/src/fw/aspect/film-mini.ts','core/src/fw/aspect/film-session.ts','core/src/fw/aspect/film-metadata.ts'}
changed={str(p.relative_to(B))for p in(B/'core/src').rglob('*.ts')if p.read_bytes()!=(OLD/p.relative_to(B)).read_bytes()};assert changed==expected,changed
for p in (B/'resources').rglob('*'):
 if p.is_file():assert p.read_bytes()==(OLD/p.relative_to(B)).read_bytes()
patch=[]
for rel in sorted(changed):patch.extend(difflib.unified_diff((OLD/rel).read_text().splitlines(True),(B/rel).read_text().splitlines(True),fromfile='v22/'+rel,tofile='v23/'+rel))
limits=['Offline checks do not prove a physical camera boot or sensor/DSP result. Hardware retest required.', 'Actual exposure timing, continuous shooting, camera filesystem/codec and RAW+JPG group member selection need physical validation.', 'Old photos contain already incorrect saved identities. This firmware does not alter or infer their original look.', 'SD card originals were read only. No firmware copied to SD, no camera flashed, no website/download updated.']
assert not OUT.exists(),'Never overwrite delivered output';OUT.mkdir()
(OUT/'fwdc248b.bin').write_bytes(a);(OUT/'SHA256.txt').write_text(sha+'  fwdc248b.bin\n');shutil.copy2(B/'LICENSE',OUT/'LICENSE');(OUT/'v22到v23.patch').write_text(''.join(patch))
for p,name in files:shutil.copy2(p,OUT/name)
shutil.copy2(B/'sample-evidence.json',OUT/'原图只读核对.json')
meta.update(sourceVersion='v23',status='OFFLINE_VALIDATED_HARDWARE_RETEST_PENDING',hardwareTested=False,reproducibleBuild=True,runtimeSourceChanges=sorted(changed),validationReports=reports,limitations=limits)
(OUT/'构建记录.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
(OUT/'验证汇总.json').write_text(json.dumps({'passed':True,'hardwareTested':False,'sha256':sha,'bytes':len(a),'reproducibleBuild':True,'checks':reports,'limitations':limits},ensure_ascii=False,indent=2))
(OUT/'使用说明.txt').write_text('''GR IV 1.11 — INFO逐张身份与子菜单确认 v23

固件：fwdc248b.bin（机内厂商版本号仍是1.11）。本版以v22为基础。

修正1：INFO的胶片图标错后一张
卡中R0000767.JPG是黑白照片，却保存了EKTAR100标识；R0000768.JPG是彩色，却保存T-MAX100。不是单纯回放控件延迟。
旧实现过早在处理任务的预分配/绑定时锁定胶片，因此会把上一张的设置带进下一张。
现在在原生每张照片采集日期/拍摄身份的入口锁定胶片、颗粒和日期设置。之后切换胶片、预分配或再次绑定任务不会覆盖本次信息。
普通JPG仍保存胶片标识；DNG/RAW共享元数据写入器保持原生，新增记录只在独立RAM中，不向RAW补写胶片型号。
旧照片里已经写错的标识不会自动修复，请用更新后新拍照片验证。

修正2：子菜单OK即应用
T-MAX / PORTRA / VISION3子菜单按OK：立即确认所选子型号，再返回母菜单。ADJ保持打开，无需再按母菜单OK。
母菜单的当前标记与该家族同步。随后退出ADJ仍保留选择。
再次进入子菜单改动后按右键取消，会恢复刚才已确认的子型号。
以后浏览其他母菜单但不确认退出，也会恢复最近一次已确认的子型号。
未确认的原有预览/取消行为继续保留。

检查范围
已重现旧版“先准备任务→切换胶片→曝光”错位，并验证修正后的逐张记录、后续UI变化不污染已拍照片。
13个子型号、3个家族分别从胶片开/关进入，执行真实母菜单刷新回调及再次取消检查。
另检查启动RAM边界、ROM只读权限、快速切换、JPG/DNG元数据分离、ISO颗粒、全部日期格式与黑白日期、打包图标、颜色资源。
两次独立构建一致，容器校验与类型检查通过。
这些是本地离线检查，不能代替实机开机与拍摄复测。

建议实机复测
1. 新拍连续三张：T-MAX100 → T-MAX400 → 一款彩色胶片，逐张检查INFO及JPG原图。
2. 从其他胶片进入T-MAX，左键选400、只按一次子菜单OK；返回母菜单后直接退出并拍照，确认400生效。
3. 再进入子菜单选择其他值但按右键取消，确认保持前一次已确认的选择。
4. 胶片OFF、RAW+JPG、颗粒与日期各拍一组核对。
保留用户此前确认能正常启动的版本作为回退。

此处仅提供本地固件，没有写入内存卡、没有刷机、没有替换网站上的下载文件。
源码与验证.zip遵循GPL-2.0-only，不含原厂固件、用户照片和依赖包。
''')
with zipfile.ZipFile(OUT/'源码与验证.zip','w',compression=zipfile.ZIP_DEFLATED)as z:
 paths=[]
 for sub in ('core/src','core/test','resources','stamp-research','iso-research','capture-research'):
  paths.extend(p for p in(B/sub).rglob('*')if p.is_file()and '__pycache__'not in p.parts and p.suffix not in('.o','.bin'))
 paths.extend(B/f for f in ('build.ts','package.json','LICENSE','emu-v6.py','runtime-memory.py','sidecar-fixture.py','capture-event-fixture.py','test-v7-refresh-info.py','check-packed-icons.ts','run-v23-checks.py','v23-catalog.json','virtual-reads.json','package-v23.py'))
 paths.extend((B/'core').glob('*.json'));paths.extend(B.glob('test-v23*.py'));paths.extend((B/'audit-color').glob('*.py'));paths.extend([B/'audit-color/models.json',B/'audit-color/patch-words.json'])
 for p in sorted(set(paths)):z.write(p,'gr4-kodak-fw-v23/'+str(p.relative_to(B)))
 for p in(ROOT/'outputs/GR4-Menu-Experiment/tools/upstream_menu_emu.py',ROOT/'work/gr4-fuji-fw-v2/audit-grain/check_grain.py'):z.write(p,'shared-workspace/'+str(p.relative_to(ROOT)))
 z.writestr('README.txt','GPL-2.0-only. Node dependencies and official GR IV1.11 input required. Python tests use Unicorn/Capstone; historical regressions require local historical builds, not included. No original firmware or personal photographs in this archive.\n')
with zipfile.ZipFile(OUT/'源码与验证.zip')as z:assert z.testzip()is None
assert hashlib.sha256((OUT/'fwdc248b.bin').read_bytes()).hexdigest()==sha
print(json.dumps({'output':str(OUT),'bytes':len(a),'sha256':sha},ensure_ascii=False))
