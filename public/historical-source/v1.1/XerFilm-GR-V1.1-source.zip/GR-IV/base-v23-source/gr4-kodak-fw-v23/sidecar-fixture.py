# SPDX-License-Identifier: GPL-2.0-only
"""UNIT-test bridge only: turn the legacy test's requested preferences into
an actual native BindShotInfo call. Production never reads private SI padding.
The integration test uses live UI preferences directly and no bridge.
"""
from unicorn import arm_const as A
import struct
U=0x55084dd8+4;BIND=0x536651e4;DUMMY=0x60080000;STOP=0x600ff000
REGS=[getattr(A,f'UC_ARM_REG_R{i}')for i in range(13)]+[A.UC_ARM_REG_SP,A.UC_ARM_REG_LR,A.UC_ARM_REG_CPSR]
def register(mu,si):
 fields=(0x49,0x4a,0x4b,0x90f,0x94b);before={o:bytes(mu.mem_read(U+o,1))for o in fields}
 regs=[mu.reg_read(r)for r in REGS]
 for o in fields:mu.mem_write(U+o,bytes(mu.mem_read(si+o,1)))
 for r,v in zip((A.UC_ARM_REG_R0,A.UC_ARM_REG_R1,A.UC_ARM_REG_R2,A.UC_ARM_REG_SP,A.UC_ARM_REG_LR),(0,si,0,0x600f0000,STOP)):mu.reg_write(r,v)
 mu.emu_start(BIND,0x536651e8,count=10000)
 if mu.reg_read(A.UC_ARM_REG_PC)!=0x536651e8:raise AssertionError('Exposure hook did not reach native continuation')
 for o,v in before.items():mu.mem_write(U+o,v)
 for r,v in zip(REGS,regs):mu.reg_write(r,v)
def install(g):
 scope={};exec((__import__('pathlib').Path('work/gr4-kodak-fw-v23/runtime-memory.py')).read_text(),scope)
 original=g.Emulator.__init__
 def initialize(self,image):
  original(self,image);scope['protect_g'](self,image)
 g.Emulator.__init__=initialize
 old=g.Emulator.call
 def call(self,entry):
  if entry in(g.PREPARE,g.GATE):register(self.mu,g.SI)
  return old(self,entry)
 g.Emulator.call=call
