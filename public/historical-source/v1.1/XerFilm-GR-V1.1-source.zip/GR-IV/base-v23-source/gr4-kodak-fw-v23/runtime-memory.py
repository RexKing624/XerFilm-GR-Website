# SPDX-License-Identifier: GPL-2.0-only
"""Test-only boot RAM initialisation, allocator service, and real ROM permissions.
Memory permissions are a mandatory part of every v20 ARM test.
"""
import struct
from unicorn import UC_PROT_READ,UC_PROT_EXEC,UC_HOOK_CODE
from unicorn import arm_const as A
def protect_h(h):
 if getattr(h,'_gr20_rom_protected',False):return
 original=h.Emu.__init__
 def initialize(self,img,*args,**kwargs):
  original(self,img,*args,**kwargs)
  src,dst,n=struct.unpack('<III',img.rd(0x53000450,12))
  self.mu.mem_write(dst,img.rd(src,n))
  size=max((len(img.R)+0xfffff)&~0xfffff,0x1500000)
  self.mu.mem_protect(h.BASE,size,UC_PROT_READ|UC_PROT_EXEC)
  # Boot domain2 allocator exists. Emu's original operator-new/free service
  # stubs supply real bounded RAM; no allocator algorithm is modelled here.
  self.mu.mem_write(0x5539ff00,struct.pack('<I',0x707ff000))
 h.Emu.__init__=initialize;h._gr20_rom_protected=True
def protect_g(self,image):
 mu=self.mu
 src,dst,n=struct.unpack_from('<III',image,0x450)
 mu.mem_write(dst,image[src-0x53000000:src-0x53000000+n])
 mu.mem_protect(0x53000000,(len(image)+0xffff)&~0xffff,UC_PROT_READ|UC_PROT_EXEC)
 mu.mem_write(0x5539ff00,struct.pack('<I',0x60070000))
 self.capture_allocs=0
 def services(uc,at,size,user):
  if at==0x538e09b0:
   assert self.capture_allocs==0,'Only one registry allocation per runtime'
   assert uc.reg_read(A.UC_ARM_REG_R0)==2064
   self.capture_allocs+=1;uc.reg_write(A.UC_ARM_REG_R0,0x60090000)
   uc.reg_write(A.UC_ARM_REG_PC,uc.reg_read(A.UC_ARM_REG_LR))
  elif at==0x538e09ec:uc.reg_write(A.UC_ARM_REG_PC,uc.reg_read(A.UC_ARM_REG_LR))
 mu.hook_add(UC_HOOK_CODE,services)
