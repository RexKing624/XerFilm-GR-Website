# SPDX-License-Identifier: GPL-2.0-only
"""Unit fixture: execute the real exposure metadata dispatcher and its hook.
Only the three downstream clock/calibration/extra-metadata services are omitted
in isolated tests; dedicated lifecycle integration executes native clock copy.
Never intercept pool constructor or BindShotInfo to fake a capture.
"""
def latch(e,si):
 addresses=(0x536650fc,0x53664d5c,0x53664e10)
 old={a:e.stubs.get(a) for a in addresses}
 try:
  for a in addresses:e.stubs[a]=lambda:0
  return e.call(0x536651e4,(0,si,0))
 finally:
  for a,v in old.items():
   if v is None:e.stubs.pop(a,None)
   else:e.stubs[a]=v
