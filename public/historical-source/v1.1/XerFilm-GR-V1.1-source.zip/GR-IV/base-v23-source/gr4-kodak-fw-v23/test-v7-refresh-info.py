# SPDX-License-Identifier: GPL-2.0-only
"""Execute real ARM cache, snapshot metadata, playback and widget paths.
Boot, native IFD entry I/O and display device are stubs; no physical camera.
"""
from pathlib import Path
exec((Path(__file__).parent/'emu-v6.py').read_text())
N=h.Image(str(BASE/'build-v7-c/candidate.bin.rtos'));O=h.Image('work/filter-analysis/RTOS.bin')
FLAG=0x55084dd8+4+0x94b
def branch(a):
 w=N.u32(a);n=w&0xffffff;n=n-0x1000000 if n&0x800000 else n;return a+8+n*4
def step(e,a):
 # Explicit hook avoids Unicorn reusing a translated block with an earlier
 # end address when testing the adjacent original OR/branch between calls.
 stop=e.mu.hook_add(UC_HOOK_CODE,lambda uc,pc,size,ud:uc.emu_stop() if pc==a+4 else None)
 e.mu.emu_start(a,0x100,count=10000);e.mu.hook_del(stop)
 ck(e.mu.reg_read(UC_ARM_REG_PC)==a+4,f'Inline hook {a:#x} returns to native continuation')

# Per-processor identity participates directly in the actual full-dirty decision.
e,_=make(str(BASE/'build-v7-c/candidate.bin.rtos'));mu=e.mu
for owner in [OBJ,OBJ+0x1000,OBJ+0x2000]:
 mu.mem_write(owner+0x20e,b'\xff\xff')
 for look in [0,6,10,11,12,9,10,0]:
  mu.mem_write(S,bytes([look]));mu.mem_write(FLAG,b'\1')
  for repeat in [False,True]:
   mu.mem_write(owner+0x20d,b'\0')
   mu.reg_write(UC_ARM_REG_R4,owner);mu.reg_write(UC_ARM_REG_R0,0x70050000)
   mu.reg_write(UC_ARM_REG_SP,0x600f0000);mu.reg_write(UC_ARM_REG_CPSR,0xa0000013)
   step(e,0x5391268c)
   ck(mu.reg_read(UC_ARM_REG_R1)==int(not repeat),f'Processor {owner:#x}, look {look}: dirty only on identity change ({repeat=})')
   ck(struct.unpack('<H',mu.mem_read(owner+0x20e,2))[0]==0x100+look,'Per-processor stamp contains actual look, including child speed')
   ck(mu.reg_read(UC_ARM_REG_R0)==0x70050000 and mu.reg_read(UC_ARM_REG_CPSR)&0xf0000000==0xa0000000,'Native update input and NZCV preserved')
  # Native OR and branch immediately after this hook choose the full reload.
  mu.reg_write(UC_ARM_REG_R0,0);mu.reg_write(UC_ARM_REG_R1,1)
  mu.emu_start(0x53912690,0x5391262c,count=20)
  ck(mu.reg_read(UC_ARM_REG_PC)==0x5391262c,'New film identity reaches native full parameter invalidation')
 mu.mem_write(FLAG,b'\0');mu.mem_write(owner+0x20d,b'\0')
 mu.reg_write(UC_ARM_REG_R4,owner);mu.reg_write(UC_ARM_REG_R0,0);step(e,0x5391268c)
 ck(mu.reg_read(UC_ARM_REG_R1)==1,'Switch OFF invalidates previous film parameter cache')

# Inline neutral reads: compare all registers and NZCV with the native word,
# with capture-snapshot flags deliberately opposite the current camera flag.
import re
rows=json.loads(re.search(r'=(\[.*\]) as const', (BASE/'core/src/fw/aspect/film-neutral-reads.ts').read_text()).group(1))
regs=[UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3,UC_ARM_REG_R4,UC_ARM_REG_R5,UC_ARM_REG_R6,UC_ARM_REG_R7,UC_ARM_REG_R8,UC_ARM_REG_R9,UC_ARM_REG_R10,UC_ARM_REG_R11,UC_ARM_REG_R12,UC_ARM_REG_SP,UC_ARM_REG_LR,UC_ARM_REG_CPSR]
old,new=h.Emu(O),h.Emu(N)
for row in rows:
 for active in [0,1,2,255]:
  for e in [old,new]:
   for k,r in enumerate(regs[:13]):e.mu.reg_write(r,0x70010000+k*0x1000)
   e.mu.reg_write(UC_ARM_REG_SP,0x600f0000);e.mu.reg_write(UC_ARM_REG_LR,0x100);e.mu.reg_write(UC_ARM_REG_CPSR,0xb0000013)
   base=e.mu.reg_read(regs[row['rn']]);e.mu.mem_write(base+row['offset'],b'\7')
   e.mu.mem_write(base+0x94b,bytes([active]));e.mu.mem_write(FLAG,bytes([1-active if active in [0,1] and row['snapshot'] else active]))
  old.mu.emu_start(row['address'],row['address']+4,count=2);new.mu.emu_start(row['address'],row['address']+4,count=2000)
  before=[old.mu.reg_read(r) for r in regs];after=[new.mu.reg_read(r) for r in regs]
  if active==1 and not row['snapshot']:before[row['rd']]=11 if row['offset']==0x79c else 4
  ck(before==after,f'Neutral read {row["address"]:#x}: snapshot/live gate {active}, only intended result changes')

# Round-trip all 13 captured looks through actual native writer/reader dispatch.
e,_=make(str(BASE/'build-v7-c/candidate.bin.rtos'));mu=e.mu;snapshot=0x70760000;entry=0x70750000
code=[0];writes=[]
def write():
 code[0]=mu.reg_read(UC_ARM_REG_R2);writes.append(code[0]);return 0
e.stubs[0x537e7148]=write;e.stubs[0x537e7354]=lambda:code[0]
e.stubs[0x537d4784]=lambda:0 # no device work, IFD scalar entry is stubbed above
for film in range(13):
 mu.mem_write(snapshot+0x94b,b'\1');mu.mem_write(snapshot+0x90f,bytes([film]));mu.mem_write(snapshot+0x79c,b'\x0e')
 mu.mem_write(FLAG,b'\0');mu.mem_write(S,bytes([(film+4)%13]))
 code[0]=0x8200+film # Backwards-compatible read of an existing tagged photo; no new private tag written.
 e.call(0x537d5748,(0,0,snapshot))
 ck(e.byte(snapshot+0x79c)==11,'Photo reader maps film identity to safe native Std for processing')
 # Reader's exact entry is derived from its prologue immediately before 89A0.
 got=[];e.stubs[0x537d3f70]=lambda:0
 # Stop at the native property setter to inspect the decoded property argument.
 mu.reg_write(UC_ARM_REG_R0,code[0]);mu.reg_write(UC_ARM_REG_R4,entry);mu.reg_write(UC_ARM_REG_SP,0x600f0000)
 mu.emu_start(0x537d89b0,0x537d8a00,count=10000)
 ck(mu.reg_read(UC_ARM_REG_R2)==128+film,'Playback identity distinguishes the film of this photo')

# Native old-photo ImageTone writer is preserved while snapshot is OFF, even
# when the currently selected camera film is ON. Old photos have no new icon.
mu.mem_write(snapshot+0x94b,b'\0');mu.mem_write(snapshot+0x79c,b'\x0b');mu.mem_write(FLAG,b'\1')
e.call(0x537de474,(0,entry,snapshot));native_code=code[0]
ck(native_code<0x8200,'Film-OFF snapshot uses original native ImageTone writer')

# Actual INFO IconView creation, layout, hiding and ownership. Both stock Std
# and film icons are independent; only photo property 128..140 shows film.
e,_=make(str(BASE/'build-v7-c/candidate.bin.rtos'));mu=e.mu
e.stubs[0x5323bddc]=lambda:0x707b0400;e.stubs[0x5323dbf0]=lambda:40;e.stubs[0x5323dc10]=lambda:40
d=0x707f0000
def create(kind,x,y,w,ht):
 mu.mem_write(d,struct.pack('<6I',kind,x,y,w,ht,0));return e.call(0x53589ee4,(d,))
root=create(1,0,0,720,480);std=create(10,240,260,40,40);e.call(0x53588158,(root,std))
mu.mem_write(OBJ+0x15c,struct.pack('<I',root));mu.mem_write(OBJ+0x224,struct.pack('<I',std));mu.mem_write(OBJ+0x31c,b'\2\0')
e.stubs[0x53183e14]=lambda:0x4000001;e.stubs[0x5323f868]=lambda:0x70740000;e.stubs[0x5323f67c]=lambda:0x70730000
photo=[1];e.stubs[0x537d3f30]=lambda:photo[0]
update=branch(0x53194604)
for film in range(13):
 photo[0]=128+film;mu.mem_write(FLAG,b'\0');mu.mem_write(S,bytes([(film+6)%13]));e.call(update,(OBJ,))
 icon=e.u32(OBJ+0x334)
 ck(struct.unpack('<H',mu.mem_read(std+0xea,2))[0]==366,'Original Std icon remains independent in playback INFO')
 ck(struct.unpack('<H',mu.mem_read(icon+0xea,2))[0]==(721+film if film<10 else 733+film-10),'INFO film icon matches recorded photo, including T-MAX speed')
 ck(struct.unpack('<4i',mu.mem_read(icon+0x20,16))==(240,320,40,40),'Film INFO icon occupies blank area below Std, outside histograms and values')
 ck(e.call(0x535894c0,(icon,))==1,'Film INFO icon visible for captured film photo')
photo[0]=1;e.call(update,(OBJ,));ck(e.call(0x535894c0,(icon,))==0,'Changing to old photo hides stale film INFO icon')
photo[0]=128;mu.mem_write(OBJ+0x31c,b'\1\0');e.call(update,(OBJ,));ck(e.call(0x535894c0,(icon,))==0,'Other playback display modes hide INFO-only film icon')
frees=[]
for a in [0x538e09ec,0x538e0a60]:e.stubs[a]=lambda:frees.append(mu.reg_read(UC_ARM_REG_R0)) or 0
mu.reg_write(UC_ARM_REG_R0,OBJ);mu.reg_write(UC_ARM_REG_SP,0x600f0000);mu.emu_start(0x5318f80c,0x5318f810,count=100000)
ck(icon in frees and e.u32(OBJ+0x334)==0,'INFO film icon freed before native parent destruction')
ck(not [c for c in e.calls if c[0] in ('ASSERT','NULL-JUMP')],'INFO widget paths have no failed native assertions or null jumps')
(BASE/'refresh-info-checks.json').write_text(json.dumps({'status':'passed','checks':checks,'hardwareTested':False,'scope':'ARM cache invalidation, original snapshot metadata reads; backwards-compatible old-photo identity dispatch, native playback property mapping, real INFO view creation/layout/lifetime. IFD entry I/O and display hardware stubbed; no camera live-view validation.'},ensure_ascii=False,indent=2))
print('PASS',len(checks),'cache, snapshot metadata and INFO checks')
