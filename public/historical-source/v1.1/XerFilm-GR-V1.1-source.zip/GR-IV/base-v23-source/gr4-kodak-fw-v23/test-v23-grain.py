# SPDX-License-Identifier: GPL-2.0-only
# Execute actual GR IV native effect preparation, processing gate, and new menu.
from pathlib import Path
import importlib.util,itertools,json,struct,os
BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
spec=importlib.util.spec_from_file_location('native_grain',ROOT/'work/gr4-fuji-fw-v2/audit-grain/check_grain.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
sidecar={};exec((BASE/'sidecar-fixture.py').read_text(),sidecar);sidecar['install'](g)
stock=(ROOT/'work/filter-analysis/RTOS.bin').read_bytes();new=(BASE/'build-v23-a/candidate.bin.rtos').read_bytes()
a,b=g.Emulator(stock),g.Emulator(new);checks=[]
def ck(ok,msg):
 if not ok:raise AssertionError(msg)
 checks.append(msg)
U=0x55084dd8+4
# Native OFF remains unchanged, including other grain-capable image controls.
for tone,enable,size,strength in itertools.product((11,13,28),(0,1),range(3),range(3)):
 results=[]
 for em in (a,b):
  em.configure(0,tone,enable,size,strength);em.mu.mem_write(g.SI+0x94b,b'\0')
  results.append((em.call(g.PREPARE),em.call(g.GATE)))
 ck(all(g.public(results[0][i])==g.public(results[1][i]) and results[0][i]['memory']==results[1][i]['memory'] for i in (0,1)),f'Native OFF unchanged tone{tone},enable{enable},size{size},strength{strength}')
# A shot owns the switch and strength; current live UI never retargets it.
for level,live,tone,enable,size,strength in itertools.product(range(4),(0,1),(11,13,28),(0,1),(0,2),(0,2)):
 b.configure(live,tone,enable,size,strength,shading=8,clarity=0)
 b.mu.mem_write(g.SI+0x94b,b'\1');b.mu.mem_write(g.SI+0x49,(0xc80000|(level<<17)|0x1ffff).to_bytes(3,'little'))
 b.mu.mem_write(U+0x49,(0xc80000|(((level+1)%4)<<17)|0x1ffff).to_bytes(3,'little'))
 before=bytes(b.mu.mem_read(g.SI,0x1000));p=b.call(g.PREPARE);gate=b.call(g.GATE)
 ck((p['p4_enable_type'],p['p6_strength'],p['p8_size'],gate['plan25'])==(int(level>0),max(0,level-1),0,int(level>0)),f'Snapshot grain{level},live{live},tone{tone},native{enable}/{size}/{strength}')
 ck(bytes(b.mu.mem_read(g.SI,0x1000))==before,'Effect stage never rewrites the shot snapshot')
 ck(struct.unpack_from('<2h',p['memory'][0],0)==(0,0) and struct.unpack_from('<h',p['memory'][0],10)[0]==0,'Film grain keeps native shading, clarity, HDR neutral')
# Old installed settings acquire grain OFF, regardless of old unused bytes.
for tag in (0,0xb40000,0xffffff):
 b.configure(1,11,1,2,2);b.mu.mem_write(g.SI+0x94b,b'\1');b.mu.mem_write(g.SI+0x49,(tag|0x1ffff).to_bytes(3,'little'))
 ck(b.call(g.PREPARE)['p4_enable_type']==0 and b.call(g.GATE)['plan25']==0,f'Untagged/legacy snapshot{tag:#x} defaults grain OFF')
# Native settings dispatch and recorded strength controls.
KEEP_BASE=BASE;checks_native=checks.copy()
os.chdir(ROOT);exec((BASE/'emu-v6.py').read_text(),globals())
BASE=KEEP_BASE;checks=[]
e,_=make(str(BASE/'build-v23-a/candidate.bin.rtos'));mu=e.mu;img=h.Image(str(BASE/'build-v23-a/candidate.bin.rtos'))
table=img.movw_movt(0x531d6868,0x531d6878);record=table+127*0x4c
count,draw,setter,current=[img.u32(record+off) for off in (0xc,0x14,0x24,0x2c)]
from capstone import Cs,CS_ARCH_ARM,CS_MODE_ARM
calls_set=[]
for ins in Cs(CS_ARCH_ARM,CS_MODE_ARM).disasm(img.rd(setter,200),setter):
 if int.from_bytes(ins.bytes,'little')&0xf000000==0xb000000:calls_set.append(int(ins.op_str[1:],16))
 if ins.mnemonic=='pop' and 'pc' in ins.op_str:break
preview_events=[]
e.stubs[calls_set[-1]]=lambda:preview_events.append(1) or 0

ck(e.call(count,())==4,'Grain settings have Off / Weak / Medium / Strong')
e.call(0x531d5e8c,(OBJ,0x020001a3));ck(e.byte(OBJ+0x1a4)==127,'New grain controller selects independent record127, not ADJ or grid')
for level in range(4):
 mu.mem_write(U+0x49,(0xb40000|0x15555).to_bytes(3,'little'));mu.mem_write(U+0x94b,b'\1')
 e.call(setter,(OBJ,level))
 packed=int.from_bytes(mu.mem_read(U+0x49,3),'little')
 ck(packed&0x1ffff==0x15555 and (packed>>17)&3==level and (packed>>19)==0x19,'Grain menu migrates old mask without changing enabled families')
 ck(e.byte(U+0x94b)==1,'Setting grain never changes global film switch')
 ck([e.call(current,(OBJ,i)) for i in range(4)]==[int(i==level) for i in range(4)],'Exactly one native current marker follows chosen strength')
 start=len(e.calls)
 for i in range(4):e.call(draw,(OBJ,0x70008000,i))
 captured=[v[2:] for v in e.calls[start:] if v[0]=='list-item']
 ck([v[1] for v in captured]==[2,880,881,882],f'Native row labels correctly map to OFF/Weak/Medium/Strong: {captured}')
ck(len(preview_events)==3,'Three changed active grain settings request native refresh; unchanged OFF does not')
mu.mem_write(U+0x94b,b'\0');e.call(setter,(OBJ,1));ck(len(preview_events)==3,'Setting grain while simulation OFF does not refresh image processing')
# Use actual compact-mask reader and setting callbacks to test orthogonal storage.
from capstone import Cs,CS_ARCH_ARM,CS_MODE_ARM
M=Cs(CS_ARCH_ARM,CS_MODE_ARM)
def calls(addr):
 out=[]
 for i in M.disasm(img.rd(addr,1500),addr):
  if int.from_bytes(i.bytes,'little')&0xf000000==0xb000000:out.append(int(i.op_str[1:],16))
  if i.mnemonic=='pop' and 'pc' in i.op_str:break
 return out
mask_count=img.u32(0x53d9f714+10*0x5c+0x30)
maskfn=calls(mask_count)[0]
for level in range(4):
 e.call(setter,(OBJ,level));v=int.from_bytes(mu.mem_read(U+0x49,3),'little')
 ck(e.call(maskfn,())==0x15555 and int.from_bytes(mu.mem_read(U+0x49,3),'little')==v,'Reading enabled families preserves grain level')
# Toggling a family never erases the selected grain level (same three bytes).
w=img.u32(0x531dacac);n=w&0xffffff;n=n-0x1000000 if n&0x800000 else n;keys=0x531dacac+8+n*4
panel_toggle=calls(keys)[1];family_toggle=calls(panel_toggle)[0]
for level in range(4):
 mu.mem_write(U+0x49,(0xc80000|(level<<17)|0x15555).to_bytes(3,'little'));e.call(family_toggle,(16,))
 v=int.from_bytes(mu.mem_read(U+0x49,3),'little')
 ck(v&0x1ffff==0x5555 and ((v>>17)&3)==level,'Disabling a family preserves independently configured grain level')
 e.call(family_toggle,(16,));v=int.from_bytes(mu.mem_read(U+0x49,3),'little')
 ck(v&0x1ffff==0x15555 and ((v>>17)&3)==level,'Re-enabling a family preserves independently configured grain level')
checks=checks_native+checks
(BASE/'v23-grain-checks.json').write_text(json.dumps({'passed':True,'checks':checks,'count':len(checks),'scope':'Real native parameter preparation and stage gate, snapshot independence, original OFF behavior, native settings callbacks, menu labels and tagged settings migration. Pixel engine/camera not executed.','hardwareTested':False},ensure_ascii=False,indent=2))
print('PASS',len(checks),'native grain preparation, processing-stage gate, snapshot and settings checks')
