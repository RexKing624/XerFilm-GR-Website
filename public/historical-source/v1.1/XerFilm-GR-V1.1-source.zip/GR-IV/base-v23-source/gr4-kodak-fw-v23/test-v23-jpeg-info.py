# SPDX-License-Identifier: GPL-2.0-only
"""JPEG-only metadata identity -> real native decoder -> actual INFO icon.
Native ctor and parameter binding/IFD scalar write/read run as ARM code.
Hardware display, boot services and filesystem/JPEG codec are not emulated.
"""
from pathlib import Path
import os,json,struct
HERE=Path(__file__).resolve().parent;os.chdir(HERE.parent.parent)
exec((HERE/'emu-v6.py').read_text(),globals());BASE=HERE
exec((HERE/'capture-event-fixture.py').read_text(),globals())
from unicorn import arm_const as A
from unicorn import UC_HOOK_MEM_WRITE
N=h.Image(str(BASE/'build-v23-a/candidate.bin.rtos'));O=h.Image('work/filter-analysis/RTOS.bin')
CAT=json.loads((BASE/'v23-catalog.json').read_text());checks=[]
U=0x55084dd8+4;SI=0x700a0000;JOB=0x70010000;JW=0x70070000;DS=0x70080000;ENTRY=0x70090000;DESC=0x700b0000;PROP=0x700c0000

def ck(ok,s):
 if not ok:raise AssertionError(s)
 checks.append(s)
def word(e,a,v):e.mu.mem_write(a,struct.pack('<I',v))
def branch(a):
 w=N.u32(a);n=w&0xffffff;n=n-0x1000000 if n&0x800000 else n;return a+8+n*4

new,_=make(str(BASE/'build-v23-a/candidate.bin.rtos'));stock,_=make('work/filter-analysis/RTOS.bin');m=new.mu
previous,_=make(str(BASE.parent/'gr4-kodak-fw-v21/build-v21-a/candidate.bin.rtos'))
# Boot's allocator singleton is supplied; native vector/owner ctors still run.
for e in(stock,new,previous):
 word(e,0x707d0000,0x707d0100);word(e,0x707d0108,0x707d0200)
 word(e,0x553a0850,0x707d0400) # Boot platform singleton, default scalar fields.
 e.stubs[0x53799b70]=lambda:0x707d0000
 def alloc(e=e):
  p=e.heap[0];e.heap[0]+=(e.mu.reg_read(A.UC_ARM_REG_R1)*4+15)&~15;return p
 e.stubs[0x707d0200]=alloc
# Execute the original ImageTone registry initialiser, not an empty BSS table.
# The old empty-table fixture made EVERY native style fall back to Std, hiding
# the exact Soft BW provenance seen in the user's v20 camera photo.
for e in(stock,new,previous):
 e.mu.reg_write(A.UC_ARM_REG_SP,0x600f0000)
 e.mu.emu_start(0x537ae810,0x537ae888,count=10000)
 start=e.u32(0x5537f198);end=e.u32(0x5537f19c)
 ck(end-start==80 and bytes(e.mu.mem_read(start,80))==O.rd(0x53fa1758,80),'Real boot initializer installs all20 native ImageTone mappings')
# Exact RTTI proves the native owning class; don't mistake H264 for DNG.
def typename(img,vt):
 ti=img.u32(vt-4);p=img.u32(ti+4);return img.rd(p,80).split(b'\0')[0].decode()
ck(typename(O,O.u32(0x53809638))=='22ExifJpegMetaDataWriter','Hook owner is the ordinary still-photo ExifJpegMetaDataWriter, not the auxiliary writer')
ck(typename(O,O.u32(0x53800b98))=='17DNGMetaDataWriter','DNG uses a separate original writer class')
# Original JPEG ctor initializes the member; only its vptr changes.
for e in(stock,new,previous):e.call(0x53809564,(JW,))
old=bytes(stock.mu.mem_read(JW,0x290));actual=bytes(m.mem_read(JW,0x290))
ck(old[:0x240]==actual[:0x240] and old[0x244:]==actual[0x244:],'Full native JPEG ctor differs only at its owned setter vptr')
JSET=JW+0x240;JVT=new.u32(JSET);NVT=0x53fa7650
ck(previous.u32(JSET)==NVT,'v21 regression reproduced: ordinary still-photo writer incorrectly retains the stock setter')
AUX=0x70050000
for e in(stock,new,previous):e.call(0x53806c2c,(AUX,))
ck(previous.u32(AUX+0x54)!=NVT and new.u32(AUX+0x54)==NVT,'v21 changed the auxiliary writer; v23 restores it and covers ordinary photos instead')
ck(JVT!=NVT and new.u32(JVT-4)==O.u32(NVT-4) and new.u32(JVT-8)==O.u32(NVT-8),'JPEG clone preserves original RTTI and offset-to-top')
for off in range(0,0x24,4):ck((new.u32(JVT+off)!=O.u32(NVT+off))==(off==0x14),f'Only JPEG virtual SetEntry slot changes ({off:#x})')
# DNG's own constructor call site and shared member ctor/table remain exact.
for a,n in((0x53806c60,16),(0x53800b44,12),(0x5380c6d4,0x50),(0x53fa7648,44),(0x537de474,0x150),(0x5382497c,24)):
 ck(N.rd(a,n)==O.rd(a,n),f'Shared/DNG/video writer bytes {a:#x} unchanged')
DW=0x70060000
for e in(stock,new):e.call(0x53800a8c,(DW,))
ck(bytes(m.mem_read(DW,0x2b0))==bytes(stock.mu.mem_read(DW,0x2b0)),'Full native DNG constructor and every owned member remain byte-identical')
DS=DW+0x244
ck(new.u32(DS)==NVT,'Full native DNG constructor still gives its owned setter the original vtable')
# Prepare both setters through native descriptor constructor/accessor chain.
new.call(0x538048b0,(DESC,));new.call(0x5380494c,(DESC,SI))
previous.call(0x538048b0,(DESC,));previous.call(0x5380494c,(DESC,SI))
previous.call(0x5380480c,(JSET,DESC))
previous.mu.mem_write(U+0x94b,b'\1');previous.mu.mem_write(U+0x90f,b'\x0a');previous.mu.mem_write(SI+0x79c,b'\x0b')
previous.call(0x537119a0,(JOB,0,SI))
previous.mu.mem_write(ENTRY,struct.pack('<IHHIII B3x',0,0x4f,3,1,0xdeadbeef,0,1))
previous.call(previous.u32(previous.u32(JSET)+0x14),(JSET,ENTRY))
ck(struct.unpack('<H',previous.mu.mem_read(ENTRY+12,2))[0]==0x100,'v21 active T-MAX capture still writes native Standard in ordinary JPG, matching the supplied photo')
for setter in(JSET,DS):
 ck(new.call(0x5380480c,(setter,DESC))==1,'Real native SetParameter/reset/virtual-init path succeeds')
 ck(new.u32(setter+0x18)==SI,'Real native parameter accessor gives metadata the same ShotInfo key')
# Initialize a real inline SHORT IFD entry; no stub on IFD write/read/clear.
def entry(e,tag=0x4f):
 e.mu.mem_write(ENTRY,struct.pack('<IHHIII B3x',0,tag,3,1,0xdeadbeef,0,1))
def bind(flag,look,si=SI):
 m.mem_write(U+0x94b,bytes([flag]));m.mem_write(U+0x90f,bytes([look]));m.mem_write(U+0x49,(0x400000|0x15555).to_bytes(3,'little'))
 latch(new,si);new.call(0x537119a0,(JOB,0,si))
def saved(e):return struct.unpack('<H',e.mu.mem_read(ENTRY+12,2))[0]
def write(setter):
 entry(new);before=bytes(m.mem_read(SI,0x1000));live=bytes(m.mem_read(U,0x1000))
 result=new.call(new.u32(new.u32(setter)+0x14),(setter,ENTRY))
 ck(result==1,'Native entry dispatch returns success')
 ck(bytes(m.mem_read(SI,0x1000))==before and bytes(m.mem_read(U,0x1000))==live,'Metadata write never rewrites native shot or current camera settings')
 return saved(new)
# Real INFO view object lifecycle, with only display/boot singleton service stubs.
new.stubs[0x5323bddc]=lambda:0x707b0400;new.stubs[0x5323dbf0]=lambda:40;new.stubs[0x5323dc10]=lambda:40
D=0x707f0000
def create(kind,x,y,w,ht):
 m.mem_write(D,struct.pack('<6I',kind,x,y,w,ht,0));return new.call(0x53589ee4,(D,))
root=create(1,0,0,720,480);std=create(10,240,260,40,40);new.call(0x53588158,(root,std))
word(new,OBJ+0x15c,root);word(new,OBJ+0x224,std);m.mem_write(OBJ+0x31c,b'\2\0')
new.stubs[0x53183e14]=lambda:0x4000001
new.stubs[0x5323f868]=lambda:PROP-0x194;new.stubs[0x5323f67c]=lambda:PROP-0x194
update=branch(0x53194604)
# Reader entry starts at native prologue immediately before 0x537d89a0.
READER=0x537d8994
ck(O.u32(READER)==0xe1a0c00d,'Native photo ImageTone decoder entry verified')
for look in range(27):
 m.mem_write(SI,b'\0'*0x1000);m.mem_write(SI+0x79c,b'\x0b');bind(1,look)
 # Current UI changes after capture: saved metadata must follow this shot.
 m.mem_write(U+0x94b,b'\0');m.mem_write(U+0x90f,bytes([(look+7)%27]))
 ck(write(JSET)==0x8200+look,f'JPEG persists captured look {look}, independent of later UI')
 jpeg=bytes(m.mem_read(ENTRY,24))
 # Real scalar IFD decode -> real property setter -> real getter -> INFO.
 new.call(READER,(0,PROP,ENTRY));ck(new.call(0x537d3f30,(PROP,0x25))==128+look,f'JPEG look {look} survives native metadata decoder round-trip')
 new.call(update,(OBJ,));icon=new.u32(OBJ+0x334)
 ck(struct.unpack('<H',m.mem_read(icon+0xea,2))[0]==CAT['hudIcons'][look],f'INFO uses the saved icon including child variant {look}')
 ck(new.call(0x535894c0,(icon,))==1,'INFO icon visible after real metadata writer/reader round-trip')
 ck(struct.unpack('<H',m.mem_read(std+0xea,2))[0]==366,'Native Std INFO icon remains separate')
 ck(write(DS)==0x100,'Same capture through DNG member retains native Std, never private tag')
 # Loading the previously saved JPEG after DNG processing still sees its own tag.
 m.mem_write(ENTRY,jpeg);new.call(READER,(0,PROP,ENTRY));ck(new.call(0x537d3f30,(PROP,0x25))==128+look,'Stored JPEG identity survives independent DNG processing')
# Reproduce every saved native style, including Soft BW, behind Film ON.
# The JPEG must describe its recorded film; the DNG must keep its native tag.
# With Film OFF both writers and the displayed native INFO icon stay original.
native_styles=[struct.unpack('<BBH',O.rd(0x53fa1758+i*4,4)) for i in range(20)]
for native,unused,native_code in native_styles:
 m.mem_write(SI+0x79c,bytes([native]))
 for look in range(27):
  bind(1,look);m.mem_write(U+0x94b,b'\0')
  ck(write(JSET)==0x8200+look,f'Native style{native} cannot replace captured JPEG film{look}')
  new.call(READER,(0,PROP,ENTRY));new.call(update,(OBJ,))
  ck(struct.unpack('<H',m.mem_read(std+0xea,2))[0]==366 and struct.unpack('<H',m.mem_read(new.u32(OBJ+0x334)+0xea,2))[0]==CAT['hudIcons'][look],f'INFO shows Std plus recorded film{look}, never stale native style{native}')
  ck(write(DS)==native_code,f'DNG native style{native} keeps its original ImageTone{native_code:#x}')
 bind(0,0);m.mem_write(U+0x94b,b'\1')
 for setter in(JSET,DS):
  ck(write(setter)==native_code,f'Film OFF preserves native style{native} in both JPEG and DNG')
  new.call(READER,(0,PROP,ENTRY));new.call(update,(OBJ,))
  ck(new.call(0x535894c0,(new.u32(OBJ+0x334),))==0,f'Native style{native} does not acquire a film INFO icon')
  prop=new.call(0x537d3f30,(PROP,0x25));native_id=O.rd(0x53dbda18+prop-1,1)[0]
  expected=struct.unpack('<H',O.rd(0x53dbdbf0+(native_id-8)*2,2))[0]
  ck(struct.unpack('<H',m.mem_read(std+0xea,2))[0]==expected,f'Film OFF retains the correct original INFO icon for native style{native}')
# Restore the neutral snapshot for the original negative/serialization cases.
m.mem_write(SI+0x79c,b'\x0b')
# OFF, invalid flag, unknown/recycled shot keys fail closed even when UI is ON.
for flag in(0,2,255):
 bind(flag,12);m.mem_write(U+0x94b,b'\1');ck(write(JSET)==0x100,f'Captured flag {flag} uses native identity despite live Film ON')
word(new,JSET+0x18,SI+0x5000);ck(write(JSET)==0x100,'Unknown metadata shot key retains native identity')
word(new,JSET+0x18,SI);bind(1,0)
# Non-ImageTone tags use exact native handler, not a custom tag-layout guess.
for tag in(0x5c,0x4e,0xffff):
 for e,setter in((new,JSET),(stock,DS)):
  if e is stock:
   e.call(0x5380c6d4,(DS,));word(e,DS+0x18,SI);e.mu.mem_write(SI,b'\0'*0x80000)
  entry(e,tag);e.call(e.u32(e.u32(setter)+0x14),(setter,ENTRY))
 ck(bytes(m.mem_read(ENTRY,24))==bytes(stock.mu.mem_read(ENTRY,24)),f'Other metadata tag {tag:#x} matches original native handler')
# After switching to an untagged photo, hide a previous icon rather than reuse it.
entry(new);new.call(0x537e7148,(ENTRY,0,0x100));new.call(READER,(0,PROP,ENTRY));new.call(update,(OBJ,))
ck(new.call(0x535894c0,(new.u32(OBJ+0x334),))==0,'Untagged/native photo hides previous film icon')
# A new boot has no capture registry: replay the stored on-disk identity through
# a second emulation instance. No current film or sidecar is supplied to it.
fresh,_=make(str(BASE/'build-v23-a/candidate.bin.rtos'))
for look in range(27):
 entry(fresh);fresh.call(0x537e7148,(ENTRY,0,0x8200+look))
 fresh.call(READER,(0,PROP,ENTRY))
 ck(fresh.call(0x537d3f30,(PROP,0x25))==128+look,f'Fresh runtime reads saved JPEG look {look} with empty capture registry')
# Native TIFF directory -> real entry serialization, both byte orders. This
# tests actual persisted bytes, beyond a stubbed scalar IFD value in memory.
TW=0x700d0000;WIRE=0x700d1000;IFD=0x700d2000;LIST=0x700d3000
new.call(0x538147bc,(TW,));word(new,TW+4,WIRE);word(new,TW+8,128)
m.mem_write(IFD,bytes(0x40));word(new,LIST,ENTRY);word(new,IFD+0xc,LIST);word(new,IFD+0x10,LIST+4)
wire_cases=[]
for endian in(0,1):
 order='>'if endian else'<'
 new.call(0x53814778,(TW,endian))
 for look in range(27):
  m.mem_write(SI,bytes(0x1000));m.mem_write(SI+0x79c,b'\x0b');bind(1,look)
  m.mem_write(U+0x94b,b'\0');m.mem_write(U+0x90f,bytes([(look+5)%27]))
  for setter,is_jpeg in((JSET,True),(DS,False)):
   # Start with an unfilled entry. The actual directory walk must invoke the
   # selected JPEG/DNG virtual setter itself before serializing its bytes.
   entry(new);word(new,ENTRY,0x53fa4b58);m.mem_write(WIRE,b'\xa5'*128)
   ck(new.call(0x537e6c30,(IFD,TW,setter))==1,'Native IFD directory invokes the actual owned JPEG/DNG setter and serializes successfully')
   data=bytes(m.mem_read(WIRE,128));count=struct.unpack_from(order+'H',data,0)[0]
   tag,kind,n=struct.unpack_from(order+'HHI',data,2);v=struct.unpack_from(order+'H',data,10)[0]
   ck((count,tag,kind,n,v)==(1,0x4f,3,1,0x8200+look if is_jpeg else 0x100),f'Actual serialized {"JPEG"if is_jpeg else"DNG"} metadata bytes: endian{endian},look{look}')
   ck(data[12:18]==bytes(6)and data[18:]==b'\xa5'*110,'Native serializer writes only one valid SHORT entry and next-IFD pointer within buffer')
   # Independent wire parsing feeds a fresh native scalar/property decoder.
   entry(fresh);fresh.call(0x537e7148,(ENTRY,0,v));fresh.call(READER,(0,PROP,ENTRY))
   ck(fresh.call(0x537d3f30,(PROP,0x25))==(128+look if is_jpeg else 1),'Persisted wire value round-trips after fresh-runtime decode')
   wire_cases.append({'endian':'big'if endian else'little','writer':'JPEG'if is_jpeg else'DNG','look':look,'hex':data[:18].hex()})
(BASE/'v23-info-wire-cases.json').write_text(json.dumps(wire_cases,indent=2))
# Untagged/foreign images and invalid private values must clear stale icons.
for code in(0x100,0x101,0x81ff,0x821b,0xffff,0):
 entry(new);new.call(0x537e7148,(ENTRY,0,code));new.call(READER,(0,PROP,ENTRY));new.call(update,(OBJ,))
 ck(new.call(0x535894c0,(new.u32(OBJ+0x334),))==0,f'Native/foreign/out-of-range photo tag{code:#x} hides stale INFO film icon')
# Warm INFO has one owned widget. Repeated photo navigation never creates one
# view per image or substitutes the current menu's film for the photo's film.
heap_before=new.heap[0];icon=new.u32(OBJ+0x334)
for k in range(400):
 look=(k*7)%27;entry(new);new.call(0x537e7148,(ENTRY,0,0x8200+look));new.call(READER,(0,PROP,ENTRY))
 m.mem_write(U+0x94b,bytes([k%2]));m.mem_write(U+0x90f,bytes([(look+13)%27]));new.call(update,(OBJ,))
 ck(new.u32(OBJ+0x334)==icon and struct.unpack('<H',m.mem_read(icon+0xea,2))[0]==CAT['hudIcons'][look],'Repeated photo navigation reuses the same widget and displays the photo-owned icon')
ck(new.heap[0]==heap_before,'400 INFO photo transitions do not allocate additional native widgets')
for mode in(0,1,3,4):
 m.mem_write(OBJ+0x31c,struct.pack('<H',mode));new.call(update,(OBJ,))
 ck(new.call(0x535894c0,(icon,))==0,'Non-INFO display modes hide the separate film icon')
m.mem_write(OBJ+0x31c,b'\2\0');new.stubs[0x53183e14]=lambda:0x4000002;new.call(update,(OBJ,))
ck(new.call(0x535894c0,(icon,))==0,'Non-photo/video state does not show a stale film icon')
new.stubs[0x53183e14]=lambda:0x4000001;new.call(update,(OBJ,))
ck(new.call(0x535894c0,(icon,))==1,'Returning to detailed photo INFO restores the correct photo icon')
# Execute COMPLETE original playback destructor, not only the injected prefix.
frees=[]
for a in(0x538e09ec,0x538e0a60):new.stubs[a]=lambda:frees.append(m.reg_read(A.UC_ARM_REG_R0))or 0
new.call(0x5318f80c,(OBJ,))
ck(new.u32(OBJ+0x334)==0 and frees.count(icon)==1,'Complete native playback destruction frees the custom INFO icon exactly once')
ck(frees.count(root)==1 and frees.count(std)==1,'Complete native playback destruction also frees original root and Std exactly once')
ck(not[c for c in new.calls if c[0]in('ASSERT','NULL-JUMP')],'Writer/reader/INFO chain has no native failed assertions')
report={'passed':True,'count':len(checks),'checks':checks,'hardwareTested':False,'scope':'Native JPEG/DNG member constructors; real scalar IFD I/O and full TIFF directory serialization in both byte orders;108 persisted entry byte cases; native property decode;400 INFO photo transitions, mode guards and full controller destructor. JPEG file codec, filesystem, RAW+JPEG pair member selection and camera display are not executed.','rawBoundary':'Shared maker-note class/table/writer, DNG member ctor site and H264 writer remain original; only JPEG owner member gets a private setter vtable. No new ShotInfo or live UI writes.'}
(BASE/'v23-jpeg-info-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('PASS',len(checks),'JPEG-only photo identity and real INFO round-trip checks')
