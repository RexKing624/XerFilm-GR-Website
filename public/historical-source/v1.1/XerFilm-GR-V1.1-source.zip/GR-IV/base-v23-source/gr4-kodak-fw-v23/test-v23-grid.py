# SPDX-License-Identifier: GPL-2.0-only
# Execute the real native grid, settings state and compact ADJ adapters.
from pathlib import Path
import os, json, struct
HERE=Path(__file__).resolve().parent
os.chdir(HERE.parent.parent)
exec((HERE/'emu-v6.py').read_text())
from capstone import Cs,CS_ARCH_ARM,CS_MODE_ARM
BASE=HERE;P=BASE/'build-v23-a/candidate.bin.rtos';N=h.Image(str(P));M=Cs(CS_ARCH_ARM,CS_MODE_ARM)
def branch(a):
 w=N.u32(a);n=w&0xffffff;n=n-0x1000000 if n&0x800000 else n;return a+8+n*4

def calls(a,limit=1800):
 out=[]
 for i in M.disasm(N.rd(a,limit),a):
  if int.from_bytes(i.bytes,'little')&0x0f000000==0x0b000000:out.append(int(i.op_str[1:],16))
  if i.mnemonic=='pop' and 'pc' in i.op_str:break
 return out

key=branch(0x531dacac);toggle_button=calls(key)[1];render=calls(key)[2]
TABLE=0x53d9f714+10*0x5c;count=N.u32(TABLE+0x30);maskfn=calls(count)[0]
adj_current=N.u32(TABLE+0x20);adj_set=N.u32(TABLE+0x28);at=calls(adj_set)[-2];stable_set=calls(adj_set)[-1]
preview=calls(stable_set)[-1];enabled_toggle=calls(toggle_button)[0]
CAT=json.loads((BASE/'v23-catalog.json').read_text());U=0x55084dd8+4;ALL=(1<<17)-1

def write_mask(mu,bits):mu.mem_write(U+0x49,(0xb40000|bits).to_bytes(3,'little'))
def read_mask(e):return e.call(maskfn,())

# All subsets are addressed by a compact position only at the UI edge.
e,_=make(str(P));mu=e.mu;events=[];e.stubs[preview]=lambda:events.append(e.byte(S)) or 0
for bits in [ALL,1,1<<16,(1<<10)|(1<<11)|(1<<16),0x15555,0xaaa,0]:
 write_mask(mu,bits);families=[i for i in range(17) if bits&(1<<i)]
 ck(e.call(count,())==1+len(families),f'Mask {bits:#x}: safe native count including empty OFF state')
 ck([e.call(at,(i,)) for i in range(1,1+len(families))]==families,f'Mask {bits:#x}: compact rows map to stable family IDs')
 if not families:ck(e.call(at,(0,))==0xffffffff,'Empty list returns explicit OFF sentinel, never a real film')
 for i,f in enumerate(families):
  mu.mem_write(S,b'\0');mu.mem_write(U+0x94b,b'\1');events.clear();e.call(adj_set,(OBJ,i+1))
  ck(e.byte(S)==CAT['families'][f]['first'],f'Mask {bits:#x} row{i}: selecting ADJ resolves stable family {f}')
write_mask(mu,(1<<10)|(1<<11)|(1<<16));mu.mem_write(S,b'\x14')
ck(e.call(adj_current,(OBJ,3))==1 and e.call(adj_current,(OBJ,16))==0,'Shrinking ADJ list invalidates stale native cached row16 while retaining current compact row2')
write_mask(mu,0);mu.mem_write(U+0x94b,b'\0');ck(e.call(adj_current,(OBJ,0))==1 and e.call(adj_current,(OBJ,16))==0,'Only empty-list row0 is current; stale out-of-range rows never pass the native cache guard')
# Defaults, independent padding and corruption fallback.
mu.mem_write(U+0x48,b'\x73');mu.mem_write(U+0x4c,b'\x11\x22\x33\x44');mu.mem_write(U+0x49,b'\0\0\0')
ck(read_mask(e)==ALL,'Existing firmware settings acquire all-enabled defaults')
ck(e.byte(U+0x48)==0x73 and bytes(mu.mem_read(U+0x4c,4))==b'\x11\x22\x33\x44','Mask writes preserve native fields surrounding alignment padding')
for f in range(17):
 write_mask(mu,ALL);mu.mem_write(S,b'\0');mu.mem_write(U+0x94b,b'\1');events.clear();e.call(enabled_toggle,(f,))
 ck(read_mask(e)==ALL^(1<<f),f'Family {f}: one OK changes exactly one enable bit')
 ck(e.byte(S)==(1 if f==0 else 0),f'Family {f}: disabled active family changes to first enabled film only')
 e.call(enabled_toggle,(f,));ck(read_mask(e)==ALL,f'Family {f}: second OK re-enables the same family')
write_mask(mu,1<<11);mu.mem_write(S,b'\x13');mu.mem_write(U+0x94b,b'\1');e.call(enabled_toggle,(11,))
ck(read_mask(e)==0 and e.byte(U+0x94b)==0,'Disabling last family safely switches simulation OFF')
# Turning simulation back on from an empty list enables the retained family.
settings=N.movw_movt(0x531d6868,0x531d6878);switch=N.u32(settings+125*0x4c+0x24)
write_mask(mu,0);mu.mem_write(S,b'\x13');mu.mem_write(U+0x94b,b'\0');events.clear();e.call(switch,(OBJ,1))
ck(read_mask(e)==1<<11 and e.byte(U+0x94b)==1 and e.byte(S)==19,'Global ON from empty list restores the retained PORTRA family without changing its speed')
e.call(switch,(OBJ,0));ck(read_mask(e)==1<<11 and e.byte(U+0x94b)==0,'Global OFF preserves configured enabled families')
# Screen uses the firmware's native View/ADJListItem/IconView/TextView code.
e,draws=make(str(P));mu=e.mu;frees=[]
for a in [0x538e09ec,0x538e0a60]:e.stubs[a]=lambda:frees.append(mu.reg_read(UC_ARM_REG_R0)) or 0
e.stubs[0x538ee49c]=lambda:e.calls.append(('ASSERT',hex(mu.reg_read(UC_ARM_REG_LR)))) or 0 if not mu.reg_read(UC_ARM_REG_R0) else 0
e.stubs[0x5323bddc]=lambda:0x707b0400;e.stubs[0x5323dbf0]=lambda:80;e.stubs[0x5323dc10]=lambda:80
D=0x707f0000
def create(kind,x,y,w,ht):
 mu.mem_write(D,struct.pack('<6I',kind,x,y,w,ht,0));return e.call(0x53589ee4,(D,))
root=create(1,0,0,720,480);mu.mem_write(OBJ+0x158,struct.pack('<I',root))
for off,kind,rect in [(0x15c,11,(0,0,720,60)),(0x160,17,(10,10,560,40)),(0x164,11,(0,58,720,2)),(0x180,11,(0,420,720,60)),(0x184,6,(10,430,190,40)),(0x188,6,(530,430,180,40)),(0x198,13,(0,60,720,360))]:
 v=create(kind,*rect);mu.mem_write(OBJ+off,struct.pack('<I',v));e.call(0x53588158,(root,v))
mu.mem_write(OBJ,struct.pack('<I',0x53da2c70));mu.mem_write(OBJ+0x1a4,b'\x7e');mu.mem_write(S,b'\x0d');write_mask(mu,ALL);mu.mem_write(U+0x94b,b'\0')
e.call(render,(OBJ,));tree=e.u32(OBJ+0x1e4);caption=e.u32(OBJ+0x1ec);cells=[e.u32(OBJ+0x1f0+4*k) for k in range(12)]
ck(tree!=0 and caption!=0 and all(cells),'Grid creates one owned tree, a caption and twelve cached native cells')
ck(e.u32(OBJ+0x1e8)==11,'Opening list focuses current shooting family without changing it')
ck([struct.unpack('<4i',mu.mem_read(c+0x20,16)) for c in cells]==[(20+170*(i%4),54+98*(i//4),164,92) for i in range(12)],'Native cells form a four-column three-row grid inside the body')
ck(struct.unpack('<H',mu.mem_read(caption+0xea,2))[0]==846+11,'Caption below title shows focused family English name')
ck([e.byte(c+0x101) for c in cells]==[0]*11+[1],'Exactly one cursor border, independent from enabled markers')

def icon_id(cell):return struct.unpack('<H',mu.mem_read(e.u32(cell+0xf0)+0xea,2))[0]
ck(all(struct.unpack('<4i',mu.mem_read(e.u32(c+0xf0)+0x20,16))==(0,0,164,92) for c in cells),'Native tile icons paint complete164x92 panels including background and focus')
ck([icon_id(c) for c in cells]==[788+4*i+1+(2 if i==11 else 0) for i in range(12)],'Initially enabled tiles use coloured packaging plus check assets')
ck(e.call(0x535894c0,(e.u32(OBJ+0x198),))==0,'Original vertical settings list hidden while grid active')
EVENT=0x707d0000
exit_calls=[];e.stubs[0x53182e9c]=lambda:exit_calls.append(e.u32(OBJ+0x1e8)) or 1
# Run the true BaseController entry, before widget and menu-manager routes.
def press(k):mu.mem_write(EVENT,struct.pack('<H',k));return e.call(0x53183b40,(OBJ,EVENT))
press(0xe0)
ck(not read_mask(e)&(1<<11) and icon_id(cells[11])==788+44+2,'Physical OK disables focused family and switches its asset to grey')
ck(e.u32(OBJ+0x1e8)==11 and e.call(0x535894c0,(tree,))==1,'Physical OK retains cursor and keeps list open')
press(0xd5)
ck(e.u32(OBJ+0x1e8)==12 and struct.unpack('<H',mu.mem_read(caption+0xea,2))[0]==858,'Right crosses to next page and updates name')
ck([e.call(0x535894c0,(c,)) for c in cells]==[1]*5+[0]*7,'Final page exposes only its five installed families')
press(0xd7);ck(e.u32(OBJ+0x1e8)==16,'Down reaches VISION3 in final partial grid row')
press(0xe0);ck(not read_mask(e)&(1<<16),'Final-page OK disables the correct stable VISION3 bit')
mu.mem_write(OBJ+0x1e8,struct.pack('<I',13));press(0xd7);ck(e.u32(OBJ+0x1e8)==16,'Down from an incomplete last row chooses its nearest valid tile')
press(0xd4);ck(e.u32(OBJ+0x1e8)==15,'Left selects adjacent final-page family')
# Tapping stock footer OK must stay in the manager and use the same cursor.
carrier=0x707c0000;mu.mem_write(carrier,struct.pack('<I',carrier+8));mu.mem_write(carrier+8,struct.pack('<I',OBJ));before=read_mask(e)
e.call(branch(0x531d6b50),(carrier,));ck(read_mask(e)==before^(1<<15),'Touchable OK footer uses the same focused-family toggle')
# Send genuine raw left/right packets through the original keyboard poster,
# then the actual BaseController entry. Earlier tests only injected D4/D5.
KEYBOARD=0x707c2000;RAW=0x707c1000;posted=[]
e.stubs[0x5323ebf8]=lambda:0x707c3000
def posted_event():
 posted.append((mu.reg_read(UC_ARM_REG_R1),mu.reg_read(UC_ARM_REG_R2)))
 return 0
e.stubs[0x5325c678]=posted_event
mu.mem_write(KEYBOARD,bytes(0x800))
def raw_key(key_id,status):
 mu.mem_write(RAW,struct.pack('<II',status,0));source=bytes(mu.mem_read(RAW,8));posted.clear()
 e.call(0x53270c20,(KEYBOARD,key_id,RAW))
 ck(len(posted)==1 and posted[0][0]==key_id,'Native keyboard emits the expected raw key ID')
 code,payload=posted[0];mu.mem_write(EVENT,struct.pack('<II',code,payload));event=bytes(mu.mem_read(EVENT,8))
 result=e.call(0x53183b40,(OBJ,EVENT))
 ck(bytes(mu.mem_read(EVENT,8))==event and bytes(mu.mem_read(RAW,8))==source and bytes(mu.mem_read(payload,8))==source,'Raw event, source payload and posted payload remain immutable')
 return result
# Raw physical OK (ID8) used to escape to the native accept/close path.
# Exercise complete press/release cycles on all families and both pages.
for family in range(17):
 write_mask(mu,ALL);mu.mem_write(OBJ+0x1e8,struct.pack('<I',family));prior_exit=len(exit_calls)
 ck(raw_key(8,2)==1 and read_mask(e)==ALL^(1<<family),'Raw OK press toggles exactly the focused family')
 ck(e.u32(OBJ+0x1e8)==family and e.call(0x535894c0,(tree,))==1 and len(exit_calls)==prior_exit,'Raw OK press retains page, cursor and controller lifetime')
 ck(raw_key(8,1)==1 and read_mask(e)==ALL^(1<<family) and len(exit_calls)==prior_exit,'Raw OK release cannot toggle twice or trigger native exit')
 raw_key(8,2);raw_key(8,1)
 ck(read_mask(e)==ALL and len(exit_calls)==prior_exit,'Second complete OK cycle re-enables family while keeping list open')
mu.mem_write(OBJ+0x1e8,struct.pack('<I',6));prior_mask=read_mask(e)
ck(raw_key(11,2)==1 and e.u32(OBJ+0x1e8)==5,'Raw physical LEFT moves one tile and is consumed before native Back')
ck(raw_key(11,1)==1 and e.u32(OBJ+0x1e8)==5,'LEFT release is consumed without moving a second tile')
ck(raw_key(12,2)==1 and e.u32(OBJ+0x1e8)==6,'Raw physical RIGHT moves one tile and is consumed')
ck(raw_key(12,1)==1 and e.u32(OBJ+0x1e8)==6,'RIGHT release does not duplicate movement')
ck(read_mask(e)==prior_mask and not exit_calls,'Horizontal navigation changes neither enabled state nor controller lifetime')
mu.mem_write(OBJ+0x1e8,struct.pack('<I',0));raw_key(11,2)
ck(e.u32(OBJ+0x1e8)==0 and not exit_calls,'LEFT at first tile stays on the page instead of returning')
mu.mem_write(OBJ+0x1e8,struct.pack('<I',11));raw_key(12,2)
ck(e.u32(OBJ+0x1e8)==12,'Physical RIGHT crosses from first page to second page')
raw_key(11,2);ck(e.u32(OBJ+0x1e8)==11,'Physical LEFT crosses back to first page')
mu.mem_write(OBJ+0x1e8,struct.pack('<I',16));raw_key(12,2)
ck(e.u32(OBJ+0x1e8)==16 and not exit_calls,'RIGHT at last tile is safely consumed')
mu.mem_write(OBJ+0x1e8,struct.pack('<I',6));press(0xd6)
ck(e.u32(OBJ+0x1e8)==2,'Single UP retains vertical four-column movement')
press(0xd7);ck(e.u32(OBJ+0x1e8)==6,'Single DOWN retains vertical movement')
press(0xda);ck(e.u32(OBJ+0x1e8)==5,'Held UP repeat retains horizontal previous-tile behavior')
press(0xdb);ck(e.u32(OBJ+0x1e8)==6,'Held DOWN repeat retains horizontal next-tile behavior')
# Visit every family so icon views and native text caches are warm, then stress pages.
for i in range(17):mu.mem_write(OBJ+0x1e8,struct.pack('<I',i));e.call(render,(OBJ,))
heap=e.heap[0];freed=len(frees)
for i in range(150):
 mu.mem_write(OBJ+0x1e8,struct.pack('<I', [0,11,12,16,10,15][i%6]));e.call(render,(OBJ,))
ck(tree==e.u32(OBJ+0x1e4) and cells==[e.u32(OBJ+0x1f0+4*k) for k in range(12)],'150 page traversals keep the same native grid objects')
ck(len(frees)==freed,'Page traversals do not destroy views during drawing')
ck(e.heap[0]==heap,'Page traversals do not allocate additional native objects after warmup')
# Physical keys must be consumed by the real outer dispatcher and never leak
# an OK to the parent menu manager. MENU alone requests native controller exit.
ck(not exit_calls,'All OK and cursor inputs through actual BaseController dispatcher keep page open')
for k in [0xe0,0xd4,0xd5,0xd6,0xd7,0xda,0xdb]:
 ck(press(k)==1,f'Outer dispatch consumes physical key {k:#x}')
ck(not exit_calls,'Repeated physical OK never requests native close')
press(0xe2);ck(len(exit_calls)==1,'Physical MENU requests native exit exactly once')
# Other controller types and SelectMenu records must retain original dispatch.
def native_route(ctrl,record,vtable,key_id=0xe0):
 mu.mem_write(ctrl,struct.pack('<I',vtable));mu.mem_write(ctrl+0x1a4,bytes([record]));mu.mem_write(EVENT,struct.pack('<II',key_id,RAW))
 hook=mu.hook_add(UC_HOOK_CODE,lambda uc,pc,size,ud:uc.emu_stop() if pc==0x53183b44 else None)
 mu.reg_write(UC_ARM_REG_R0,ctrl);mu.reg_write(UC_ARM_REG_R1,EVENT);mu.reg_write(UC_ARM_REG_SP,0x600f0000);mu.reg_write(UC_ARM_REG_LR,0x100)
 mu.emu_start(0x53183b40,0x53183b44,count=10000);mu.hook_del(hook)
 return mu.reg_read(UC_ARM_REG_PC)==0x53183b44
ck(native_route(OBJ,125,0x53da2c70),'Unrelated SelectMenu record retains original event dispatcher')
ck(native_route(OBJ,126,0x53da2cb0),'Different controller type with same byte126 retains original event dispatcher')
for record in (45,125,127):
 for key_id in (8,11,12):
  ck(native_route(OBJ,record,0x53da2c70,key_id),'Other settings pages keep native left/right processing')
ck(native_route(OBJ,126,0x53da2cb0,11),'Other controller type keeps native physical LEFT processing')
mu.mem_write(OBJ,struct.pack('<I',0x53da2c70));mu.mem_write(OBJ+0x1a4,b'\x7e')
# The fixture starts with the original 180px right footer, matching hardware.
# Verify the patched bounds and actual native text layout are inside the LCD.
right=e.u32(OBJ+0x188);left=e.u32(OBJ+0x184)
ck(struct.unpack('<4i',mu.mem_read(right+0x104,16))==(380,430,330,40),'Right footer expands leftward within720px screen')
ck(struct.unpack('<4i',mu.mem_read(left+0x104,16))==(10,430,250,40),'Left footer keeps separate non-overlapping bounds')
footer_text=e.u32(right+0xf8);footer_icon=e.u32(right+0xf4)
for v in [footer_icon,footer_text]:
 rect=struct.unpack('<4i',mu.mem_read(v+0x64,16))
 ck(0<=rect[0] and rect[0]+rect[2]<=720 and rect[1]>=420 and rect[1]+rect[3]<=480,f'Native footer child {v:#x} paint bounds fitLCD: {rect}')
# Save actual view state for a clearly labelled layout preview, not a camera photo.
(BASE/'grid-view-state.json').write_text(json.dumps({'screen':[720,480],'cursor':e.u32(OBJ+0x1e8),'cells':[{'rect':list(struct.unpack('<4i',mu.mem_read(c+0x20,16))),'icon':icon_id(c),'focus':e.byte(c+0x101),'visible':e.call(0x535894c0,(c,))} for c in cells],'captionId':struct.unpack('<H',mu.mem_read(caption+0xea,2))[0]},indent=2))
background=e.u32(OBJ+0x220)
icon_owners=[e.u32(c+0xf0) for c in cells]
# Teardown must dispose the single owned tree once, including all descendants.
def stop_original(uc,pc,size,ud):
 if pc==0x531cf600:uc.reg_write(UC_ARM_REG_PC,0x100);uc.emu_stop()
hook=mu.hook_add(UC_HOOK_CODE,stop_original);before=len(frees);e.call(branch(0x531cf5fc),(OBJ,));mu.hook_del(hook);released=frees[before:]
ck(released.count(caption)==1 and released.count(background)==1 and all(released.count(v)==1 for v in icon_owners),'Every caption and lazily constructed icon owner is released exactly once')
ck(released.count(tree)==1 and all(released.count(c)==1 for c in cells),'Controller closes with exactly-once tree and cell destruction')
ck(e.u32(OBJ+0x1e4)==0 and e.u32(OBJ+0x1ec)==0 and e.u32(OBJ+0x220)==0 and all(e.u32(OBJ+0x1f0+4*k)==0 for k in range(12)),'Teardown clears root, caption and cell aliases')
ck(not [c for c in e.calls if c[0] in ('ASSERT','NULL-JUMP')],'Native grid paths execute without assertion failures or null jumps')
(BASE/'v23-grid-checks.json').write_text(json.dumps({'status':'passed','passed':len(checks),'checks':checks,'hardwareTested':False,'functions':{'gridRender':render,'gridKeys':key,'enabledToggle':enabled_toggle,'mask':maskfn},'scope':'Actual ARM compact ADJ adapters and original native widgets, grid keys and footer callback, page visibility/geometry, stable identity, 150 page traversals with no object churn and cleanup. Physical rendering and storage persistence are not modelled; complete packed panel pixels verified separately. Native keyboard raw-event posting and actual BaseController raw OK/Left/Right press/release dispatch are exercised, including all17 family toggles, boundary and page transitions.'},ensure_ascii=False,indent=2))
print('PASS',len(checks),'grid, compact ADJ and native lifetime checks')
