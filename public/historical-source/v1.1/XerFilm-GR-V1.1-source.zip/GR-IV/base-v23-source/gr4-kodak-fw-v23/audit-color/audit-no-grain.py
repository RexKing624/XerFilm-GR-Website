# SPDX-License-Identifier: GPL-2.0-only
"""Read-only ARM/resource checks. Does not validate physical ISP colour semantics."""
from pathlib import Path
import importlib.util,json,struct,sys
from unicorn.arm_const import *
from unicorn import UC_HOOK_CODE,UC_HOOK_MEM_WRITE
ROOT=Path(__file__).resolve().parents[3]
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('menu_emu',ROOT/'outputs/GR4-Menu-Experiment/tools/upstream_menu_emu.py')
emu=importlib.util.module_from_spec(spec);spec.loader.exec_module(emu)
memory={};exec((W.parent/'runtime-memory.py').read_text(),memory);memory['protect_h'](emu)
sys.path.insert(0,str(ROOT/'work/gr-custom-tool'))
from gr4_editor.codec.gr4_color_matrix_codec import compose_matrices,main_coefficients
from gr4_editor.codec.gr4_gamma_codec import compose_gamma_sources
OFF=emu.Image(str(ROOT/'work/filter-analysis/RTOS.bin'))
NEW=emu.Image(sys.argv[1] if len(sys.argv)>1 else str(W/'runtime-only.rtos'))
WORDS=[w for w in json.loads((W/'patch-words.json').read_text()) if w['reason'] in ['film: effective Standard style getter','film: native image-control changes blocked while enabled','film: neutral Standard control'] or w['reason'].startswith(('film: gated ', 'film: virtual ', 'film: selected resource bank '))]
MODELS=json.loads((W/'models.json').read_text())
REGS=[UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3,UC_ARM_REG_R4,UC_ARM_REG_R5,UC_ARM_REG_R6,UC_ARM_REG_R7,UC_ARM_REG_R8,UC_ARM_REG_R9,UC_ARM_REG_R10,UC_ARM_REG_R11,UC_ARM_REG_R12,UC_ARM_REG_SP,UC_ARM_REG_LR,UC_ARM_REG_CPSR]
FLAGS=0x55084dd8+4+0x94b;SELECT=0x55084dd8+4+0x90f
TABLES={'matrix':(0x55053780,0x53925fa8),'multi':(0x55053504,0x53925fd4),'gamma':(0x55053138,0x5392602c)}
REPORT={'checks':[],'failures':[],'limitations':['ARM/resource identity checks do not establish LibRaw RGB == native ISP RGB, region interpolation, physical JPEG appearance, or preview/capture synchronization.']}
def check(condition,message,detail=None):
 REPORT['checks'].append({'pass':bool(condition),'message':message,**({'detail':detail} if detail is not None else {})})
 if not condition:REPORT['failures'].append(message)
def snapshot(e):return [e.mu.reg_read(r) for r in REGS]
def prepared(e,flag=0,style=0,cpsr=0x13):
 mu=e.mu
 for k,r in enumerate(REGS[:13]):mu.reg_write(r,0x70010000+0x1000*k+k*17)
 mu.reg_write(UC_ARM_REG_SP,0x600f0000);mu.reg_write(UC_ARM_REG_LR,0x100);mu.reg_write(UC_ARM_REG_CPSR,cpsr)
 mu.mem_write(FLAGS,bytes([flag]));mu.mem_write(SELECT,bytes([style]))
 for k in range(13):mu.mem_write(0x70010000+0x1000*k,bytes((j+k)%256 for j in range(4096)))
def step(e,site):
 e.mu.emu_start(site,site+4,count=2000)
 if e.mu.reg_read(UC_ARM_REG_PC)!=site+4:raise RuntimeError(f'Wrapper failed at {site:#x}; PC={e.mu.reg_read(UC_ARM_REG_PC):#x}')
def resource(img,kind,flag=0,film=0,bank=0):
 e=emu.Emu(img);prepared(e,flag,film)
 table,site=TABLES[kind];e.mu.reg_write(UC_ARM_REG_R0,bank*34+11);e.mu.reg_write(UC_ARM_REG_R3,table)
 step(e,site);return e.mu.reg_read(UC_ARM_REG_R0)

# The 3 hardware rows currently point at exactly the same Standard descriptors.
for kind,(table,site) in TABLES.items():
 rows=[OFF.u32(table+(bank*34+11)*4) for bank in range(3)]
 check(len(set(rows))==1,f'Original Standard {kind}: all 3 hardware banks identical',[hex(x) for x in rows])
original_basis=OFF.u32(OFF.u32(TABLES['matrix'][0]+11*4))
basis=struct.unpack('<9h',OFF.rd(original_basis,18))
check(basis!=(8192,0,0,0,8192,0,0,0,8192),'Native camera basis is non-identity and must occur once',list(basis))
clone_resources=[]
for film,model in enumerate(MODELS):
 row={'film':film+1}
 for kind,(table,site) in TABLES.items():
  original=OFF.u32(table+11*4);selected=[resource(NEW,kind,1,film,bank) for bank in range(3)]
  check(len(set(selected))==1,f'F{film+1:03} {kind}: hardware bank dispatch consistent')
  p=selected[0];a=OFF.rd(original,128);b=NEW.rd(p,128);changes=[k for k in range(128) if a[k]!=b[k]]
  allowed={'matrix':set(range(4,8)),'multi':set(range(8,12)),'gamma':set(range(4,6))|set(range(8,20))}[kind]
  check(set(changes)<=allowed,f'F{film+1:03} {kind}: only intended descriptor members changed',changes)
  if kind=='matrix':
   check(NEW.u32(p)==original_basis,f'F{film+1:03}: camera-basis pointer preserved')
   check(NEW.rd(NEW.u32(p+4),18)==bytes(model['matrix']),f'F{film+1:03}: selected matrix bytes match fitted resource')
   row['matrix_descriptor']=hex(p)
  if kind=='multi':
   wrapper=NEW.u32(p+8);blocks=[NEW.u32(wrapper+k*4) for k in range(8)]
   check(len(set(blocks))==1,f'F{film+1:03}: 8 multi-axis bank pointers agree')
   check(NEW.rd(blocks[0],2160)==bytes(model['multi']),f'F{film+1:03}: multi-axis payload matches fitted resource')
  if kind=='gamma':
   check(b[4]==1 and b[5]==0,f'F{film+1:03}: Gamma sources enabled, independent R/G/B weight 3',{'enable':b[4],'channel_mix':b[5]})
   actual=b''.join(NEW.rd(NEW.u32(p+8+c*4),512) for c in range(3))
   check(actual==bytes(model['gamma']),f'F{film+1:03}: Gamma channel payloads match fitted resource')
 clone_resources.append(row)
REPORT['clone_resources']=clone_resources

# Every inline substitution must behave exactly like its original instruction when disabled.
oe,ne=emu.Emu(OFF),emu.Emu(NEW)
logs={id(oe):[],id(ne):[]}
for e in (oe,ne):
 def memory_write(uc,access,address,size,value,user_data,e=e):
  if not 0x60000000<=address<0x60100000:logs[id(e)].append((address,size,value))
 e.mu.hook_add(UC_HOOK_MEM_WRITE,memory_write)
off_cases=0
for word in WORDS:
 site=word['address']
 for flag in (0,2,4,6,254,255):
  for bits in (0,1,3,5,10,15):
   cpsr=0x13|(bits<<28)|0x08000000
   for e in (oe,ne):
    prepared(e,flag,0,cpsr)
    logs[id(e)].clear()
    for kind,(table,loadsite) in TABLES.items():
     if site==loadsite:e.mu.reg_write(UC_ARM_REG_R0,45);e.mu.reg_write(UC_ARM_REG_R3,table)
   try:
    step(oe,site);step(ne,site)
    old,new=snapshot(oe),snapshot(ne)
    differences=[{'register':str(REGS[k]),'original':hex(a),'patched':hex(b)} for k,(a,b) in enumerate(zip(old,new)) if a!=b]
    check(not differences,f'Off transparency {site:#x}, state {flag}, NZCV {bits}',differences or None)
    check(logs[id(oe)]==logs[id(ne)],f'Off external-memory transparency {site:#x}, state {flag}, NZCV {bits}',{'original':logs[id(oe)],'patched':logs[id(ne)]} if logs[id(oe)]!=logs[id(ne)] else None)
    off_cases+=1
   except Exception as error:check(False,f'Off transparency execution error {site:#x}',str(error))
REPORT['off_cases']=off_cases

# Every virtual read changes only its result register, including all NZCV combinations.
reads={'0x79c':json.loads((W.parent/'virtual-reads.json').read_text())['0x79c']}
ne=emu.Emu(NEW);on_cases=0
sidecar={};exec((W.parent/'sidecar-fixture.py').read_text(),sidecar)
for field,rows in reads.items():
 for load in rows:
  site=load['address']
  if site in (0x539113f8,0x537150fc) or 0x537da000<=site<0x537df000:continue
  for flag in (1,):
   for bits in (0,1,3,5,10,15):
    prepared(ne,flag,7,0x13|(bits<<28)|0x08000000)
    # Grain preparation now owns these two tone reads using the captured shot.
    if site in (0x53701c8c,0x53701e20):
     base=ne.mu.reg_read(REGS[load['rn']]);ne.mu.mem_write(base+0x94b,b'\1');sidecar['register'](ne.mu,base)
    before=snapshot(ne);step(ne,site);after=snapshot(ne)
    expected={'0x79c':11,'0x7b5':1,'0x7b6':0,'0x7b7':flag>>1}[field]
    before[load['rd']]=expected
    diff=[k for k,(a,b) in enumerate(zip(before,after)) if a!=b]
    check(not diff,f'Enabled virtual read {site:#x} {field}, state {flag}, NZCV {bits}',diff or None)
    on_cases+=1
REPORT['on_virtual_cases']=on_cases

# Prove the recovered native matrix routine performs fitted style @ camera basis exactly once.
e=emu.Emu(OFF)
for film,model in enumerate(MODELS):
 first=struct.unpack('<9h',bytes(model['matrix']));a,b,out=0x70001000,0x70002000,0x70003000
 e.mu.mem_write(a,struct.pack('<9i',*first));e.mu.mem_write(b,struct.pack('<9i',*basis));
 e.call(0x53914da4,(0,out,a,b),limit=10000)
 actual=list(struct.unpack('<9i',e.mu.mem_read(out,36)));expected=compose_matrices(first,basis)
 check(actual==expected,f'F{film+1:03}: native Q13 composition is fitted style @ camera basis once',{'actual':actual,'expected':expected})

# Run the complete native main matrix coefficient generator, including saturation and s12 clamp.
e=emu.Emu(NEW)
def copy_native():
 mu=e.mu;dest,source,size=(mu.reg_read(r) for r in REGS[:3]);mu.mem_write(dest,bytes(mu.mem_read(source,size)));return dest
e.stubs[0x53156140]=copy_native
obj,out=0x70040000,0x70050000
for film,model in enumerate(MODELS):
 desc=resource(NEW,'matrix',1,film)
 e.mu.mem_write(obj,bytes(256));e.mu.mem_write(out,bytes(256));e.mu.mem_write(obj+8,struct.pack('<I',desc))
 e.mu.mem_write(obj+0x57,b'\x04\x04');e.mu.mem_write(obj+0x5a,struct.pack('<H',256))
 e.call(0x53914e20,(out,obj),limit=100000)
 actual=[struct.unpack('<h',e.mu.mem_read(out+4+k*4,2))[0] for k in range(9)]
 first=struct.unpack('<9h',bytes(model['matrix']));saturation=OFF.u16(0x540484a4+4*2)
 expected=main_coefficients(first,basis,saturation,256,True)
 check(actual==expected,f'F{film+1:03}: native main coefficients match style @ basis, saturation and clamp',{'actual':actual,'expected':expected,'saturation_factor':saturation})

# Exercise native gamma source loading and composition with each selected descriptor.
# Original native code generates more hardware LUT words after +0x630; stop before that stage.
e=emu.Emu(NEW);gamma_out,gamma_obj=0x70060000,0x70065000
base_ptr=OFF.u32(OFF.u32(TABLES['gamma'][0]+11*4))
base=struct.unpack('<256H',OFF.rd(base_ptr,512))
for film,model in enumerate(MODELS):
 desc=resource(NEW,'gamma',1,film)
 e.mu.mem_write(gamma_out,bytes(0x4000));e.mu.mem_write(gamma_out,struct.pack('<256H',*base))
 e.mu.mem_write(gamma_obj,bytes(256));e.mu.mem_write(gamma_obj+0x14,struct.pack('<I',desc))
 prepared(e,1,film);e.mu.reg_write(UC_ARM_REG_R0,gamma_out);e.mu.reg_write(UC_ARM_REG_R1,gamma_obj)
 e.mu.emu_start(0x5391e340,0x5391e630,count=100000)
 ended=e.mu.reg_read(UC_ARM_REG_PC)==0x5391e630
 check(ended,f'F{film+1:03}: native Gamma reaches enabled RGB source path',hex(e.mu.reg_read(UC_ARM_REG_PC)))
 sources=[list(struct.unpack('<256H',bytes(model['gamma'][c*512:(c+1)*512]))) for c in range(3)]
 loaded,composed=compose_gamma_sources(base,sources)
 actual_loaded=[list(struct.unpack('<256H',e.mu.mem_read(gamma_out+0x200+c*0x200,512))) for c in range(3)]
 actual_composed=[list(struct.unpack('<256H',e.mu.mem_read(gamma_out+c*0x2000,512))) for c in range(4)]
 # RGB composition goes to the initial base addresses +0, +0x2000, +0x2800;
 # verify source loading here, which is enough to catch disabled descriptor flags.
 check(actual_loaded==loaded,f'F{film+1:03}: native RGB Gamma loads all fitted channel samples')
REPORT['relative_mapping_boundary']='Descriptor+0 retains native camera basis; descriptor+4 is new fitted style. Native ARM composition is style @ basis exactly once. This proves coefficient ABI, not that fitting in LibRaw linear sRGB matches native pre-style input. Current fit does not multiply by native Standard style matrix; it fits post-basis proxy RGB, not measured native Standard colours.'
(W/'report.json').write_text(json.dumps(REPORT,ensure_ascii=False,indent=2))
print(json.dumps({'checks':len(REPORT['checks']),'off_cases':off_cases,'on_virtual_cases':on_cases,'failures':REPORT['failures'],'output':str(W/'report.json')},ensure_ascii=False,indent=2))
sys.exit(bool(REPORT['failures']))
