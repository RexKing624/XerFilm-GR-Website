# SPDX-License-Identifier: GPL-2.0-only
"""Regress real pool-before-exposure ordering, not bind-after-choice fixtures.
Executes native JPEG writer/decoder/IFD code, exposure dispatcher, original pool
bind and emitted ctor entry. Clock/calibration/device services are bounded stubs.
"""
from pathlib import Path
import os,struct,json
HERE=Path(__file__).resolve().parent;os.chdir(HERE.parent.parent)
exec((HERE/'emu-v6.py').read_text(),globals())
from unicorn import arm_const as A
NEW=HERE/'build-v23-a/candidate.bin.rtos';OLD=HERE.parent/'gr4-kodak-fw-v22/build-v22-a/candidate.bin.rtos'
U=0x55084dd8+4;SI=0x700a0000;JOB=0x70010000;JW=0x70070000;DESC=0x700b0000;ENTRY=0x70090000;PROP=0x700c0000
checks=[]
def ck(ok,s):
 if not ok:raise AssertionError(s)
 checks.append(s)
def word(e,a,v):e.mu.mem_write(a,struct.pack('<I',v))
def prefs(e,on,look):
 e.mu.mem_write(U+0x94b,bytes([on]));e.mu.mem_write(U+0x90f,bytes([look]));e.mu.mem_write(U+0x49,(0x400000|5<<19|3<<17|0x1ffff).to_bytes(3,'little'))
def setup(p):
 e,_=make(str(p));word(e,0x707d0000,0x707d0100);word(e,0x707d0108,0x707d0200);word(e,0x553a0850,0x707d0400)
 e.stubs[0x53799b70]=lambda:0x707d0000
 def alloc():
  q=e.heap[0];e.heap[0]+=(e.mu.reg_read(A.UC_ARM_REG_R1)*4+15)&~15;return q
 e.stubs[0x707d0200]=alloc
 e.mu.reg_write(A.UC_ARM_REG_SP,0x600f0000);e.mu.emu_start(0x537ae810,0x537ae888,count=10000)
 e.call(0x53809564,(JW,));e.call(0x538048b0,(DESC,));e.call(0x5380494c,(DESC,SI));e.call(0x5380480c,(JW+0x240,DESC))
 callbacks=[]
 for a in (0x536650fc,0x53664d5c,0x53664e10):
  def service(a=a):callbacks.append((a,e.mu.reg_read(A.UC_ARM_REG_R1)));return 0
  e.stubs[a]=service
 return e,callbacks
new,callbacks=setup(NEW);old,old_callbacks=setup(OLD)
def pool(e,on,look):
 prefs(e,on,look);m=e.mu
 for r,v in [(A.UC_ARM_REG_R0,JOB),(A.UC_ARM_REG_R1,SI),(A.UC_ARM_REG_R2,0),(A.UC_ARM_REG_SP,0x600f0000),(A.UC_ARM_REG_LR,0x100)]:m.reg_write(r,v)
 m.emu_start(0x5370fecc,0x5370fed0,count=10000)
 ck(m.reg_read(A.UC_ARM_REG_PC)==0x5370fed0,'Preallocated job reaches original constructor prologue')
 e.call(0x537119a0,(JOB,0x1234,SI))
 ck(e.u32(JOB+0x4688)==SI,'Pool bind preserves native pointer')
def save(e):
 e.mu.mem_write(ENTRY,struct.pack('<IHHIII B3x',0,0x4f,3,1,0xdeadbeef,0,1))
 setter=JW+0x240;e.call(e.u32(e.u32(setter)+0x14),(setter,ENTRY))
 value=struct.unpack('<H',e.mu.mem_read(ENTRY+12,2))[0]
 e.call(0x537d8994,(0,PROP,ENTRY))
 return value,e.call(0x537d3f30,(PROP,0x25))
sequence=[(1,10),(1,11),(1,12),(1,23),(0,0),(1,20),(1,22),(1,19),(1,0)]*8
previous=(0,0);rows=[]
for index,(on,look) in enumerate(sequence):
 for e in (old,new):
  pool(e,*previous);prefs(e,on,look);e.mu.mem_write(SI+0x79c,b'\x0b')
  native=bytes(e.mu.mem_read(SI,0x1000));live=bytes(e.mu.mem_read(U,0x1000))
  e.call(0x536651e4,(0,SI,0))
  ck(bytes(e.mu.mem_read(SI,0x1000))==native and bytes(e.mu.mem_read(U,0x1000))==live,'Exposure registration leaves original shot and user bytes unchanged')
 old_value,_=save(old)
 ck(old_value==(0x8200+previous[1] if previous[0] else 0x100),'v22 reproduces previous-frame identity when pool precedes exposure')
 # A later choice and even pool rebind must not replace current-shot identity.
 prefs(new,1-on,(look+7)%27);new.call(0x537119a0,(JOB,0x1234,SI))
 got,decoded=save(new)
 ck(got==(0x8200+look if on else 0x100),'v23 saves this exposure rather than the previous/later choice')
 ck(decoded==(128+look if on else 1),'Native photo decoder returns this exposure identity or native OFF')
 rows.append({'sequence':index,'filmOn':bool(on),'look':look,'v22Written':old_value,'v23Written':got})
 previous=(on,look)
ck(len(callbacks)==len(sequence)*3 and all(key==SI for _,key in callbacks),'Native exposure dispatcher retains all three date/identity services and the exact shot argument')
# Preserve all native function-entry inputs, callee-saved values and flags.
regs=[getattr(A,f'UC_ARM_REG_R{i}')for i in range(13)]+[A.UC_ARM_REG_SP,A.UC_ARM_REG_LR,A.UC_ARM_REG_CPSR]
for index,r in enumerate(regs[:13]):new.mu.reg_write(r,0x70010000+index*0x100)
new.mu.reg_write(A.UC_ARM_REG_CPSR,0xa8000013);new.mu.reg_write(A.UC_ARM_REG_R1,SI);new.mu.reg_write(A.UC_ARM_REG_SP,0x600f0000);new.mu.reg_write(A.UC_ARM_REG_LR,0x100)
before=[new.mu.reg_read(r)for r in regs];shot=bytes(new.mu.mem_read(SI,0x1000))
stop=new.mu.hook_add(UC_HOOK_CODE,lambda uc,pc,size,ud:uc.emu_stop()if pc==0x536651e8 else None)
new.mu.emu_start(0x536651e4,0x100,count=10000);new.mu.hook_del(stop)
ck(new.mu.reg_read(A.UC_ARM_REG_PC)==0x536651e8,'Exposure wrapper returns to the exact native prologue continuation')
after=[new.mu.reg_read(r)for r in regs];before[12]=before[13]
ck(after==before and bytes(new.mu.mem_read(SI,0x1000))==shot,'Exposure hook preserves every native entry register/NZCV and original ShotInfo bytes')
N=h.Image(str(NEW));O=h.Image('work/filter-analysis/RTOS.bin')
for a,n in [(0x5370fec8,0x30),(0x537119a0,16)]:ck(N.rd(a,n)==O.rd(a,n),'Preallocation/bind code restored byte-for-byte to native')
ck(not[c for c in new.calls if c[0]in('ASSERT','NULL-JUMP')],'Capture order regression has no failed native assertions')
(HERE/'v23-exposure-order-checks.json').write_text(json.dumps({'passed':True,'count':len(checks),'checks':checks,'sequences':rows,'hardwareTested':False,'scope':'72 sequential pool-before-exposure lifecycles; v22 lag reproduced; new dispatcher and original pool rebind; actual JPEG setter/IFD and photo decoder; live changes after exposure; date/calibration/clock/DSP services not emulated.'},ensure_ascii=False,indent=2))
print('PASS',len(checks),'per-exposure ordering checks with v22 regression')
