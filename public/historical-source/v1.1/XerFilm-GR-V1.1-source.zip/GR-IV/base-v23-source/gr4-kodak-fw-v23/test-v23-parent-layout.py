# SPDX-License-Identifier: GPL-2.0-only
# Run the original three-row submenu builder, including native row icon layout.
from pathlib import Path
import os,json,struct
HERE=Path(__file__).resolve().parent
os.chdir(HERE.parent.parent)
exec((HERE/'emu-v6.py').read_text())
BASE=HERE
reports=[]
for name,path in [('v13',HERE.parent/'gr4-kodak-fw-v13/build-v13-a/candidate.bin.rtos'),('v18',HERE/'build-v23-a/candidate.bin.rtos')]:
 e,draws=make(str(path));mu=e.mu;img=h.Image(str(path))
 e.record.pop(0x53583188,None) # Execute actual SubMenuItem::SetIcon, not its fixture recorder.
 e.stubs[0x5323bddc]=lambda:0x707b0400
 e.stubs[0x5323dbf0]=lambda:40;e.stubs[0x5323dc10]=lambda:40
 e.stubs[0x538ee49c]=lambda:e.calls.append(('ASSERT',hex(mu.reg_read(UC_ARM_REG_LR)))) or 0 if not mu.reg_read(UC_ARM_REG_R0) else 0
 D=0x707f0000
 def create(kind,x,y,w,ht):
  mu.mem_write(D,struct.pack('<6I',kind,x,y,w,ht,0));return e.call(0x53589ee4,(D,))
 root=create(1,0,0,720,480);panel=create(13,0,60,720,300)
 e.call(0x53588158,(root,panel));mu.mem_write(OBJ+0x170,struct.pack('<I',panel))
 types=0x707e0000;mu.mem_write(types,bytes([34])*5)
 e.call(0x5357094c,(panel,types,5,60))
 mu.mem_write(OBJ+0x174,b'\x13');mu.mem_write(OBJ+0x175,b'\0')
 U=0x55084dd8+4;mu.mem_write(U+0x94b,b'\1');mu.mem_write(U+0x90f,b'\0');mu.mem_write(U+0x49,(0xca0000|0x1ffff).to_bytes(3,'little'))
 e.call(0x531e2424,(OBJ,)) # Native record -> rows -> title -> value X -> draw callback.
 subtable=img.movw_movt(0x531e2438,0x531e2444);record=subtable+19*100
 nrows=4 if name=='v18' else 3
 rows=[e.call(0x53570a9c,(panel,i)) for i in range(nrows)]
 icons=[e.u32(v+0xf0) for v in rows];titles=[e.u32(v+0xec) for v in rows]
 anchors=[e.u32(v+0x108) for v in rows]
 rects=[list(struct.unpack('<4i',mu.mem_read(v+0x20,16))) for v in icons]
 ck(anchors==[540]*nrows,f'{name}: original native builder uses per-row value anchors {anchors}')
 ck([r[0] for r in rects]==anchors,f'{name}: actual native icon geometry follows the record, including grain row')
 ck([struct.unpack('<H',mu.mem_read(v+0xea,2))[0] for v in titles]==([842,843,879,883] if name=='v18' else [842,843,879]),f'{name}: row titles are Switch / Film List / Grain')
 ck(struct.unpack('<H',mu.mem_read(icons[2]+0xea,2))[0]==311,f'{name}: grain ON status remains the expected original icon')
 ck(not [v for v in e.calls if v[0] in ('ASSERT','NULL-JUMP')],f'{name}: native submenu building has no failed assertion')
 ck(struct.unpack('<H',mu.mem_read(icons[1]+0xea,2))[0]==(721 if name=='v13' else 732),f'{name}: Film List entry uses expected old-family / new fixed FILM icon')
 if name=='v18':
  for on in (0,1):
   for look in range(27):
    mu.mem_write(U+0x94b,bytes([on]));mu.mem_write(U+0x90f,bytes([look]));e.call(0x531e2424,(OBJ,))
    ck(struct.unpack('<H',mu.mem_read(icons[1]+0xea,2))[0]==732,f'Fixed FILM entry survives switch{on}, selected look{look}')
 reports.append({'version':name,'recordValueX':[img.u32(record+0x28+4*i) for i in range(nrows)],'nativeIconRects':rects})
(BASE/'v23-parent-layout-checks.json').write_text(json.dumps({'passed':True,'checks':checks,'comparisons':reports,'hardwareTested':False,'scope':'Original native SubMenu builder and SubMenuItem icon geometry. Preserves right-aligned native value icons and verifies Film List entry stays FILM ID732 for all27 looks with simulation ON/OFF. Compares v13 previous dynamic family icon with v18 fixed icon.'},ensure_ascii=False,indent=2))
print('PASS',len(checks),'native submenu checks; fixed FILM entry and right-aligned grain value')
