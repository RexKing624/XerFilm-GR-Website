# SPDX-License-Identifier: GPL-2.0-only
from pathlib import Path
import json,shutil,hashlib,zipfile
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
D=ROOT/'outputs/GR4-v23-H-高小版本-2026-10-19';R=json.loads((D/'build-report.json').read_text())
I=json.loads((D/'independent-checks.json').read_text());N=json.loads((W/'native-checks.json').read_text())
assert I['passed'] and N['passed'] and all(R['checks'].values())
assert I['sha256']==R['sha256']==hashlib.sha256((D/'fwdc248b.bin').read_bytes()).hexdigest()
assert hashlib.sha256((ROOT/R['basePath']).read_bytes()).hexdigest()==R['baseSHA256']
shutil.copyfile(W/'native-checks.json',D/'native-checks.json')
shutil.copyfile(ROOT/'work/gr4-kodak-fw-v23/LICENSE',D/'LICENSE')
(D/'SHA256.txt').write_text(R['sha256']+'  fwdc248b.bin\n')
(D/'使用说明.txt').write_text('''XerFilm GR IV v23-H — 高小版本完整功能版
内部版本：1.12.10.7；机内显示：1.12。

这是一份保留全部v23功能的高版本固件，不是只有原厂功能的中转固件。
适用于因隐藏小版本较高、拒绝安装公开1.11版本的新出厂GR IV进行实机测试。
它仍基于理光官方1.11，并不是理光发布的官方1.12。
仅面向GR IV；不用于GR III、GR IIIx、GR IV Monochrome。
本包未建立GR IV HDF的实机兼容性，不作为HDF发布。

修改范围
参考Maxwooow/Ricoh-GRMod v0.8.0的桥接实现，同步提高RTOS/SRIC/CPU和容器中已有版本字段至1.12.10.7，并修改RTOS更新程序的低版本拒绝路径。
同时保留该上游桥接方案对应的辅助组件内部校验修正。
只对v23成品做严格限定的修改，不重建胶片逻辑、不修改胶片参数与图标。
解码后的20个变化字节全部属于上述桥接改动及最终校验补偿；其他v23字节完全一致。
胶片列表、ADJ母子菜单、ISO适配颗粒、时间戳和回放INFO功能代码保持v23版本。

使用
固件文件必须保留名称 fwdc248b.bin，放到相机存储卡根目录，按GR IV正常固件更新方式安装（按住MENU开机）。
这是完整v23-H包，不需要先刷一个空的中转固件再刷本包。
已能正常使用原v23的机器没有必要仅为提高版本号而刷入本包。
保留已确认可用的原v23作为回退文件。

验证范围
与原v23的逐字节差异审计、独立Python解码、容器及校验和、全部段布局、辅助固件校验对应、两次构建一致性均通过。
本地ARM模拟器执行5个版本读取入口及更新拒绝分支，6项检查通过。
没有进行实机更新、开机、拍摄或新出厂硬件兼容性验证，不能据此保证安装成功。
提高版本号只解决版本门槛；它不保证所有新硬件都与旧官方1.11组件兼容。第三方固件有相机无法启动等风险。
此次没有写入存储卡、没有刷写相机、没有改动网站下载，也没有覆盖原v23。

源码
源码与验证.zip包含本次构建脚本、差异来源、全部本地检查，以及原v23源码包和GR Mod v0.8.0源码包。
相关代码依原GPL-2.0-only授权；许可证随附。原厂固件仍属理光。
''')
(D/'验证汇总.json').write_text(json.dumps({'passed':True,'hardwareTested':False,'sha256':R['sha256'],'bytes':R['bytes'],'version':'1.12.10.7','decodedChangedBytes':20,'independentChecks':I['count'],'nativeChecks':N['count'],'checks':R['checks'],'limitations':R['limitations']},ensure_ascii=False,indent=2))
source=D/'源码与验证.zip'
with zipfile.ZipFile(source,'x',compression=zipfile.ZIP_DEFLATED)as z:
 for name in ['inspect.ts','build.ts','verify.py','test-native.py','package.py','upstream-diff.json','native-checks.json']:
  z.write(W/name,'work/gr4-v23-high-version-20261019/'+name)
 for p in sorted((W/'upstream').glob('*')):z.write(p,'work/gr4-v23-high-version-20261019/upstream/'+p.name)
 z.write(ROOT/'outputs/GR4-INFO逐张身份与子菜单确认-v23/源码与验证.zip','base-v23-source.zip')
 z.write(Path('/Users/xer/Documents/Codex/GRMod-0.8.0-桥接研究/source-v0.8.0.tar.gz'),'third_party/Ricoh-GRMod-v0.8.0-source.tar.gz')
 for n in ['build-report.json','independent-checks.json','native-checks.json','验证汇总.json','LICENSE']:z.write(D/n,'reports/'+n)
 z.writestr('README.txt','''GPL-2.0-only. Bridge source: Maxwooow/Ricoh-GRMod v0.8.0 (16327db).
No full original Ricoh firmware or user photos in this source archive.
Reproduction needs Node22 with vite-node2 and the original v23 source archive (base-v23-source.zip), plus the exact official GR IV1.11 input and v23 binary identified in build-report.json.
Unpack base-v23-source.zip into work/gr4-kodak-fw-v23 with its original dependencies; it contains the build pipeline for the base v23 firmware.
Provide the matching original v23 binary at outputs/GR4-INFO逐张身份与子菜单确认-v23/fwdc248b.bin.
From workspace root run vite-node work/gr4-v23-high-version-20261019/inspect.ts /path/to/official/fwdc248b.bin, then vite-node work/gr4-v23-high-version-20261019/build.ts NEW_OUTPUT_DIRECTORY.
inspect.ts reconstructs the exact upstream bridge in memory using its publicly supplied delta and verifies SHA256 before mapping section-relative changes.
build.ts copies only guarded section-relative changes into v23, fixes the v23 checksum, repacks and verifies reproducibility and exact feature preservation.
verify.py independently decodes with gr-custom-tool Python codec. test-native.py needs Unicorn/Capstone and permission for local JIT; it executes only the five native version accessors and the reviewed update-rejection branch. No camera is connected or flashed.
Base v23 source includes the existing full v23 code and checks. Source package names may need restoring to the workspace paths shown in the scripts. The new build output requires independent hardware testing.
''')
with zipfile.ZipFile(source)as z:assert z.testzip()is None
archive=D/'XerFilm-GRIV-v23-H-1.12.10.7.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED)as z:
 for p in sorted(D.iterdir()):
  if p.is_file()and p!=archive:z.write(p,p.name)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
print(json.dumps({'archive':str(archive),'firmware':str(D/'fwdc248b.bin'),'sha256':R['sha256'],'bytes':R['bytes'],'checks':[I['count'],N['count']]},ensure_ascii=False,indent=2))
