# SPDX-License-Identifier: GPL-2.0-only
"""Independent strict Python decoder, structural and exact-feature-preservation checks."""
from pathlib import Path
import sys,json,struct,hashlib
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'work/gr-custom-tool'))
from gr4_editor.codec.container import inspect_container,sum32
from gr4_editor.codec.frames import decode_payload,section_rows
from capstone import Cs,CS_ARCH_ARM,CS_MODE_ARM
W=Path(__file__).resolve().parent;D=ROOT/'outputs/GR4-v23-H-高小版本-2026-10-19'
report=json.loads((D/'build-report.json').read_text());checks=[]
def ck(ok,name):
 if not ok:raise AssertionError(name)
 checks.append(name)
def decode(p):
 raw=p.read_bytes();c=inspect_container(raw);ck(c['additive_sum32']==0,str(p.name)+' file sum')
 dec,frames=decode_payload(raw[128:128+c['encoded_size']],c['decoded_size'])
 ck(sum32(dec)==0,str(p.name)+' decoded sum');return raw,c,dec,frames
a,ac,ad,af=decode(ROOT/report['basePath']);b,bc,bd,bf=decode(D/'fwdc248b.bin')
ck(hashlib.sha256(a).hexdigest()==report['baseSHA256'],'original v23 hash')
ck(hashlib.sha256(b).hexdigest()==report['sha256'],'high version hash')
ck(bc['project']==ac['project']==0x27c,'GR IV project identity')
ck(bc['firmware_type']==ac['firmware_type'],'firmware type unchanged')
ck(bc['decoded_size']==ac['decoded_size'],'no decoded size change')
ck(len(af)==len(bf),'frame count unchanged')
ck(bc['header_record_count']==ac['header_record_count'],'model count unchanged')
ck(all(report['checks'].values()),'all TypeScript structural checks passed')
expected={}
for p in report['payloadPatches']:
 o=p['offset'];before=bytes.fromhex(p['before']);after=bytes.fromhex(p['after'])
 ck(ad[o:o+len(before)]==before and bd[o:o+len(after)]==after,'reviewed section patch '+p['section']+' '+hex(p['relativeOffset']))
 for k in range(len(after)):expected[o+k]=after[k]
restored=bytearray(bd)
for p in report['payloadPatches']:restored[p['offset']:p['offset']+len(bytes.fromhex(p['before']))]=bytes.fromhex(p['before'])
restored[-4:]=ad[-4:]
ck(bytes(restored)==ad,'independent decoder: every original v23 byte is preserved except the reviewed bridge changes and final checksum')
ck(sum(x!=y for x,y in zip(ad,bd))==20,'exactly 20 decoded bytes differ')
rows=section_rows(bd);old=section_rows(ad);ck(rows==old,'all section geometry and flags unchanged')
rt=next(s for s in rows if s['name']=='RTOS');rtos=bd[rt['start']+16:rt['end']]
offrt=(W/'official.decoded').read_bytes();origref=(W/'upstream-bridge.decoded').read_bytes()
rs=json.loads((W/'upstream-diff.json').read_text())['sections']
for s in rows:
 if s['name'] not in ('RTOS','SRIC','CPU'):
  ck(ad[s['start']:s['end']]==bd[s['start']:s['end']],'entire section preserved: '+s['name'])
for name in ['SRIC','CPU']:
 s=next(s for s in rows if s['name']==name);ref=next(s for s in rs if s['name']==name)
 ck(bd[s['start']+16:s['end']]==origref[ref['offset']:ref['offset']+ref['size']],name+' exactly matches upstream verified bridge including embedded checksum')
ck(struct.unpack_from('<I',rtos,0xfe50f8)[0]==0x010c0a07,'runtime version 1.12.10.7')
md=Cs(CS_ARCH_ARM,CS_MODE_ARM);changed=next(md.disasm(rtos[0x83188c:0x831890],0x5383188c))
ck(changed.mnemonic=='b' and changed.op_str=='#0x53831804','updater old-version rejection branches to original success path')
ck(rtos[0x83171c:0x83188c]==ad[rt['start']+16+0x83171c:rt['start']+16+0x83188c],'all updater reads and comparisons before rejection unchanged')
ck(rtos[0x831890:0x83198c]==ad[rt['start']+16+0x831890:rt['start']+16+0x83198c],'remaining updater gate and return/guard paths unchanged')
newhead=bytearray(b[:128]);oldhead=a[:128]
for p in report['headerPatches']:newhead[p['offset']:p['offset']+len(bytes.fromhex(p['before']))]=bytes.fromhex(p['before'])
ck(bytes(newhead)==oldhead,'header differs only at reviewed version fields')
models=bytearray(b[bc['metadata_start']:-24]);oldmodels=a[ac['metadata_start']:-24]
for p in report['modelPatches']:models[p['offset']:p['offset']+len(bytes.fromhex(p['before']))]=bytes.fromhex(p['before'])
ck(bytes(models)==oldmodels,'model records differ only at reviewed version fields')
result={'passed':True,'count':len(checks),'checks':checks,'hardwareTested':False,'decoder':'independent strict Python codec','sha256':report['sha256']}
(D/'independent-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print('PASS',len(checks),'independent structural and preservation checks')
