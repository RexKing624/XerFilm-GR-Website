# SPDX-License-Identifier: GPL-2.0-only
"""Executes native version accessors and only the reviewed updater branch; never flash routines."""
from pathlib import Path
import json,struct
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_ARM,UC_PROT_READ,UC_PROT_EXEC
from unicorn.arm_const import UC_ARM_REG_R0,UC_ARM_REG_LR,UC_ARM_REG_PC
W=Path(__file__).resolve().parent;d=(W/'high-version.rtos').read_bytes()
u=Uc(UC_ARCH_ARM,UC_MODE_ARM);size=(len(d)+0xfff)&~0xfff;u.mem_map(0x53000000,size);u.mem_write(0x53000000,d);u.mem_protect(0x53000000,size,UC_PROT_READ|UC_PROT_EXEC)
u.mem_map(0x70000000,0x1000);sentinel=0x70000000;checks=[]
for address,expected in [(0x53a78498,0x010c0a07),(0x53a784a4,1),(0x53a784ac,12),(0x53a784b4,10),(0x53a784bc,7)]:
 u.reg_write(UC_ARM_REG_R0,0xdeadbeef);u.reg_write(UC_ARM_REG_LR,sentinel);u.emu_start(address,sentinel,count=16)
 actual=u.reg_read(UC_ARM_REG_R0);assert actual==expected,(hex(address),hex(actual),hex(expected));checks.append({'address':hex(address),'returned':hex(actual),'passed':True})
u.emu_start(0x5383188c,0x53831804,count=1);assert u.reg_read(UC_ARM_REG_PC)==0x53831804
checks.append({'address':'0x5383188c','target':'0x53831804','passed':True})
report={'passed':True,'count':len(checks),'checks':checks,'hardwareTested':False,'scope':'Native ARM version accessors and reviewed rejection branch only; no full boot, flash or peripheral simulation.'}
(W/'native-checks.json').write_text(json.dumps(report,indent=2));print('PASS',len(checks),'native ARM accessor/branch checks')
