// SPDX-License-Identifier: GPL-2.0-only
import {readFileSync,writeFileSync} from 'node:fs';
import {inflateSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {Firmware,sectionsOf} from '../gr4-kodak-fw-v23/core/src/fw/container';
import {BRIDGE_FORWARD} from './upstream/bridge-data';
const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
const base=new Uint8Array(readFileSync(process.argv[2]||'/Users/xer/Documents/Codex/2026-10-08/https-github-com-doyitnow-gr-custom/outputs/GR-IV-1.11/fwdc248b.bin'));
if(sha(base)!=='a2f664dfca034059eb0fd6e18ab08684c326b4a034d85c164dad7e1ec9b5655f')throw Error('Not official input');
const patch=inflateSync(Buffer.from(BRIDGE_FORWARD,'base64'));if(patch.subarray(0,5).toString()!=='GRMP1')throw Error('patch magic');
const out=Buffer.alloc(patch.readUInt32LE(5));let i=9,o=0;
while(patch[i]){if(patch[i]===1){const a=patch.readUInt32LE(i+1),n=patch.readUInt32LE(i+5);out.set(base.subarray(a,a+n),o);o+=n;i+=9;}else if(patch[i]===2){const n=patch.readUInt32LE(i+1);out.set(patch.subarray(i+5,i+5+n),o);o+=n;i+=5+n;}else throw Error('patch opcode');}
if(o!==out.length||sha(out)!=='ecdfc3034441d9f1cc4684955de546a6d3d4bb495470a48fb8e1d84971659adb')throw Error('bridge hash');
const f=new Firmware(base),g=new Firmware(out);
function diff(a:Uint8Array,b:Uint8Array){if(a.length!==b.length)throw Error('unequal lengths');const changes=[];for(let i=0;i<a.length;){if(a[i]===b[i]){i++;continue;}const p=i;while(i<a.length&&a[i]!==b[i])i++;changes.push({offset:p,hex:'0x'+p.toString(16),before:Buffer.from(a.subarray(p,i)).toString('hex'),after:Buffer.from(b.subarray(p,i)).toString('hex')});}return changes;}
const report={official:sha(base),bridge:sha(out),sections:sectionsOf(f.decoded),payload:diff(f.decoded,g.decoded),header:diff(f.header,g.header),models:diff(f.models,g.models),types:[f.fType,g.fType]};
console.log(JSON.stringify(report,null,2));
const dir='work/gr4-v23-high-version-20261019/';writeFileSync(dir+'upstream-diff.json',JSON.stringify(report,null,2));
writeFileSync(dir+'official.decoded',f.decoded);writeFileSync(dir+'upstream-bridge.decoded',g.decoded);
writeFileSync(dir+'v23.decoded',new Firmware(new Uint8Array(readFileSync('outputs/GR4-INFO逐张身份与子菜单确认-v23/fwdc248b.bin'))).decoded);
