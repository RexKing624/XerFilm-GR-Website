// SPDX-License-Identifier: GPL-2.0-only
// Uses the section-relative, byte-exact delta of GR Mod v0.8.0's verified bridge.
// No feature source or existing delivered firmware is modified.
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {Firmware,build,verifyContainer,sum32,sectionsOf} from '../gr4-kodak-fw-v23/core/src/fw/container';
const W='work/gr4-v23-high-version-20261019/';
const DEST=process.argv[2];if(!DEST||existsSync(DEST))throw Error('A new output directory is required');
const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
const check=(ok:unknown,msg:string)=>{if(!ok)throw Error(msg);};
const basePath='outputs/GR4-INFO逐张身份与子菜单确认-v23/fwdc248b.bin';
const original=new Uint8Array(readFileSync(basePath));
check(sha(original)==='072713abe6ff99f06e9cca4f743c71e4aeb27046e96314d8768ed9981c0a8482','v23 identity');
const v=new Firmware(original);
const reference=JSON.parse(readFileSync(W+'upstream-diff.json','utf8'));
check(reference.official==='a2f664dfca034059eb0fd6e18ab08684c326b4a034d85c164dad7e1ec9b5655f'&&reference.bridge==='ecdfc3034441d9f1cc4684955de546a6d3d4bb495470a48fb8e1d84971659adb','reference identity');
const official=new Uint8Array(readFileSync(W+'official.decoded'));
const upstream=new Uint8Array(readFileSync(W+'upstream-bridge.decoded'));
check(sha(official)==='c4e597c7c9ca1bc181b30e35139ed90a4fd876ddcca14f12be0e00b6702233ae','official decoded identity');
const target=v.decoded.slice(),header=v.header.slice(),models=v.models.slice();
const vs=sectionsOf(v.decoded),os=sectionsOf(official);
const expectedOffsets=[0x19d49,0x19d95,0x19e95,0x84959c,0xa901ac,0xa901bc,0xffccfa,0xffce0a,0xffcf5a,0x2e4bbd6,0x2e697fe,0x2e6988d,0x2e698a1];
const payloadPatches:any[]=[];
for(const p of reference.payload){
  if(p.offset===official.length-4)continue; // Recompute v23's own checksum, never copy the official value.
  check(expectedOffsets.includes(p.offset),'unexpected upstream payload edit');
  const s=os.find(s=>p.offset>=s.offset&&p.offset+Buffer.from(p.before,'hex').length<=s.offset+s.size)!;
  check(s&&['RTOS','SRIC','CPU'].includes(s.name),'unreviewed section');
  const t=vs.find(t=>t.name===s.name)!;check(t,'missing target section');
  const offset=t.offset+(p.offset-s.offset),before=Buffer.from(p.before,'hex'),after=Buffer.from(p.after,'hex');
  check(Buffer.from(target.subarray(offset,offset+before.length)).equals(before),'v23 patch guard '+s.name+' '+offset.toString(16));
  const contextStart=Math.max(s.offset,p.offset-12),contextEnd=Math.min(s.offset+s.size,p.offset+after.length+12);
  check(Buffer.from(official.subarray(contextStart,contextEnd)).equals(Buffer.from(v.decoded.subarray(t.offset+contextStart-s.offset,t.offset+contextEnd-s.offset))),'v23 reference context mismatch');
  target.set(after,offset);payloadPatches.push({section:s.name,relativeOffset:p.offset-s.offset,offset,before:p.before,after:p.after});
}
check(payloadPatches.length===13,'complete payload patch set');
for(const [name,buffer]of [['header',header],['models',models]]as const){
  for(const p of reference[name]){const before=Buffer.from(p.before,'hex');check(Buffer.from(buffer.subarray(p.offset,p.offset+before.length)).equals(before),name+' patch guard');buffer.set(Buffer.from(p.after,'hex'),p.offset);}
}
const view=new DataView(target.buffer);view.setUint32(target.length-4,0,true);view.setUint32(target.length-4,(-sum32(target))>>>0,true);
const template={...v,header,models} as Firmware;
const built=build(template,target),again=build(template,target);
check(Buffer.from(built.out).equals(Buffer.from(again.out)),'reproducible output');
const verified=verifyContainer(built.out,target);check(Object.values(verified.checks).every(Boolean),'container verification');
const decoded=new Firmware(built.out);check(Buffer.from(decoded.decoded).equals(Buffer.from(target)),'decoded exact identity');
const allowed=new Set<number>();for(const p of payloadPatches)for(let j=0;j<p.before.length/2;j++)allowed.add(p.offset+j);
for(let j=0;j<4;j++)allowed.add(target.length-4+j);
let count=0;for(let i=0;i<target.length;i++)if(target[i]!==v.decoded[i]){check(allowed.has(i),'unexpected feature delta');count++;}
check(count===20,'expected 20 decoded changed bytes');
const reverted=target.slice();for(const p of payloadPatches)reverted.set(Buffer.from(p.before,'hex'),p.offset);reverted.set(v.decoded.subarray(-4),reverted.length-4);
check(Buffer.from(reverted).equals(Buffer.from(v.decoded)),'all v23 content retained outside reviewed bridge patch');
const sections=vs.map(s=>{
  const end=s.name==='RES'?target.length-4:s.offset+s.size;
  const changed=[];for(let i=s.offset;i<end;i++)if(target[i]!==v.decoded[i])changed.push(i-s.offset);
  return{name:s.name,offset:s.offset,size:s.size,changedOffsets:changed,sha256:sha(target.subarray(s.offset,end)),baseSha256:sha(v.decoded.subarray(s.offset,end))};
});
const rt=vs.find(s=>s.name==='RTOS')!;
const report={name:'XerFilm GR IV v23-H',displayVersion:'1.12',internalVersion:'1.12.10.7',basePath,baseSHA256:sha(original),sha256:sha(built.out),bytes:built.out.length,
  purpose:'High-version v23 build for factory GR IV bodies rejecting the public 1.11 update; contains all v23 features, not a stock-only bridge.',
  upstream:{project:'Maxwooow/Ricoh-GRMod',tag:'v0.8.0',commit:'16327db',bridgeSHA256:reference.bridge,license:'GPL-2.0-only'},
  payloadPatches,headerPatches:reference.header,modelPatches:reference.models,decodedChangedBytes:count,sections,reencodedFrames:built.reencoded,
  checks:{...verified.checks,reproducibleBuild:true,reviewedDeltaOnly:true,allV23FeaturesByteIdenticalOutsideVersionGate:true,originalV23Unchanged:sha(new Uint8Array(readFileSync(basePath)))===sha(original)},
  hardwareTested:false,limitations:['Local structural and byte-identity validation only; not physical boot/update validation.','Based on official GR IV 1.11, not an official Ricoh 1.12 release.','GR IV only; not GR III, IIIx or GR IV Monochrome.','The patched updater permits older component versions; it does not establish hardware compatibility with every factory revision.']};
mkdirSync(DEST,{recursive:true});
writeFileSync(DEST+'/fwdc248b.bin',built.out,{flag:'wx'});
writeFileSync(DEST+'/build-report.json',JSON.stringify(report,null,2),{flag:'wx'});
writeFileSync(W+'high-version.rtos',target.subarray(rt.offset,rt.offset+rt.size));
console.log(JSON.stringify({output:DEST,sha256:report.sha256,bytes:report.bytes,version:report.internalVersion,decodedChangedBytes:count,reencodedFrames:built.reencoded,checks:report.checks},null,2));
