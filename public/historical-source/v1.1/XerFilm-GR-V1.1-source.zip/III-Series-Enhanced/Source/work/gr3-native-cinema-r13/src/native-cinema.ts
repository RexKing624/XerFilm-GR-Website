// SPDX-License-Identifier: GPL-2.0-only
// New native Image Control identities; never alias the two existing Custom banks.
// Bounded list-extension locations researched by gr3-film-mods (MIT, see NOTICE).
import {Patch,fn,addr,u32le,concat,expectWord,branch,RAM} from './build';
import {movWord} from './arm';
import {installRuntime} from './film-runtime';

export function installNativeCinema(p:Patch,runtime:ReturnType<typeof installRuntime>){
 function set(a:number,before:number,after:number,why:string){expectWord(p,a,before);p.setWord(a,after,why);}
 function hook(a:number,w:number,s:string,why:string,link=false){expectWord(p,a,w);const at=fn(p,s);p.setWord(a,branch(a,at,link),why);return at;}
 // Unused legacy resource slots, with no original record/pixels overwritten.
 for(let i=0;i<2;i++)for(const[a,v]of [
  [0x55018d94+4*(i+1),runtime.matrixRecords[27+i]],
  [0x55018cf0+4*(i+1),runtime.sets+(27+i)*32],
  [0x55018e4c+4*(i+1),p.mappedWord(0x55018e4c+44)],
 ]){const mapped=RAM.source+a-RAM.destination;if(p.word(mapped)!==v)p.setWord(mapped,v,'new native Cinema resource slot');}
 const slot=hook(0x536dc280,0xe3520016,'cmp r2,#22;moveq r1,#25;bxeq lr;sub r1,r2,#25;cmp r1,#2;addlo r1,r1,#1;movhs r1,r2;bx lr','native Cinema resource mapping',true);
 set(0x536dc284,0x11a01002,0xe1a00000,'slot map moved into helper');
 set(0x536dc288,0x03a01019,0xe1a00000,'slot map moved into helper');
 const list=p.append(concat([p.read(0x53b59224,12),Uint8Array.from([25,26])]),4);
 const count=hook(0x532c2acc,0x93a0000c,'bhi #0x532c2ad0;push {r2};mrs r2,cpsr;cmp r3,#0;moveq r0,#14;movne r0,#12;msr cpsr_f,r2;pop {r2};b #0x532c2ad0','append two native still Image Control entries; RAW picker count unchanged');
 for(const[lo,hi,old]of [[0x532c2d60,0x532c2d64,0x53b59224],[0x532c2d80,0x532c2d84,0x53b58fcc],[0x532c2d00,0x532c2d04,0x53b5919c],[0x532c2f58,0x532c2f60,0x53b5919c],[0x532c2ff0,0x532c2ff8,0x53b58fcc],[0x532c3074,0x532c307c,0x53b59224]]){
  // Preserve the native register and instruction condition on both halves.
  for(const[a,high]of [[lo,false],[hi,true]] as const){const oldWord=p.word(a),reg=(oldWord>>>12)&15,cond=oldWord&0xf0000000;
   const before=(movWord(reg,high?old>>>16:old&65535,high)&0x0fffffff)|cond;
   const after=(movWord(reg,high?list>>>16:list&65535,high)&0x0fffffff)|cond;
   set(a,before>>>0,after>>>0,'native list index/tone table, all original entries retained');
  }
 }
 for(const a of [0x532c2f74,0x532c300c,0x532c3090])set(a,0xe350000c,0xe350000e,'native list reverse search includes Cinema');
 const names:Record<string,number>={},icons:Record<string,number>={};
 for(const[site,kind]of [[0x532922b4,'name'],[0x532935dc,'icon']]as const){
  const at=hook(site,0xe351000a,`sub ip,r1,#25;cmp ip,#2;blo added;cmp r1,#10;b #${site+4};added:movw r0,#${kind==='name'?889:858};add r0,r0,ip;bx lr`,'new native Cinema '+kind);(kind==='name'?names:icons)[site.toString(16)]=at;
 }
 const display=hook(0x5326c240,branch(0x5326c240,0x5326c2a0),'sub r0,r3,#25;cmp r0,#2;movlo r0,r3;blo #0x5326c22c;b #0x5326c2a0','native Cinema display identity');
 for(const[site,ret,fail,kind]of [[0x532a9874,0x532a98e0,0x532a9958,'name'],[0x532a99a0,0x532a9a0c,0x532a9a84,'icon']]as const){
  const at=hook(site,branch(site,fail),`sub r0,r1,#25;cmp r0,#2;bhs #${fail};movw r3,#${kind==='name'?889:858};add r0,r0,r3;b #${ret}`,'new native display '+kind+'; original Custom branches unchanged');(kind==='name'?names:icons)[site.toString(16)]=at;
 }
 const detail=hook(0x531acb1c,0xe354000b,'cmp r4,#14;cmpne r4,#15;moveq r4,#0;cmp r4,#11;b #0x531acb20','Cinema uses safe native Standard detail layout');
 const rawConvert=hook(0x53288d5c,0xe241100b,'sub ip,r1,#25;cmp ip,#2;movlo r0,#1;bxlo lr;sub r1,r1,#11;b #0x53288d60','Cinema as-shot safe RAW development conversion');
 const rawKind=hook(0x5318dea0,0xe241100b,'sub ip,r1,#25;cmp ip,#2;movlo r1,#11;sub r1,r1,#11;b #0x5318dea4','Cinema as-shot safe RAW detail layout');
 // This test port exposes fixed source defaults, without lending Standard's
 // saved adjustment cells to a new effect or editing Custom 1/2 recipes.
 const setters=[],defaults=[];
 for(const site of [0x532bd784,0x532bdcd8,0x532be22c,0x532be8a0,0x532bef14,0x532bf588,0x532bfbfc,0x532c0da8,0x532c141c]){
  setters.push(hook(site,0xe1a0c00d,`push {r0,r1,r2,r3,ip,lr};mrs ip,cpsr;push {r4,ip};ldrb r3,[r0,#0x1b];cmp r3,#0;bne native;bl #0x532bd6b4;sub r0,r0,#25;cmp r0,#2;bhs native;pop {r4,ip};msr cpsr_f,ip;pop {r0,r1,r2,r3,ip,lr};bx lr;native:pop {r4,ip};msr cpsr_f,ip;pop {r0,r1,r2,r3,ip,lr};mov ip,sp;b #${site+4}`,'fixed Cinema defaults: no writes into Standard or Custom recipes'));
 }
 for(const site of [0x532c34e8,0x532c3b54,0x532c41c0,0x532c494c,0x532c50d8,0x532c5864,0x532c5ff0,0x532c8bd4,0x532c9360]){
  defaults.push(hook(site,0xe1a0c00d,`sub ip,r1,#25;cmp ip,#2;movlo r0,#4;bxlo lr;mov ip,sp;b #${site+4}`,'fixed Cinema neutral scalar default; stock defaults unchanged'));
 }
 // Native maker-note codes are distinct from XerFilm's private JPEG identities.
 const exifPairs=0x53d2b6f4,exifCtor=0x53599df8,exifRead=0x535bf7d0;
 const pairs=p.append(concat([p.read(exifPairs,48),Uint8Array.from([25,0,12,1,26,0,13,1])]),4);
 const why='separate native Cinema maker-note identity';
 set(exifCtor-4,0xe3a00030,0xe3a00038,why);
 set(exifCtor+0x28,movWord(12,exifPairs&65535),movWord(12,pairs&65535),why);
 set(exifCtor+0x34,movWord(12,exifPairs>>>16,true),movWord(12,pairs>>>16,true),why);
 set(exifCtor+0x38,0xe2801030,0xe2801038,why);set(exifCtor+0x54,0xe353000c,0xe353000e,why);set(exifCtor+0x68,0xe2800030,0xe2800038,why);
 const readTable=p.append(concat([p.read(0x53d2d920,11),Uint8Array.from([25,26])]),4);
 set(exifRead,0xe350000a,0xe350000c,why);
 for(const[a,high]of [[exifRead+4,false],[exifRead+12,true]]as const){const mask=0x0fffffff,condition=0x90000000;set(a,((movWord(3,high?0x53d2:0xd920,high)&mask)|condition)>>>0,((movWord(3,high?readTable>>>16:readTable&65535,high)&mask)|condition)>>>0,why);}
 return{tones:[25,26],nativeIcons:[858,859],textIds:[889,890],count,list,slot,names,icons,display,detail,rawConvert,rawKind,setters,defaults,pairs,readTable,fixedSourceDefaults:true};
}
