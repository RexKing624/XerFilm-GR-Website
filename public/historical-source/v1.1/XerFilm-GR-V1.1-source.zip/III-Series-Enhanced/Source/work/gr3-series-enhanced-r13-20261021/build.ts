// SPDX-License-Identifier: GPL-2.0-only
// Independently scoped III/IIIx high-version tests, based on the existing R13 BIN.
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {Firmware,build,verifyContainer,sum32,sectionsOf} from '../gr3-native-cinema-r13/src/container';
import {branch} from '../gr3-native-cinema-r13/src/build';
import {movWord} from '../gr3-native-cinema-r13/src/arm';
const root='work/gr3-series-enhanced-r13-20261021',out='outputs/XerFilm-GRIII-Series-R13-H-2026-10-21';
const targets=[
 {model:'GRIII',label:'GR III / HDF',version:'2.11',full:'2.11.21.27',baseVersion:'2.10',major:2,minor:11,old:0x020a151b,next:0x020b151b,project:588,file:'fwdc239b.bin',sha:'284c08e6f260382ff2d566053910f488e4a6ce8a548c9414def61d5b80554a65'},
 {model:'GRIIIx',label:'GR IIIx / HDF',version:'1.61',full:'1.61.11.17',baseVersion:'1.60',major:1,minor:61,old:0x013c0b11,next:0x013d0b11,project:609,file:'fwdc243b.bin',sha:'31ff0cde8ace96eb9d6cfdda86da3a90832e703dd3ddbfb5fd8f36152a6680fd'},
];
const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
function need(x:unknown,m:string){if(!x)throw Error(m);}
for(const t of targets){
 const base=`outputs/XerFilm-${t.model}-R13-Cinema-2026-10-21/${t.model}-${t.baseVersion}-XerFilm-R13/${t.file}`;
 const raw=new Uint8Array(readFileSync(base));need(sha(raw)===t.sha,'Pinned R13 BIN changed');const fw=new Firmware(raw);need(fw.project===t.project,'Wrong model');
 const data=fw.decoded.slice(),header=fw.header.slice(),rows=sectionsOf(data),rt=rows.find(s=>s.name==='RTOS')!,cpu=rows.find(s=>s.name==='CPU')!;
 need(fw.models.length===0&&cpu.size===0x20000,'Unexpected model/CPU layout');
 const payload:any[]=[],heads:any[]=[];
 function patch(b:Uint8Array,at:number,before:Uint8Array,after:Uint8Array,reason:string,log:any[]){need(before.length===after.length&&Buffer.from(b.subarray(at,at+before.length)).equals(Buffer.from(before)),'Patch guard '+reason);b.set(after,at);log.push({offset:at,before:Buffer.from(before).toString('hex'),after:Buffer.from(after).toString('hex'),reason});}
 function word(v:number,be=false){const b=new Uint8Array(4);new DataView(b.buffer).setUint32(0,v>>>0,!be);return b;}
 // The native parser reads CPU/RTOS version at header+38 / +50, big endian.
 for(const a of [0x38,0x50])patch(header,a,word(t.old,true),word(t.next,true),'installation version',heads);
 patch(data,rt.offset+0x2038,word(t.old,true),word(t.next,true),'RTOS embedded version',payload);
 const mainAt=rt.offset+0x81fe6c,minorAt=rt.offset+0x81fe7c;
 const oldMain=t.model==='GRIII'?0xe300020a:0xe3a00f4f;
 patch(data,mainAt,word(oldMain),word(movWord(0,(t.major<<8)|t.minor)),'native version main accessor',payload);
 patch(data,minorAt,word(0xe3a00000|(t.minor-1)),word(0xe3a00000|t.minor),'native version minor accessor',payload);
 // Same GR Mod bridge principle, at independently verified III-family addresses:
 // retain project/checksum checks and file-presence guards; change only the
 // shared older-version rejection into its existing success/stack-check path.
 patch(data,rt.offset+0x6285dc,word(0xe3032804),word(branch(0x536285dc,0x5362857c)),'native updater lower-version return path',payload);
 // CPU is a 128KiB uncompressed image with a big-endian additive sum==0,
 // verified by the native checksum routine at53629044. Leave all CPU code intact.
 const oldCpu=data.slice(cpu.offset,cpu.offset+cpu.size);
 const sumBE=(b:Uint8Array)=>{const v=new DataView(b.buffer,b.byteOffset,b.byteLength);let s=0;for(let i=0;i<b.length;i+=4)s=(s+v.getUint32(i,false))>>>0;return s;};
 need(sumBE(oldCpu)===0,'Original CPU embedded checksum');
 patch(data,cpu.offset+0x90,word(t.old,true),word(t.next,true),'CPU embedded version metadata only',payload);
 const oldFix=oldCpu.slice(0x7c,0x80),fix=(new DataView(oldFix.buffer).getUint32(0,false)-sumBE(data.subarray(cpu.offset,cpu.offset+cpu.size)))>>>0;
 patch(data,cpu.offset+0x7c,oldFix,word(fix,true),'CPU embedded checksum',payload);need(sumBE(data.subarray(cpu.offset,cpu.offset+cpu.size))===0,'CPU checksum after version bump');
 const v=new DataView(data.buffer);v.setUint32(data.length-4,0,true);v.setUint32(data.length-4,(-sum32(data))>>>0,true);
 const template={...fw,header}as Firmware,built=build(template,data);const check=verifyContainer(built.out,data);need(Object.values(check.checks).every(Boolean),'Output container');
 const again=build(template,data);need(Buffer.from(again.out).equals(Buffer.from(built.out)),'Reproducible output');
 const restored=data.slice();for(const p of payload)restored.set(Buffer.from(p.before,'hex'),p.offset);restored.set(fw.decoded.subarray(-4),restored.length-4);need(Buffer.from(restored).equals(Buffer.from(fw.decoded)),'Unexpected R13 feature change');
 const sectionReport=rows.map(s=>{const a=fw.decoded.subarray(s.offset,s.offset+s.size),b=data.subarray(s.offset,s.offset+s.size);const offsets=[];for(let i=0;i<a.length;i++)if(a[i]!==b[i])offsets.push(i);return{name:s.name,offset:s.offset,size:s.size,changedOffsets:offsets,baseSha256:sha(a),sha256:sha(b)};});
 need(sectionReport.every(s=>s.changedOffsets.length===0||['RTOS','CPU','RES'].includes(s.name)),'Unrelated component changed');
 const dest=`${out}/${t.model}-R13-H-${t.version}`;mkdirSync(dest,{recursive:true});writeFileSync(`${dest}/${t.file}`,built.out);
 const image=data.subarray(rt.offset,rt.offset+rt.size);writeFileSync(`${root}/${t.model}-high.rtos`,image);
 const report={model:t.label,project:t.project,basePath:base,baseSha256:t.sha,version:t.version,fullVersion:t.full,publicFeatureVersion:'V1.1 / R13',file:t.file,bytes:built.out.length,sha256:sha(built.out),rtosSha256:sha(image),hardwareTested:false,payloadPatches:payload,headerPatches:heads,sections:sectionReport,checks:{...check.checks,reproducibleBuild:true,exactR13PreservationOutsideReviewedVersionAndGateChanges:true,cpuEmbeddedChecksumValid:true},limitations:['Only targets event-service bodies still on the original 2.10/1.60 main version; not the newly released official2.20/1.70.','No camera installation or boot was performed. Hidden service revisions may have other restrictions.','SRIC, BOOT, M0, Linux, INITFS, pixel processing and image assets remain byte-identical to R13.'],output:dest};
 writeFileSync(`${dest}/build-report.json`,JSON.stringify(report,null,2));writeFileSync(`${dest}/SHA256SUMS.txt`,report.sha256+'  '+t.file+'\n');console.log(t.model,report.fullVersion,report.bytes,report.sha256);
}
